<!-- omit from toc -->

# Autopilot Express

Autopilot Express is a PowerShell technician CLI for new-device builds using
[Autopilot Checklist - New Device v1.4](Autopilot%20Checklist%20-%20v1.4.pdf).
It reduces Intune/Entra portal navigation, keeps actions in checklist order and saves work between sessions.

> **Live mode can delete Intune managed-device records and change group membership and primary users.**
> This is an active development implementation, not a production-approved release. Use Demo for rehearsal.
> Tenant acceptance and a complete approved physical pilot remain outstanding. Keep storage Local; Shared is disabled.
> Complete [Live approval requirements](OPERATIONS.md#tenant-approval-gate) and
> [acceptance procedures](TESTING.md#real-environment-acceptance) before production use.

## Contents

- [Contents](#contents)
- [What It Does](#what-it-does)
- [Getting Started](#getting-started)
- [Configuration](#configuration)
- [Operation](#operation)
- [Saved Work and Recovery](#saved-work-and-recovery)
- [Troubleshooting](#troubleshooting)
- [Further Reading](#further-reading)
- [Support](#support)

## What It Does

- Captures serial/Service Tag, Configuration Item (CI), site and device type; accepts plain serials and supported scanner URLs.
- Resolves Autopilot, Intune and Entra identities, confirms deletion when needed and derives the enforced `SITECODE-DeviceType` Group Tag.
- Adds/removes pre-provisioning membership and assigns technician/final primary users with read-back verification.
- Guides imaging, profile checks, reseal, sign-in, applications, updates and conditional recovery, recording observations.
- Tracks multiple devices on a build bench, blocks unmet prerequisites and preserves progress, attempt history and local audit evidence.

The CLI does **not** replace physical work, approvals, the official checklist or technician judgement. Applications,
firmware, ZENworks, CMDB, deployment, collection and disposal remain technician/external work. Step H requests device
sync, not the checklist's application-remediation procedure. Guided-only mode and cross-machine audit searches are not implemented.

See the [operations reference](OPERATIONS.md) for detailed scope, workflow order and verification rules.

## Getting Started

Use Windows and PowerShell 7, preferably a fresh non-elevated session. Keep the script and both JSON definitions together:

```plaintext
autopilot-express/
|-- autopilot-express.ps1           # CLI entry point
|-- autopilot-express.manifest.json # Ordered actions, prerequisites and guidance
|-- autopilot-express.runtime.json  # Tenant settings and Demo data
`-- Autopilot Checklist - v1.4.pdf  # Governing physical-device procedure
```

From the repository root, start a rehearsal:

```pwsh
Set-Location .\intune\devices\autopilot-express
.\autopilot-express.ps1 -Mode Demo
```

Demo simulates Graph operations and saves separate Demo records. It does not authenticate or mutate the tenant.
Without an explicit mode, the prompt defaults to Demo. Follow saved-session and site prompts, then open Build bench
or start a new device.

Before **approved Live** use, also have Graph/service network access, approved delegated permissions, current Windows 11
USB media and the checklist's hardware/network prerequisites. Configured modules include `Microsoft.Graph.Authentication`
and `Microsoft.Graph.DeviceManagement.Enrollment`. Missing modules offer PSGallery installation into the current Windows
user scope, default **No**. Do not install or broaden permissions without approval.

Account contexts are distinct: CA/A authenticates to Graph; C/E is used for physical sign-in; the final primary user is
an explicitly selected eligible active C/E account. The CLI does not infer managers or account roles.

After [tenant approval](OPERATIONS.md#tenant-approval-gate) and separate authorisation for the intended operations:

```pwsh
.\autopilot-express.ps1 -Mode Live
```

The initial screen shows `Initial setup and testing`. Definitions and storage checks run first; Live then completes
sign-in, tenant binding and profile/group/read checks **before** resume or site selection. Failure stops startup rather
than continuing into saved work. Authentication/read success does not prove write permission or authorise mutations.

For approved IDE/ISE pasted-code execution or a nonstandard definition folder, see
[Pasted-Code Execution](OPERATIONS.md#pasted-code-execution). Compatibility is not approval to bypass execution policy.

## Configuration

Edit [autopilot-express.runtime.json](autopilot-express.runtime.json) in the definition folder this invocation loads.
Replace example values and have the tenant owner validate settings before Live use. Configuration loads **once at startup**.

| Setting                                          | Purpose                                                                                  |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------- |
| `graph.expectedTenantId`                         | Approved tenant GUID; blank allows unpinned sign-in, not tenant approval.                |
| `graph.requiredScopes` / `graph.requiredModules` | Approved access/SDK modules; review all seven scopes, including privileged sync.         |
| `autopilot.deploymentProfileDisplayName`         | Intended profile, currently `SJOG Hybrid Join`; physically verify assignment.            |
| `autopilot.preProvisioningGroupDisplayName`      | Exact group name, currently `Intune-Autopilot-PreProvisioning`; controls add and remove. |
| `storage.mode`                                   | Keep `Local` for initial imaging. Shared is disabled and not qualified.                  |

To change the pre-provisioning group:

1. Change `autopilot.preProvisioningGroupDisplayName` to the approved exact Entra **display name**, not its object ID.
2. Save the runtime file and restart the script; there is no live reload or main-menu group-change control.
3. During approved Live startup, verify the tenant and uniquely resolved group against approved evidence. Missing or duplicate names are rejected.

Use an eligible assigned security group for manual device membership, not a dynamic group. A blank/recognised placeholder
prompts at Live startup, but that choice is **session-only** and is not written to JSON.

**Do not switch groups midway through a build without a reviewed transition.** Removal targets the currently configured
group, which may differ from the earlier addition. Changing settings or archiving local work does not migrate/remove
tenant memberships or reset saved evidence. Finish with the original approved group or obtain tenant-owner review.

Account eligibility, scanners, search limits and polling/transport controls are in the
[configuration reference](OPERATIONS.md#configuration-reference). Never clear a tenant pin or widen scopes to bypass a failure.

## Operation

Follow the displayed commands and labelled defaults; choices are case-insensitive. `0` returns/exits where shown.

```plaintext
Main Menu
|-- 1. Build bench                  # Manage physical device positions
|-- 2. Start work on a new device   # Capture serial, CI, site and type
|-- 3. Work on a tracked device     # Continue one device's workflow
|-- 4. What's outstanding          # Inspect steps and open that device
|-- 5. Maintain my device list     # Edit status; completion is guarded
|-- 6. My stats and progress        # Per-user totals
|-- 7. Change current site          # Select the working site
|-- 8. About this script            # Script information
|-- 9. Enhancements and questions   # Future ideas
|-- 10. Archive and start fresh     # Current-user/mode pair; No/CANCEL defaults
`-- 0. Exit                        # Save and close Graph
```

In a tracked workflow, `8` runs the next eligible step, a step ID chooses eligible work, `9` selects another device
and `0` returns. Follow alternative labels if custom IDs collide. Outstanding option `1` opens the same device.
Declining new-device confirmation retains editable defaults; Enter keeps them. CI is text and leading zeros matter.

```plaintext
Build Bench
|-- I. Induct                       # Place a device in an empty position
|-- S. Next step                    # Run the next eligible action
|-- C. Choose action                # Select eligible specific work
|-- V. View                         # Inspect device/progress
|-- D. Dispatch                     # Complete/remove after required work
|-- R. Remove                       # Bench position only, not workflow evidence
|-- M. Move                         # Move to an empty position
|-- W. Workflow guide               # Read steps, notes and prerequisites
`-- 0. Return                       # Main menu; E is a legacy alias
```

On the bench, Enter **refreshes**, not exits. Select by position, serial or CI; use `P:1`, `S:ABC123` or `CI:001` when
ambiguous. Bare `0` cancels; `CI:0` selects that literal CI. In the guide use `>` then Enter for Next, `<` then Enter
for Previous, a step ID for detail, `STEP LIST` for overview and `0`/Enter to return. N/P remain step IDs.
The guide does not execute actions or change progress.

Read the result state: **Verified** means observed Graph state; **TechnicianConfirmed** means manual observation;
**Simulated** is Demo only. **Submitted** is pending, not completion; Failed/Blocked cannot advance work. An empty
next-step picker is not completion. Retrying completed work invalidates dependent completion; repeat it before dispatch.
See [workflow and physical work](OPERATIONS.md#workflow-and-physical-work) for the full sequence and recovery close-out.

## Saved Work and Recovery

Work is saved per Windows user/mode; Live audit is shared within the local root. Resume deliberately. Normal storage
is project `data/`; if unwritable, fallback is `%LOCALAPPDATA%\PowerShellScriptingNew\AutopilotExpress\data`.
Once authoritative, fallback stays authoritative. Do not merge copies or choose by timestamp. Protect operational/personal
data and keep it out of Git.

Option `10` archives the current user's current-mode device/bench pair, not an archive catalogue. Selection defaults
to cancel, then **No**, then requires `CLEAR` (default `CANCEL`). Successful archival starts fresh site/bench setup without
reconnecting Graph. Audit, recent users, receipts and other users/modes remain; tenant state is unchanged.

**If a save, lock, checkpoint or archive fails: stop and preserve evidence.** Never remove an active lock, delete recovery
markers to bypass guards or replay uncertain mutations. There is no automatic rollback or distributed/power-loss guarantee.
Follow [session and recovery procedures](OPERATIONS.md#data-session-recovery-and-audit) with the recovery owner.
The bench's five-line feedback is transient, not a durable transcript or proof of save.

## Troubleshooting

| Symptom                          | First response                                                                                                                                             |
| -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Live fails after browser sign-in | Preserve stage/type/status/request ID and SDK/host versions. Check approved tenant/settings; see [startup diagnosis](OPERATIONS.md#live-startup-failures). |
| Serial not found                 | Check canonical serial, follow approved hash-upload handoff and retry. Never bypass Autopilot presence.                                                    |
| Graph action denied              | Preserve permitted code/request ID and target/action; ask the administrator to review minimum approved access.                                             |
| Submitted or uncertain result    | Inspect tenant state and saved evidence under approval before repeating any write.                                                                         |
| No eligible next step            | Inspect prerequisites/recovery in `W` or the action list; do not force completion.                                                                         |
| Resume, storage or lock error    | Confirm user/mode/root, stop and follow [recovery procedures](OPERATIONS.md#data-session-recovery-and-audit).                                              |
| Layout problem                   | Rehearse Demo in the same host/width; supply permitted screenshots and exact input sequence.                                                               |
| Physical Autopilot failure       | Record `X` and reason; follow approved B/F/timed-Q [recovery close-out](OPERATIONS.md#recovery-close-out). Never reuse old physical completion.            |

For an approved diagnostic launch, add `-Verbose` for exception-type chains. Never share indiscriminate SDK
body/debug/token logging, broaden permissions or switch tenants as a speculative workaround. Detailed diagnostic
meaning and limitations are in [OPERATIONS.md](OPERATIONS.md#troubleshooting).

## Further Reading

| Document                                                               | Read it for                                                                                         |
| ---------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| [OPERATIONS.md](OPERATIONS.md)                                         | Detailed scope, workflow/evidence rules, advanced configuration, Graph behaviour and safe recovery. |
| [TESTING.md](TESTING.md)                                               | Regression/lint commands, results, visual/tenant acceptance and approved physical-pilot procedures. |
| [DEVELOPMENT.md](DEVELOPMENT.md)                                       | Contributor guidance, roadmap, maintained TODO status and future decisions.                         |
| [Autopilot Checklist - v1.4.pdf](Autopilot%20Checklist%20-%20v1.4.pdf) | Governing technician/physical procedure.                                                            |

Offline passes do not approve Live use or certify terminal layout, corporate policy or every SDK combination.
The historical text scaffold is reference-only; use the script and current JSON definitions.

## Support

Use MWP + ITSOs Teams chat with serial, checklist/action, permitted error/code/request ID, approved evidence location
and troubleshooting completed. For defects include mode, host/version/language mode, source/config revision,
SDK versions, exact inputs, preflight output and record/checkpoint IDs. Never include secrets. Stop on uncertain tenant
or stored state; the pilot approver and recovery owner decide when work may resume.
