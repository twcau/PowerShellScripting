<!-- omit from toc -->

# Autopilot Express Testing

Use this guide to run the offline regression suite, understand what each test file checks, and collect evidence
before approving a real-device pilot. For installation and technician operation, see [README.md](README.md).
Offline passes do not approve Live authentication, tenant mutations, physical imaging or Shared storage.

## Contents

- [Contents](#contents)
- [Requirements](#requirements)
- [Run the Offline Suite](#run-the-offline-suite)
- [Run a Focused Suite](#run-a-focused-suite)
- [Static Analysis](#static-analysis)
- [Test Catalogue](#test-catalogue)
- [Usability Acceptance](#usability-acceptance)
  - [Screenshot Review Backlog](#screenshot-review-backlog)
- [Real Environment Acceptance](#real-environment-acceptance)
- [Single-Device Live Pilot](#single-device-live-pilot)
  - [Approval and Baseline](#approval-and-baseline)
  - [Authorised Inspection](#authorised-inspection)
  - [Approved Build](#approved-build)
  - [Stop and Acceptance Criteria](#stop-and-acceptance-criteria)
- [Maintaining Tests](#maintaining-tests)
- [Validation Results](#validation-results)
- [Historical Validation Notes](#historical-validation-notes)
  - [Shared Development Contract](#shared-development-contract)

## Requirements

- Pester 5.7.1 or later, installed and approved for the development host.
- A FullLanguage development session for parsing and extracting production functions.
- PowerShell 7 and Windows PowerShell 5.1 for the two-host compatibility gate.
- Writable temporary storage. Run from the Autopilot Express directory, not the repository root.
- PSScriptAnalyzer for static analysis; Node.js/npm for Markdown linting.

The suites mock tenant requests and physical work. File tests use isolated temporary directories, and actual CLI
rehearsals copy the entry point and definitions there. No test run authorises access to operational tenant data.
Some tests start Windows PowerShell children with synthetic ConstrainedLanguage; these are not certification of
an enforced corporate policy, ISE, or every installed Graph SDK version.

## Run the Offline Suite

Open a fresh PowerShell host and navigate to this directory. Run the following block separately in PowerShell 7
and Windows PowerShell 5.1. Selecting the exact installed Pester manifest avoids accidentally using inbox Pester 3.

```powershell
& {
    $ErrorActionPreference = 'Stop'
    $pester = Get-Module -ListAvailable Pester |
        Where-Object Version -ge '5.7.1' |
        Sort-Object Version -Descending |
        Select-Object -First 1
    if (-not $pester) { throw 'Install an approved Pester 5.7.1 or later before testing.' }
    Import-Module -Name $pester.Path -ErrorAction Stop
    $configuration = New-PesterConfiguration
    $configuration.Run.Path = Join-Path $PWD 'tests'
    $configuration.Run.PassThru = $true
    $configuration.TestResult.Enabled = $false
    $configuration.Output.Verbosity = 'Detailed'
    $result = Invoke-Pester -Configuration $configuration
    Write-Output ('Host={0}; Total={1}; Passed={2}; Failed={3}; Skipped={4}; NotRun={5}' -f
        $PSVersionTable.PSVersion, $result.TotalCount, $result.PassedCount,
        $result.FailedCount, $result.SkippedCount, $result.NotRunCount)
    if ($result.TotalCount -eq 0 -or $result.FailedCount -gt 0 -or
        $result.SkippedCount -gt 0 -or $result.NotRunCount -gt 0) {
        throw 'Offline regression gate failed. Inspect discovery and failures before proceeding.'
    }
}
```

Result export is disabled so the suite does not write reports into the source tree. Capture permitted output in
the approved evidence location. Record host version, discovered files, totals and source/configuration revision.
Use direct full discovery for the final gate: editor discovery can omit repeated test blocks. Totals are executed
checks, not unique scenarios, and should increase when coverage is added. Do not pin an obsolete expected count.

## Run a Focused Suite

After importing the approved Pester manifest as above, target the relevant existing file:

```powershell
Invoke-Pester -Path '.\tests\WorkflowRehearsal.Tests.ps1' -Output Detailed
```

For UI changes, run the workflow rehearsal first. For changes to shared helpers, run their neighbouring suites,
then complete full discovery on both hosts. A focused pass is not a replacement for the final cross-host gate.

## Static Analysis

Run from this directory after installing/importing the approved PSScriptAnalyzer module:

```powershell
& {
    $files = @('.\autopilot-express.ps1') + @(
        Get-ChildItem '.\tests' -Filter '*.Tests.ps1' | Select-Object -ExpandProperty FullName
    )
    $findings = @($files | ForEach-Object {
        Invoke-ScriptAnalyzer -Path $_ -ExcludeRule PSUseSingularNouns, PSAvoidUsingWriteHost
    })
    $findings | Format-Table ScriptName, Line, RuleName, Message -AutoSize
    if ($findings.Count -gt 0) { throw 'Static analysis gate failed.' }
}
```

The two established exclusions cover collection-oriented internal helper names and intentional interactive host
output. Other source-level suppressions are narrow and documented at their declaration; do not broaden them to
hide new defects. The real CLI rehearsal uses a test-only global prompt fixture because the entry point has a
separate script scope. Its prior value and inherited storage roots are restored after each run.

Validate the operator, testing and development documentation:

```powershell
npx --yes markdownlint-cli README.md OPERATIONS.md TESTING.md DEVELOPMENT.md --disable MD013
```

`MD013` is the established line-length exception for tables and commands. Other findings must be resolved.

## Test Catalogue

All thirty current suites are listed below. Follow a file link to inspect individual cases and fixtures rather
than relying on historical per-file counts. Tests extract the real functions unless a row identifies actual CLI
execution. Graph calls, waits and physical observations are mocked or use Demo simulation.

| Suite                                                                            | Behaviour and principal risks checked                                                                                                                        |
| -------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| [DirectoryUser.Tests.ps1](tests/DirectoryUser.Tests.ps1)                         | Active C/E eligibility, exact/literal/one-edit suggestions, ranking, paging, selection, recent-user JSON.                                                    |
| [PrimaryUserAssignment.Tests.ps1](tests/PrimaryUserAssignment.Tests.ps1)         | Exclusive primary-user evidence, object-ID precedence, partial submissions, bounded polling, no write replay, cancellation.                                  |
| [GroupTag.Tests.ps1](tests/GroupTag.Tests.ps1)                                   | Guarded v1.0 REST mutation, exact tag read-back, delayed propagation, failures, submission evidence and Demo isolation.                                      |
| [GroupMembership.Tests.ps1](tests/GroupMembership.Tests.ps1)                     | Add/remove reference writes, idempotent pre-checks, bounded membership verification and failure handling.                                                    |
| [ManagedDeviceRemoval.Tests.ps1](tests/ManagedDeviceRemoval.Tests.ps1)           | Confirmed deletion, unique current targets, delayed absence, replacement identities and cancellation.                                                        |
| [DeviceIdentity.Tests.ps1](tests/DeviceIdentity.Tests.ps1)                       | Unique serial/registration resolution, malformed/partial responses, staged context and stale-ID removal.                                                     |
| [MutationTarget.Tests.ps1](tests/MutationTarget.Tests.ps1)                       | Refresh before writes; never mutate cached, absent or mismatched targets.                                                                                    |
| [GraphEvidence.Tests.ps1](tests/GraphEvidence.Tests.ps1)                         | Complete collection evidence, safe continuation URLs, repeated/duplicate pages, group/profile/organisation identity.                                         |
| [GraphTransport.Tests.ps1](tests/GraphTransport.Tests.ps1)                       | Public HTTPS Graph URI safety, relative SDK paths, SDK controls, GET-only retries, Retry-After, redacted logs.                                               |
| [GraphModuleSelection.Tests.ps1](tests/GraphModuleSelection.Tests.ps1)           | Common installed Graph version, exact manifest selection, import order and conflicting-version refusal.                                                      |
| [TenantBinding.Tests.ps1](tests/TenantBinding.Tests.ps1)                         | Expected tenant pin, authenticated ownership, refusal of cross-tenant and unsafe legacy adoption.                                                            |
| [ManifestDefinition.Tests.ps1](tests/ManifestDefinition.Tests.ps1)               | Schema, types, supported actions, prerequisites, phase coverage, invalid definitions without partial publication.                                            |
| [PhysicalMilestone.Tests.ps1](tests/PhysicalMilestone.Tests.ps1)                 | Checklist gates, explicit observations, recovery close-out, renamed labels, incomplete work and manual completion refusal.                                   |
| [CompletionSafety.Tests.ps1](tests/CompletionSafety.Tests.ps1)                   | Honest Demo/failure states, completion/dispatch readiness, downstream invalidation and retained previous evidence.                                           |
| [HandoffGuidance.Tests.ps1](tests/HandoffGuidance.Tests.ps1)                     | Guidance-only external handoffs, triggering evidence, no extra mutation or completion claims.                                                                |
| [WorkflowRehearsal.Tests.ps1](tests/WorkflowRehearsal.Tests.ps1)                 | Real isolated Demo entry point, persistence/reload, two-device bench, startup faults; headers, menu order, repeated actions, feedback and return navigation. |
| [BenchInduction.Tests.ps1](tests/BenchInduction.Tests.ps1)                       | Occupied positions, duplicate/conflicting identities, matching existing records and preserved progress.                                                      |
| [BenchLinks.Tests.ps1](tests/BenchLinks.Tests.ps1)                               | Occupied slot links agree with active workflow serial, CI, status and metadata.                                                                              |
| [ScannerSelection.Tests.ps1](tests/ScannerSelection.Tests.ps1)                   | Position/serial/CI collisions, explicit prefixes, leading zeros, cancelled or removed selections.                                                            |
| [PersistedState.Tests.ps1](tests/PersistedState.Tests.ps1)                       | Typed saved evidence, supported states, dates, recovery history and legacy compatibility without empty-state substitution.                                   |
| [StorageFailure.Tests.ps1](tests/StorageFailure.Tests.ps1)                       | Read/parse/save failures, unreadable audit preservation, normal missing-file startup.                                                                        |
| [StorageRoot.Tests.ps1](tests/StorageRoot.Tests.ps1)                             | Root authority, sticky fallback, conflicting copies, interrupted migration and receipt boundaries.                                                           |
| [LocalSessionSafety.Tests.ps1](tests/LocalSessionSafety.Tests.ps1)               | Exclusive local reservation, tokens, contention, mode separation and crash leftovers.                                                                        |
| [InterruptedWrite.Tests.ps1](tests/InterruptedWrite.Tests.ps1)                   | Staging/read-back/backup/promotion/cleanup faults, retained artefacts, startup blocking and archiving.                                                       |
| [LocalCheckpoint.Tests.ps1](tests/LocalCheckpoint.Tests.ps1)                     | Detached multi-file proposals, save ordering, unresolved-checkpoint guards and read-only inspection.                                                         |
| [CheckpointWorkflow.Tests.ps1](tests/CheckpointWorkflow.Tests.ps1)               | Actual CLI fault injection, retained proposals, restart refusal, lock release, successful resume and history.                                                |
| [AttemptHistory.Tests.ps1](tests/AttemptHistory.Tests.ps1)                       | Detached attempt evidence, sequence/identity/date fields, legacy snapshots and recovery retention.                                                           |
| [AttemptHistoryPersistence.Tests.ps1](tests/AttemptHistoryPersistence.Tests.ps1) | Append-only saved history, truncation/rewrite refusal, nested evidence and record/audit consistency.                                                         |
| [SyncSubmission.Tests.ps1](tests/SyncSubmission.Tests.ps1)                       | Accepted sync receipts, confirmation-only resume, changed/damaged targets, no automatic POST replay.                                                         |
| [SharedStorageSafety.Tests.ps1](tests/SharedStorageSafety.Tests.ps1)             | Disabled runtime mode, offline reservation/revisions, retained audit/history, recovery inspection and read-only migration preview.                           |

## Usability Acceptance

The screenshot-review code and added focused coverage now pass a fresh 980-check gate on each supported host.
The table records implementation and acceptance criteria, not proof that every terminal layout is visually accepted.
Do not accept actual terminal visual layouts until the technician completes the final review.
Rehearse with Demo mode and non-production identifiers; keep screenshots in controlled storage.

### Screenshot Review Backlog

These implemented tasks precede final terminal visual acceptance, tenant acceptance and the Live pilot. The current main-menu
order is 1 Bench, 2 New Device, 3 Tracked Device, 4 Outstanding Work, 5 Maintain Device List, 6 Statistics, 7 Site,
8 About, 9 Enhancements, 10 Archive Session, 0 Exit. Old numeric routes are superseded, not preserved as conflicting aliases.

| TODO | Implemented behaviour                                                                                                                                                                                                                                                                   | Regression and visual acceptance criteria                                                                                                                                                                                                                                      |
| ---- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 49   | Derive sequential displayed numbers and routing from one ordered collection with stable internal action IDs; changing order must not require a second dispatcher rewrite.                                                                                                               | Every number selects the displayed action; reorder the collection and prove routes follow it; reject invalid choices; update all real CLI and checkpoint prompt fixtures without dropping evidence assertions.                                                                 |
| 50   | Put Demo/Live mode in the blue header on every screen, including redraws and guide pages; remove duplicate mode indicators elsewhere. Main has exactly one blank row below the bar, one combined site/Graph line and a blank row before choices; remove redundant MAIN MENU decoration. | Both modes, connected/disconnected/unset site, narrow widths and unavailable RawUI; no duplicate mode labels, overlapping text or redundant title. Wrapping on narrow screens must preserve full account/site text.                                                            |
| 51   | On the bench, place retained recent results below the command-entry area with a visible text separator and spacing.                                                                                                                                                                     | Rendering order and actual input/cursor position, retained latest five lines across refresh/actions/refusals, Enter refresh, immediate 0/E return, no consumed outcome objects or lost save errors.                                                                            |
| 52   | Page the workflow guide by available window height with the blue header on each page, page indicator, next/previous/return controls and step details.                                                                                                                                   | Short/long guides, wrapped rows, first/middle/last pages, last-page Previous, terminal resize, missing RawUI fallback, case-insensitive valid/invalid input and step-ID command collisions; no workflow execution or save.                                                     |
| 53   | After declining new-device confirmation, retain serial, CI, site and selected device type as editable defaults; Enter accepts each existing value and the derived tag updates correctly.                                                                                                | N then Enter retains values; editing one field preserves others; scanner normalisation/defaults and site/type changes remain correct; cancellation creates no record, save or tenant mutation.                                                                                 |
| 54   | Validate serial/CI format and identity conflicts when those fields are entered, with correction/retry rather than forced main-menu return; retain final defensive identity checks.                                                                                                      | Duplicate serial, CI held by multiple active workflows, cross serial/CI conflicts, removed-record rules, invalid scanner values, corrected values and cancellation; no new records/writes until valid confirmation; final recheck catches changes after field validation.      |
| 55   | Tracked Device uses 8 Next Eligible Step and 9 Select Another Device. Show a separated result for the current serial/CI and action: green background/white text for completed success, red background/white text for failure, plus explicit text/evidence states.                       | Consecutive actions and device switching, shortcut/step-ID collisions, clear result ownership after switching, wrapped messages and save failure; Simulated is labelled, Submitted/Blocked/cancelled are not presented as completed success, and colour is never the only cue. |
| 56   | Outstanding Work opens the already selected device directly in Tracked Device, with no reselection; retain another-device and return options.                                                                                                                                           | Same record identity reaches the workflow, no extra selection prompt, actions persist normally, invalid/removed targets are refused, cancellation/return is immediate and viewing alone never mutates evidence.                                                                |
| 57   | Maintain Device List stays available for other devices after an edit or completion refusal; offer another device and explicit return.                                                                                                                                                   | Multiple independent edits, invalid/blocked completion and correction, no-op/cancel paths, accurate saved actor/time, preserved readiness gates, no duplicate acknowledgement or hidden persistence failure.                                                                   |
| 58   | Integrate all previous and new UI requirements in existing suites, update operator/test documentation, then rerun full discovery on both hosts and static/documentation lint.                                                                                                           | Retain coverage for About editing/return, enhancements, induction, per-line reports, recovery, identity, history and storage safety. Record new actual totals; 961 is not an expected fixed count or proof of new features.                                                    |

For the final technician review, exercise every screen and navigation path above in narrow/wide windows on both
supported hosts. Confirm the mode stays in the header throughout the session; inspect actual command placement,
page boundaries, coloured/text-labelled results and field correction, not just mocked Write-Host call order.
The screenshots supplied on 11 October show Main and Tracked Device only, not complete visual acceptance.
Main-menu Enter continues to default to Exit unless separately approved; guide paging is now requested work,
while a longer persistent bench message-history feature is not implicitly authorised. Guide controls use
`>` for Next and `<` for Previous, each followed by Enter; N/P still open step details. Custom direction-symbol
step IDs cause the displayed paging command to repeat its symbol instead. `STEP LIST` returns from details. Resizing recalculates pages
on the next input. Cursor-capable bench hosts reserve command rows above feedback; non-cursor hosts print results
after linear input. Verify this in the real terminal, including wrapped commands, scroll and unavailable RawUI.
Tiny windows unable to fit all navigation and one content row require enlargement; offline paging is not a guarantee
of usable output at arbitrarily small dimensions.

Include the latest startup/archive flow in TODO 48. Use disposable Demo sessions for archival checks, not operational
Live evidence. Record host, terminal, window dimensions and observed results, with screenshots free of sensitive data.

- Launch without a mode argument: confirm the clear screen and blue Initial setup and testing bar precede mode input.
- In Demo, confirm setup proceeds without sign-in; for an approved Live run, confirm tenant checks precede resume/site input.
- Check option 10 at narrow and wide widths; the warning, retained-evidence text and defaults must remain readable.
- Cancel selection, press Enter at the No default, and cancel CLEAR; each path must preserve the active list and bench.
- On a disposable confirmed archive, check empty active work, fresh site selection and subsequent bench position/type setup.
- Confirm no reconnection, lost result text, overlap or misleading success banner; verify archived files and retained history.

These are technician acceptance criteria, not completed visual checks. TODO 31 and TODO 10 still require separate
approved tenant/read and physical-device/mutation evidence; Shared remains deferred under the existing backend decision.

## Real Environment Acceptance

Offline tests do not establish authentication, consent, Conditional Access, Intune RBAC, propagation or physical
build success. Follow [Tenant Approval Gate](OPERATIONS.md#tenant-approval-gate) and
[Single-Device Live Pilot](#single-device-live-pilot). Authentication/read inspection and mutations need
separate approval. Compare each intended change independently in the portals; do not use destructive probes.

Required evidence includes approved account/tenant/group/profile/device identities, host/SDK versions, expected
and observed outcomes, permitted error/request IDs, successful save/reload, final ownership and physical checklist
results. Stop on unexpected targets, incomplete evidence, permission/storage failure or unresolved recovery files.
The approver must accept the full pilot and remaining limitations before bulk imaging. Shared storage is deferred
and disabled; offline helpers do not qualify a network backend, distributed ownership or power-loss durability.

## Single-Device Live Pilot

This is an offline-prepared procedure moved from the README, not approval or evidence of a successful Live build.
Use one dedicated, approved pilot serial before bulk imaging. Shared storage stays disabled. Use the intended
production host and corporate policy without bypassing application control or execution policy. Synthetic tests
do not certify that host.

### Approval and Baseline

Record the following in the controlled change record, not in Git:

- Approver, operator, intended tenant identity, pilot serial and CI, site/type and expected Group Tag.
- Approved deployment profile and group IDs, Graph account, required consent/roles and Conditional Access readiness.
- Approved physical reimage/reset procedure and the explicitly permitted mutations: managed-device deletion,
  Group Tag change, group add/remove, technician/final-user assignment and sync. Recovery unblock requires separate
  approval if not already included; do not deliberately fail production enrolment to exercise recovery.
- Technician C/E physical sign-in account and explicitly selected final-owner identity, without manager-chain inference.
- Script/definition versions or hashes, PowerShell host/version/language mode, Graph module versions, pilot window,
  evidence location, access/retention rules, recovery owner and escalation contact.

Preserve the existing device/bench/audit files and read-only portal baseline: matching Autopilot serial and ID,
associated managed-device ID, Entra device ID, tag, profile, group membership and existing primary-user relationships.
Confirm there is no other technician working on this serial. A local store reservation does not coordinate separate
computers or copied roots. Keep recovery artefacts with the records; resolve existing markers before startup.

### Authorised Inspection

Only after explicit authentication/read approval, start Live mode and verify the signed-in tenant/account and
selected profile/group against the approved identities. Live startup requests configured write-capable scopes:
there is no enforced read-only or dry-run switch. During an inspection-only authorisation, do not select mutating
workflow actions. Do not treat successful consent, structural checks or reads as mutation approval.

Resolve the approved serial with A and compare every returned identity with the baseline. If it is absent, ambiguous,
unexpected or belongs to a different device, stop. The external upload handoff does not satisfy Autopilot presence.
Exit after inspection if mutation approval is not yet granted. Preserve its local evidence for review.

### Approved Build

After separate mutation and physical-work approval, resume the same pilot record and follow the CLI prerequisites:

1. A/B/C/E: resolve identities, remove the associated managed-device record when required, apply the exact Group Tag,
   and add the correct Entra device to pre-provisioning. Independently check the target and outcomes in the portals.
2. K/D/L/M: perform approved imaging/OOBE, verify the deployment profile, complete pre-provisioning, reseal and boot
   to sign-in. Do not continue on a wrong profile or failed preparation. Physical confirmations are observations,
   not Graph verification.
3. G/I/N: verify technician assignment and pre-provisioning group removal before first physical sign-in. Confirm
   that the managed-user relationship is exclusive and matches the selected account.
4. O/H/P: verify the ordered application baseline, handle any failing installation using the approved portal
   remediation, complete required sync and confirm updates/procedures/shutdown. H is a sync request, not the named
   Retry failed app installation remediation; follow the CLI's existing eligibility rules rather than replaying writes.
5. J: explicitly select the approved final owner and independently verify both Autopilot and managed primary-user
   evidence. Record whether the result is Verified or TechnicianConfirmed; do not relabel manual evidence as verified.
6. Exit normally and resume once to confirm the same record IDs, step evidence and completion survive reload.
   If using a bench slot, check dispatch removes only this pilot slot and preserves its workflow record. Complete
   checklist steps 24-26 externally and retain their evidence; the guide and dispatch do not certify those handoffs.

If recovery is necessary and approved, use X/F/Q as guided: reset/reimage, verify managed-device absence and manually
observe Allowed after the required wait. Check recovery history and restart from B. Otherwise stop and escalate.

### Stop and Acceptance Criteria

Stop on an unexpected tenant/device/group/profile/owner, permission or policy failure, ambiguous relationships,
incorrect tag, storage error, unresolved save artefact, physical failure or an outcome that disagrees with the portal.
Submitted means unverified: inspect state and resolve it before proceeding. Do not blindly repeat an action after a
timeout or save failure; the mutation may already have succeeded. Preserve error text, timestamps, request IDs where
available, record IDs and permitted screenshots. Restoration of deleted managed-device records is not an automatic
rollback; use the approved re-enrolment/recovery procedure and owner for that risk.

Release requires a reviewed complete real build with expected portal outcomes, truthful evidence states, successful
save/reload and no unresolved failures or recovery markers. Record external handoffs separately, including applicable
old-device collection/disposal. Log any defects with reproduction details and rerun the affected pilot after repairs.
The approver must accept the pilot evidence and remaining limitations before authorising bulk imaging. Approval and
execution are still outstanding; no Live session was started while preparing this procedure.

## Maintaining Tests

- Reuse the owning suite and real production helpers; do not create parallel test-only business logic.
- AST extraction must include newly called dependencies. Register mocks before asserting zero calls.
- Update prompt fixtures when navigation changes, while retaining all identity, persistence and evidence assertions.
- Keep Live requests and operational records outside offline fixtures. Verify no-write/no-mutation boundaries.
- Preserve returned arrays and dictionaries on both hosts, including empty/single collections and legacy records.
- Run focused checks after each substantive edit; run the complete two-host gate before claiming integration success.
- Record the actual discovered totals, failure details and revisions. Do not report an interrupted or partial run as passed.

## Validation Results

TODO 60 repair: on 11 October 2026, fresh full discovery across all thirty suites passed **1000/1000 on each host**:
PowerShell 7.6.6 and Windows PowerShell 5.1.26100.9444, with zero failed/skipped/unrun checks. The repair changes
test assertions only: CompletionSafety and AttemptHistory now reuse `Test-AttemptEvidenceEqual` instead of comparing
independently serialised dictionary JSON. Field checks and count assertions remain; dictionary keys, case-sensitive
text, nested values and ordered arrays are still validated. Existing persistence tamper-rejection tests also pass.
Production history/completion logic and operational data were not changed. This supersedes the historical failures
below as the current offline gate; it does not approve terminal rendering, Live permissions or physical imaging.

Initial setup/archive revision: full discovery before the final migration-boundary follow-up ran **998 checks**
per host. Windows PowerShell 5.1.26100.9444 passed **998/998**; PowerShell 7.6.6 passed **994/998**. The four PS7
failures are existing CompletionSafety JSON key-order comparisons at lines 226, 296 and 310, with matching evidence
values and different property order. No history/completion assertions were changed; TODO 60 includes this failure
family. That historical run was not a clean full two-host gate; the completed repair is recorded above.

After the final follow-up, fresh focused WorkflowRehearsal, InterruptedWrite, TenantBinding, StorageRoot and
LocalCheckpoint runs passed **282/282 on each host**, with zero failures/skips/unrun checks. Coverage exercises
the actual startup main block, failed Live/local recovery gates before resume/site prompts, fresh site setup without
reconnection, default archive cancellation, lowercase confirmation, save failures, real current/previous file moves,
retention of other state, partial-move recovery blocking, same-second unique archives and fallback migration refusal.
File tests use disposable storage; Graph and physical work remain mocked. Actual narrow/wide terminal review remains open.

The user separately confirmed successful Live connection and appropriate rejection in a tenant without the required
device group. This closes the specific startup URI retry item, not wider tenant permissions, mutations or pilot approval.

The subsequent Live startup investigation changes the initial `/me` SDK request to a relative path and adds
stage-specific, privacy-preserving diagnostics. Following the VS Code crash, fresh focused runs of TenantBinding,
GraphTransport and WorkflowRehearsal passed **155/155 on each host**: PowerShell 7.6.6 and Windows PowerShell
5.1.26100.9444, with zero failed/skipped/unrun checks. Coverage includes the exact relative `/me` request, identity
and organisation URI failures, wrapped inner URI exceptions, HTTP 401/403 guidance, browser-stage failure, safe
disconnect failure and cleared session state. It also checks script `-Verbose` support, unavailable HTTP logging,
no automatic retry on URI failure and no query/response-body leakage. PSScriptAnalyzer reported zero findings across
the script and all thirty suites using the established exclusions. An offline SDK 2.29.1
probe confirmed relative preparation preserves the public-cloud authority; its absolute probe was inconclusive
because of synthetic setup errors. No authentication or tenant request was performed by the assistant. The user's
subsequent successful connection confirmation is recorded above; these offline checks alone did not establish it.

The subsequent single-character paging revision passes all 48 focused WorkflowRehearsal checks. Fresh full discovery
passes 980/980 on Windows PowerShell 5.1, but 972/980 on PowerShell 7: eight existing AttemptHistory comparisons at
line 109 differ only in JSON dictionary-key order. That full gate is not clean; TODO 60 tracks the outstanding test
repair. The history implementation and assertions were not changed for the shortcut request. The result below is
the preceding implementation's recorded gate, not a clean rerun of this revision.

On 11 October 2026, full discovery across all thirty suites passed **980 of 980 checks on each fresh host**:
PowerShell 7.6.6 and Windows PowerShell 5.1.26100.9444. Both runs had zero failures, skipped or unrun checks.
PSScriptAnalyzer reported zero findings across the main script and all thirty test files using the established
`PSUseSingularNouns` and `PSAvoidUsingWriteHost` exclusions. Editor diagnostics were clear and both Markdown files
passed lint with only the established MD013 exception.

The usability checks cover sequential data-driven routes, session headers/About, default/explicit returns, retained
feedback, repeated tracked actions and maintenance, direct Outstanding hand-off, new-device defaults, early conflicts,
removed/cross-identifier rules and final identity race rejection. Guide checks cover wrapping, first/last Previous,
N/P step collisions, details and resize; bench tests cover linear fallback ordering and real Demo action/reload flows.
Actual console cursor placement is still a visual acceptance item, not established by mocked calls. Prior checks exposed invalid choice/
numeric input falling through the shared validator's switch; labelled loop continuation now re-prompts correctly.
Actual narrow/wide terminal visual acceptance remains pending. No Live authentication, tenant requests, mutations
or physical imaging were performed. Shared remains disabled; this is not production approval or enforced-policy
certification. The preceding 961-check usability and 945-check backend gates are historical evidence only.

## Historical Validation Notes

The former README validation narrative is consolidated below for traceability, not as current acceptance criteria.
Per-file counts, capabilities and backlog statements describe the revision recorded at that time. Use the current
catalogue, discovery output and validation result above for present behaviour and release decisions.

| Date/revision   | Executed checks on each supported host   | Main change or repair                                                                                              |
| --------------- | ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| 7 October 2026  | 312                                      | Initial normal-workflow and two-device bench CLI baseline.                                                         |
| 7 October 2026  | 384 discovered; 382 passed before repair | Two repeated bench harness blocks lacked the extracted identity validator.                                         |
| 7 October 2026  | 387, then 391 passed                     | Repaired both harness setups; added retained-record serial reassignment and swap checks.                           |
| 8 October 2026  | 474 passed across 20 files               | Fresh mutation targets, scanner disambiguation, completion/dependent evidence and typed saved-state validation.    |
| 8 October 2026  | 718 passed across 25 files               | Complete Graph evidence, sticky storage roots/receipts, bench links, accepted sync evidence and tenant binding.    |
| 8 October 2026  | 875 passed across 29 files               | Detached multi-file checkpoints, recovery inspection, durable append-only attempt history and zero-byte refusal.   |
| 8 October 2026  | 883 passed across 30 files               | Deterministic common installed Graph version/manifest selection instead of module-name imports.                    |
| 11 October 2026 | 933 passed across 30 files               | Repaired absent legacy history counting and safe Graph URI forwarding; Group Tag uses one guarded v1.0 REST write. |
| 11 October 2026 | 945 passed across 30 files               | Twelve detached initial migration-preview checks, with no actual migration or Shared activation.                   |

The 933/945 gates used fresh PowerShell 7.6.6 and Windows PowerShell 5.1.26100.9444, with zero failed, skipped or
unrun checks and zero PSScriptAnalyzer findings across source plus all thirty files using the established exclusions.
Earlier counts include the intentionally retained repeated bench block: executed checks are not unique scenarios.
The 945 result supersedes 933 only for that revision; neither approves subsequent changes or production use.

Notable rehearsal findings retained for maintainers:

- A sole dictionary-backed device was incorrectly indexed; selection now preserves its array container.
- Wrapped scalar dates became property maps after JSON reload; the normaliser now retains scalars/ISO timestamps
  and empty/single/multiple evidence arrays, including null entries required for validation on Windows PowerShell.
- Ordered-dictionary conversion lost main-menu additions; the live record container now matches parameter types.
- New AST-extracted callees must be loaded in every fixture, including repeated setup blocks. Never drop identity,
  submission or verification assertions merely to make a harness pass.
- String `"false"` must not become completed evidence. Optional absent legacy fields remain compatible; malformed
  typed evidence and conflicting identities fail closed without writes or an empty-state substitution.
- A receipt prevents normal sync replay after server acceptance; death before receipt persistence remains a gap.
- History snapshots become durable only after save. A handler that does not return a result adds no invented attempt.
- CLI copies isolate and restore `LOCALAPPDATA` and prompt globals; source test runs must not touch operational roots.

Historical synthetic ConstrainedLanguage probes used fresh Windows PowerShell 5.1 children for directory matching,
eligibility/ranking/paging, primary-user evidence and polling, Group Tag/membership/deletion handlers, physical and
post-login steps, recovery, normalisation, locks, staged writes and transport retry/replay guards. Waits, prompts and
Graph were stubbed. Isolated CLI probes loaded the definitions, initialised Demo, reached the menu and exited;
focused N/O/P rehearsal persisted negative application evidence and blocked assignment until shutdown confirmation.
These did not exercise a complete physical build or certify enforced corporate policy, real-time scheduling or SDK
error shapes. The repeatable suites above are the present gate; one-off probes are historical evidence only.

Historical SDK inspection imported Authentication and Enrollment 2.29.1 by exact manifest and read back zero SDK
retries/60-second timeout without authentication. Name-based imports later exposed PS7 2.29.1 versus PS5 Enrollment
2.27.0 with mixed Authentication dependencies. Deterministic selection subsequently chose consistent 2.29.1 on PS7
and 2.27.0 on PS5 in fresh local probes. No modules were installed, upgraded or removed and no API calls occurred.
This explains why a common version, exact manifests, Authentication-first loading and conflicting-version refusal
are now required; it is not tenant permission acceptance or certification of every installed combination.

### Shared Development Contract

These are disconnected development helpers, not runtime commands. Shared remains disabled. Legacy definitions
without `storage` retain Local behaviour; invalid/unknown modes are refused before operational storage or prompts.

| Runtime contract field | Intended meaning; not an implemented backend guarantee                                      |
| ---------------------- | ------------------------------------------------------------------------------------------- |
| `sharedDataRoot`       | Approved Shared network root.                                                               |
| `sharedBenchId`        | Stable physical-bench identifier.                                                           |
| `lockTimeoutSeconds`   | Age before considering reviewed stale-lock recovery; no Local expiry or automatic takeover. |
| `requireAtomicWrites`  | Backend-qualified temporary write/atomic replacement and durable recovery requirement.      |

- `Start-SharedStoreReservation` requires an existing isolated root and exclusively creates an ownership-token
  reservation. Readers/writers and cleanup verify ownership; no network lease/fencing is claimed.
- `Get-SharedStoreSnapshot` reads device/bench/audit collections in one envelope. Missing initial storage has revision
  zero; empty, malformed or interrupted content fails closed.
- `Write-SharedStoreSnapshot` requires the current revision, validates typed identities/status and bench links,
  preserves record IDs/serials and exact attempt-history context, and rejects audit/history-prefix alteration.
  Structural comparison ignores dictionary key order but preserves entry/array order, key casing and text values.
  Active or removed serial reassignment/swaps are refused; allowed metadata changes retain validation. The proposed
  envelope remains detached. Staged writes retain recovery files after faults; readers must hold the reservation.
- `Get-SharedStoreRecoveryInspection` checks target/pending/previous independently and reports presence, validity,
  revision, counts and validated content. Marker presence is not commit evidence. Ownership is checked before and
  after reads. `ReviewRequired` identifies unresolved evidence; `RecoveryApproved` is always false. No promotion,
  deletion, repair or replay occurs and highest revision must not be automatically selected.
- `Get-SharedStoreMigrationPreview` accepts an already captured/normalised source and a reserved pristine destination:
  revision zero and no committed snapshot, collections or recovery evidence. It returns detached nested evidence,
  revisions and counts; `ReviewRequired` is true and `MigrationApproved` false. It does not capture consistent local
  files, merge stores, rewrite identities or write/approve a migration.

Historical Shared additions included 22 snapshot cases, 22 strict schema/history cases, eight recovery-inspection
cases and twelve initial-preview cases. The actual Demo CLI rejects configured Shared before prompts or creation.
No SMB, OneDrive, disconnect, distributed/malicious-writer, enforced-policy or physical power-loss qualification
was performed. Backend approval, atomic replacement, distributed ownership, permissions, reviewed local migration,
runtime integration and multi-technician disconnect/recovery acceptance remain prerequisites to activation.

The operator selected Local-only initial imaging on 11 October 2026. Historical offline TODOs were completed and
removed from the active list; tenant acceptance (31), approved physical pilot (10) and deferred Shared qualification
(6) remain outstanding. Offline probes made no Live authentication, tenant requests, mutations or physical builds.
