<!-- omit from toc -->

# Autopilot Express Development

This file owns development guidance, change management, the roadmap and tracked TODOs moved from the README.
For technician setup and operation, see [README.md](README.md). Test procedures, acceptance criteria and historical
validation evidence are maintained in [TESTING.md](TESTING.md). Recorded offline results do not approve Live use.

## Contents

- [Contents](#contents)
- [Implementation Notes](#implementation-notes)
- [Development and Extension](#development-and-extension)
- [Version Control and Change Management](#version-control-and-change-management)
- [Roadmap](#roadmap)
- [Tracked Tasks](#tracked-tasks)
- [Future Decisions](#future-decisions)

## Implementation Notes

The following status and maintenance notes were moved from the README's former Not yet complete section.
Implemented behaviour is distinguished from work that still requires acceptance.

- Live mode requires valid structural Graph and workflow settings before authentication. After authentication, it discovers the tenant organisation and available Autopilot profiles, and validates the operator-selected pre-provisioning group. The selections apply to the current session and are not written back to configuration.
- Pre-provisioning, post-login and recovery reset/reimage guidance are implemented. External ZENworks, CMDB, handover and disposal guidance is now displayed after completed final ownership; integrations and handoff confirmation tracking remain out of scope for this delivery.
- Final-user selection supports exact username/UPN and order-independent name-fragment matching. Live candidate discovery follows bounded Graph result pages. After an exhaustive empty literal name search, it automatically offers bounded approximate suggestions. Results require explicit technician selection and Live account revalidation. Prefix retrieval still limits which candidates can be discovered; suggestions do not guarantee every typo match.
- Polling for other Graph mutations, broader Pester coverage, and complete operator documentation remain implementation work. Primary-user, Group Tag and pre-provisioning membership post-write polling and managed-device deletion polling are implemented. Bounded GET transport retries and throttling handling are implemented; live validation remains open.
- The older `autopilot-express.txt` describes an earlier scaffold and is not authoritative. Its prominent historical notice directs operators to the current script and operator guide; its original draft is retained for traceability.

The active script's header and annotated menu notes now describe the implemented manifest-driven workflow,
delegated scopes and current Graph operations. They no longer suggest Autopilot-record deletion, manager inference,
remote manufacturer commands or automated application-baseline inspection. Enhancement statuses distinguish bounded
name suggestions, offline tests and local reservations from the still-pending Live pilot and shared transactions.

Unused feature flags, vendor command defaults and their legacy per-device lock setting were retired from the internal
configuration. The uncalled legacy per-device lock helpers, phase lookup and previous-menu pause helper were also
removed after checking references. No workflow handler or operator menu option was removed. Enabled actions still
come from the manifest; the active local session reservation, offline shared-store prototype, verification polling
and Graph transport controls remain intact. Historical draft and review files are unchanged. Console logging remains
timestamped information-stream output, not a durable transcript; the header now states that limitation explicitly.

## Development and Extension

| Change                                | Owning source                                               | Validation to repeat                                                             |
| ------------------------------------- | ----------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Titles, spacing and feedback          | `Show-ScriptScreen`, `Add-ScreenFeedback`, screen functions | Workflow rehearsal and actual narrow/wide console checks.                        |
| About content                         | Editable text in `Show-AboutScript`                         | Display and immediate 0-return.                                                  |
| Menu/navigation                       | `Show-MainMenu`, main dispatcher, device/bench loops        | All entry/return/cancel/default paths and retained records.                      |
| Organisation, modules/scopes, scanner | Runtime JSON                                                | Configuration/identity guards, scanner/SDK tests and approved tenant acceptance. |
| Workflow/order/prerequisites          | Manifest and action handler                                 | Manifest, eligibility, completion, physical/recovery and handler suites.         |
| Evidence/persistence                  | Record/checkpoint/writer helpers                            | Legacy/history/identity and failure/restart tests on both hosts.                 |

Keep the checklist as the governing sequence. Never mark unverified mutations Verified, weaken identity guards or
Live/Demo isolation, or add out-of-scope integrations without approval. Initialise properties, preserve array/dictionary
shape on both hosts and document compatibility/migration before format changes. Use ASCII/EN-AU, accessible non-colour
states and default-labelled input. Future Guided mode must use TechnicianConfirmed, not GraphVerified.
`0` is navigation, not a workflow ID. Next-step/device-switch commands dynamically avoid custom-ID collisions.

## Version Control and Change Management

Review scopes/RBAC, target selection, prerequisites, evidence truthfulness, persistence compatibility, privacy and
operator documentation. Run [the documented checks](TESTING.md) before proposing release. Do not commit operational
data, credentials or tenant screenshots. Preserve others' edits; never use a destructive Git reset to discard them.
Documentation/configuration must describe current code, not a historical milestone. Record approved scope changes
before adding out-of-scope integrations; never edit completed evidence to bypass a workflow gate.

## Roadmap

Execute the active backlog in this order:

1. Keep the completed screenshot-review implementation and its unit coverage/documentation in sync.
2. Repeat the full cross-host offline regression/static gates after further changes.
3. Complete the technician's final review before accepting actual narrow/wide terminal visual layouts.
4. Accept real SDK/tenant permissions under explicit authentication/read approval.
5. Approve and execute one Local-only Live physical pilot; review complete evidence before bulk imaging.
6. Qualify Shared only when resumed under an approved backend decision; it is deferred for initial imaging.

The 11 October screenshot-review code is implemented; actual terminal visual acceptance remains outstanding.
Recorded regression results, including the historical 980-check screenshot revision and subsequent 1000-check gate,
are in [Validation Results](TESTING.md#validation-results), not evidence of acceptance of later source changes.
Current [Operation instructions](README.md#operation) describe the implemented menu.
Preserving old main-menu numbers was rejected; the implemented order is 1 Bench, 2 New Device, 3 Tracked Device,
4 Outstanding Work, 5 Maintain Device List, 6 Statistics, 7 Site, 8 About, 9 Enhancements, 10 Archive Session, 0 Exit.
Use a single ordered menu definition with stable internal action IDs to derive displayed choices and dispatch,
rather than keeping independent numbering and routing tables.

## Tracked Tasks

- [x] TODO 49: Sequential main-menu numbers and data-driven ordering/routing; updated affected CLI test inputs.
- [x] TODO 50: Session-wide Demo/Live header, one blank row below it, combined site/Graph line and no redundant title.
- [x] TODO 51: Bench results below command entry, separated and retained; actual cursor layout awaits TODO 48.
- [x] TODO 52: Window-height guide paging with persistent header, next/previous/return and readable step details.
- [x] TODO 53: Preserve all editable new-device values as defaults after declining confirmation.
- [x] TODO 54: Validate serial/CI conflicts during field entry, allow correction and retain final defensive validation.
- [x] TODO 55: Tracked-device 8 Next/9 Select Device and distinct current-device, evidence-labelled outcome banners.
- [x] TODO 56: Open the selected Outstanding Work device directly in Tracked Device without reselection.
- [x] TODO 57: Maintain multiple devices in one visit, including after invalid/blocked status changes.
- [x] TODO 58: Existing/new tests, synchronised docs and fresh full two-host/lint gates for this revision.
- [x] TODO 59: Single-character guide paging: `>` Next and `<` Previous, then Enter; 48 focused checks pass.
- [x] TODO 60: Replaced order-sensitive history/completion assertions with the existing structural evidence comparer; fresh full discovery passes 1000/1000 on both hosts.
- [x] TODO 61: User confirmed successful Live tenant connection and appropriate rejection when the required device group is absent; broader tenant/physical acceptance remains open.
- [x] TODO 64: Immediate Initial setup and testing header; gate resume/site setup behind successful Live checks or Demo selection.
- [x] TODO 65: Current-user/current-mode saved-session archive selection, default No then CLEAR, retained evidence and fresh setup without reconnection.
- [x] TODO 66: Offline startup/archive/recovery tests and documentation; focused 282/282 on both hosts, followed by the clean 1000/1000 full gate after TODO 60 repair.
- [ ] TODO 67: Enforce action-specific Live read-back evidence at result creation and persistence; reject unsupported Verified claims.
- [ ] TODO 68: Automatically requery Autopilot after upload confirmation; bounded absence remains Submitted, read errors fail closed.
- [ ] TODO 69: Reconcile complete Autopilot serial and direct group-membership discovery; enforce assigned security-group eligibility before mutations.
- [ ] TODO 70: Expand existing verification suites for delayed propagation, malformed/partial reads, no-op verification and rejected completion evidence.
- [ ] TODO 71: Synchronise verification guidance and run fresh full two-host, static-analysis and documentation gates for the current revision.
- [ ] TODO 48: Technician final narrow/wide terminal visual review; do not infer acceptance from mocked output.
- [ ] TODO 31: Confirm real SDK/tenant permissions and acceptance requirements under explicit authentication/read approval.
- [ ] TODO 10: Approve and execute the Local-only Live pilot; accept the complete physical checklist before bulk imaging.
- [ ] TODO 6: Shared storage implementation is deferred for initial imaging; resume only with an approved backend decision.

TODO 48 is paused pending the technician's specific feedback. Tenant acceptance was explicitly deferred; the
confirmed target names are SJOG Hybrid Join and Intune-Autopilot-PreProvisioning, not completed permission acceptance.
The Local pilot still requires separate approval. Shared remains deferred for initial imaging.
Detailed regression and visual criteria are in [Screenshot Review Backlog](TESTING.md#screenshot-review-backlog).

## Future Decisions

Version 1 requires a future tenant-configured shared data-store option, such as a network share path in the runtime
configuration. The design must support simultaneous technicians at one or more sites and benches without lost or
overwritten device, journal, audit, or bench updates. This requires a documented storage contract, atomic writes,
cross-process locking, collision handling, and recovery from interrupted writes before shared storage is enabled.
This requirement does not override the Local-only initial-imaging decision or authorise Shared activation.

Optional future work includes all-machine audit/search, build certificates, CMDB/ITSM integration, broader name
discovery, permission-aware UI and remote/offline workflows. These are proposals, not delivered capabilities or
blockers for agreed Local-only scope. Guidance-only external handoffs remain external. Offline success/scheduling
does not approve Live authentication or mutations; one complete accepted physical build is required before scaling.

Guide paging is implemented. Main-menu Enter opening the bench rather than Exit,
and a longer bench message-history feature, remain separate decisions; current defaults and five-line retention
remain unchanged until approved. Offline results do not replace visual, tenant or physical-device acceptance.
