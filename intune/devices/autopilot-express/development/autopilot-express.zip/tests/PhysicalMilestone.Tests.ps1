<#
.SYNOPSIS
    Checks physical guidance, evidence and manifest prerequisite gates.
.DESCRIPTION
    Extracts the real handlers, dispatcher, eligibility and result writer without
    starting the CLI. Prompts are mocked; no physical or tenant actions occur.
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('Get-ManifestActionStepId', 'Get-LiveTenantBinding', 'New-OperationResult', 'ConvertTo-NormalisedValue', 'Invoke-StepConfirmPhysicalMilestone', 'Invoke-StepConfirmRecoveryReadiness', 'ConvertTo-RecordDate', 'Enter-DeviceRecoveryMode', 'Invoke-AutopilotManifestStep', 'Write-ManifestStepResult', 'Test-ManifestStepAttempted', 'Test-ManifestStepCompleted', 'Test-CompletionStateComplete', 'Get-ManifestStepPrerequisiteIds', 'Test-ManifestStepEligibility', 'Get-EligibleManifestSteps', 'Get-DispatchBlockingManifestSteps', 'Test-DeviceReadyForDispatch', 'Test-ManifestDependencyGraph', 'Resolve-DeviceSelection', 'Select-DeviceFromRecords', 'ConvertTo-OptionalInteger', 'Update-DeviceStatus')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if ($null -eq $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function Read-ValidatedInput { param($Prompt, $Default, $Type, $Choices) throw ('Unexpected prompt: {0}, {1}, {2}, {3}' -f $Prompt, $Default, $Type, ($Choices -join ',')) }
    foreach ($functionName in @('Show-ScriptScreen', 'Show-ReturnToMainMenu')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function Show-ChecklistHandoffGuide { param($Device) if (-not $Device.Serial) { throw 'Guide requires a device serial' } }
    function Resolve-LiveManagedDeviceBySerial { param($Serial) throw ('Unexpected lookup: {0}' -f $Serial) }
    function Write-AutopilotExpressLog { param($Message, $Level) throw ('Unexpected log: {0}: {1}' -f $Level, $Message) }
    function Write-UserDeviceRecords { param($Records) throw ('Unexpected save of {0} records' -f @($Records).Count) }
    function Get-NextStepId { param($Device) if ($Device.Serial) { return 'G' } }
    function Get-EnabledManifestSteps { return $script:manifestSteps }
    function Get-MgContext { throw 'Unexpected Graph context lookup.' }
    $script:fixtureTenantId = '11111111-2222-3333-4444-555555555555'
    $manifestPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.manifest.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $script:manifestSteps = @($manifest.steps | ForEach-Object {
            @{ Id = $_.id; ActionName = $_.actionName; DisplayName = $_.displayName; PrerequisiteStepIds = @($_.prerequisiteStepIds); ActivationRequirement = if ($_.activationRequirement) { $_.activationRequirement } else { 'None' } }
        })
}

Describe 'Semantic safety gates with renamed step labels' {
    BeforeEach {
        $script:originalManifestSteps = $script:manifestSteps
        $script:manifestSteps = ConvertTo-NormalisedValue -Value $script:originalManifestSteps
        $labelMap = @{ A = 'Identity'; B = 'Cleanup'; F = 'Unblock'; Q = 'CloseRecovery'; C = 'A' }
        foreach ($definition in $script:manifestSteps) {
            if ($labelMap.ContainsKey($definition.Id)) { $definition.Id = $labelMap[$definition.Id] }
            $definition.PrerequisiteStepIds = @($definition.PrerequisiteStepIds | ForEach-Object {
                    if ($labelMap.ContainsKey($_)) { $labelMap[$_] } else { $_ }
                })
        }
        $script:Runtime = @{ IsDemoMode = $false; ModeDisplayName = 'Live' }
        $script:GraphSession = @{ Connected = $true; IsSimulated = $false; TenantId = $script:fixtureTenantId }
        Mock Get-MgContext { return @{ TenantId = $script:fixtureTenantId } }
        $script:device = @{
            TenantId = $script:fixtureTenantId
            Serial = 'RENAMED-01'; AutopilotDeviceId = 'ap-one'; ManagedDeviceId = ''; IntuneDeviceName = ''
            Steps = @{}; RecoveryActive = $true; RecoveryStartedAt = (Get-Date).AddMinutes(-5)
            RecoveryReason = 'Synthetic failure'; RecoveryHistory = @(); Status = 'in-progress'; IsCompletionVerified = $false
        }
        foreach ($definition in $script:manifestSteps) {
            if ($definition.ActivationRequirement -eq 'None') { $script:device.Steps[$definition.Id] = @{ CompletionState = 'Verified' } }
        }
        $script:device.Steps.Unblock = @{ CompletionState = 'Submitted'; Timestamp = (Get-Date).AddMinutes(-3) }
        Mock Read-ValidatedInput { return 'Y' }
        Mock Write-Host {}
        Mock Write-AutopilotExpressLog {}
        Mock Resolve-LiveManagedDeviceBySerial { return $null }
    }

    AfterEach { $script:manifestSteps = $script:originalManifestSteps }

    It 'requires an Autopilot identifier for the renamed identity action but not an unrelated A label' {
        $script:device.AutopilotDeviceId = ''
        Test-ManifestStepCompleted -Device $script:device -StepId Identity | Should -BeFalse
        Test-ManifestStepCompleted -Device $script:device -StepId A | Should -BeTrue
    }

    It 'allows renamed identity and cleanup actions during recovery but blocks unrelated A' {
        foreach ($stepId in @('Identity', 'Cleanup')) {
            $step = $script:manifestSteps | Where-Object Id -eq $stepId
            (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeTrue
        }
        $step = $script:manifestSteps | Where-Object Id -eq A
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeFalse
    }

    It 'uses the renamed unblock and cleanup steps for readiness evidence and guidance' {
        $step = $script:manifestSteps | Where-Object Id -eq CloseRecovery
        $result = Invoke-StepConfirmRecoveryReadiness -Device $script:device -StepDefinition $step
        $result.Success | Should -BeTrue
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        $result.Summary | Should -BeLike '*restart preparation from Cleanup*'
        Should -Invoke Resolve-LiveManagedDeviceBySerial -Times 1 -Exactly
    }

    It 'does not accept evidence under the old unblock label as current-cycle evidence' {
        $script:device.Steps.F = $script:device.Steps.Unblock
        $script:device.Steps.Remove('Unblock')
        $step = $script:manifestSteps | Where-Object Id -eq CloseRecovery
        $result = Invoke-StepConfirmRecoveryReadiness -Device $script:device -StepDefinition $step
        $result.CompletionState | Should -Be 'Blocked'
        $result.Summary | Should -BeLike '*Unblock first*'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'offers close-out instead of replaying a renamed submitted unblock' {
        $eligibleIds = @(Get-EligibleManifestSteps -Device $script:device | ForEach-Object Id)
        $eligibleIds | Should -Contain 'CloseRecovery'
        $eligibleIds | Should -Not -Contain 'Unblock'
    }

    It 'archives all prior evidence and retains only semantic identity unblock and close-out records' {
        $step = $script:manifestSteps | Where-Object Id -eq CloseRecovery
        $result = New-OperationResult -ActionName $step.ActionName -Success $true -CompletionState TechnicianConfirmed
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        @($script:device.Steps.Keys).Count | Should -Be 3
        $script:device.Steps.Identity.CompletionState | Should -Be 'Verified'
        $script:device.Steps.Unblock.CompletionState | Should -Be 'Submitted'
        $script:device.Steps.CloseRecovery.CompletionState | Should -Be 'TechnicianConfirmed'
        $script:device.Steps.ContainsKey('A') | Should -BeFalse
        $script:device.RecoveryHistory[0].Steps.A.CompletionState | Should -Be 'Verified'
        $script:device.RecoveryActive | Should -BeFalse
        (Get-EligibleManifestSteps -Device $script:device | Select-Object -First 1).Id | Should -Be 'Cleanup'
    }

    It 'enters recovery using renamed identity and removes renamed recovery results without losing history' {
        $script:device.RecoveryActive = $false
        $script:device.Steps.CloseRecovery = @{ CompletionState = 'TechnicianConfirmed' }
        Enter-DeviceRecoveryMode -Device $script:device
        $script:device.RecoveryActive | Should -BeTrue
        $script:device.Steps.ContainsKey('Unblock') | Should -BeFalse
        $script:device.Steps.ContainsKey('CloseRecovery') | Should -BeFalse
        $script:device.Steps.Identity.CompletionState | Should -Be 'Verified'
        $script:device.RecoveryHistory[0].Steps.Unblock.CompletionState | Should -Be 'Submitted'
        $script:device.RecoveryHistory[0].Steps.CloseRecovery.CompletionState | Should -Be 'TechnicianConfirmed'
    }

    It 'rejects missing or ambiguous action roles before changing recovery state' {
        $script:device.RecoveryActive = $false
        $before = $script:device | ConvertTo-Json -Depth 100 -Compress
        $script:manifestSteps = @($script:manifestSteps | Where-Object ActionName -ne ResolveAutopilotDevice)
        { Enter-DeviceRecoveryMode -Device $script:device } | Should -Throw '*unique manifest step*'
        ($script:device | ConvertTo-Json -Depth 100 -Compress) | Should -Be $before
        $script:manifestSteps = @($script:originalManifestSteps) + , $script:originalManifestSteps[0]
        { Get-ManifestActionStepId -ActionName ResolveAutopilotDevice } | Should -Throw '*unique manifest step*'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }
}

Describe 'Guided physical milestone workflow' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false; ModeDisplayName = 'Live' }
        $script:GraphSession = @{ Connected = $true; IsSimulated = $false; TenantId = $script:fixtureTenantId }
        Mock Get-MgContext { return @{ TenantId = $script:fixtureTenantId } }
        $script:device = @{ TenantId = $script:fixtureTenantId; Serial = 'SERIAL1'; AutopilotDeviceId = 'autopilot-1'; Steps = @{}; RecoveryActive = $false; Status = 'new'; LastUpdatedAt = $null; LastUpdatedBy = '' }
        foreach ($stepId in @('A', 'B', 'C', 'E')) { $script:device.Steps[$stepId] = @{ CompletionState = 'Verified' } }
        Mock Read-ValidatedInput { return 'Y' }
        Mock Write-Host {}
    }

    It 'loads an acyclic manifest with all physical actions enabled' {
        { Test-ManifestDependencyGraph -Steps $script:manifestSteps } | Should -Not -Throw
        @($manifest.steps | Where-Object { $_.id -in @('K', 'L', 'M') -and $_.enabled }).Count | Should -Be 3
    }

    It 'selects the sole dictionary-backed device rather than its first property' {
        Mock Read-ValidatedInput { return '1' }
        $records = @{ Value = @($script:device) }
        $selected = Select-DeviceFromRecords -Records $records -Purpose 'autopilot'
        $selected.Serial | Should -Be 'SERIAL1'
        $selected.Steps.A.CompletionState | Should -Be 'Verified'
    }

    It 'does not complete a device when no next step is eligible but required work remains' {
        Mock Get-NextStepId { return $null }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        $result = New-OperationResult -ActionName $step.ActionName -Success $false -CompletionState Submitted
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        $script:device.Status | Should -Not -Be 'completed'
        (Test-DeviceReadyForDispatch -Device $script:device).Ready | Should -BeFalse
    }

    It 'completes a device only when every active required action is complete' {
        foreach ($definition in $script:manifestSteps) {
            if ($definition.ActivationRequirement -eq 'None') { $script:device.Steps[$definition.Id] = @{ CompletionState = 'TechnicianConfirmed' } }
        }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'J' }
        $result = New-OperationResult -ActionName $step.ActionName -Success $true -CompletionState TechnicianConfirmed
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        $script:device.Status | Should -Be 'completed'
        $script:device.CompletedAt | Should -Not -BeNullOrEmpty
        (Test-DeviceReadyForDispatch -Device $script:device).Ready | Should -BeTrue
    }

    It 'clears stale completion metadata when a required action becomes incomplete' {
        $script:device.Status = 'completed'
        $script:device.CompletedAt = Get-Date
        $script:device.CompletedBy = 'Previous technician'
        $script:device.IsCompletionVerified = $true
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        $result = New-OperationResult -ActionName $step.ActionName -Success $false -CompletionState Submitted
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        $script:device.Status | Should -Be 'in-progress'
        $script:device.CompletedAt | Should -Be ([DateTime]::MinValue)
        $script:device.CompletedBy | Should -Be ''
        $script:device.IsCompletionVerified | Should -BeFalse
    }

    It 'rejects manual completed status while required work remains' {
        Mock Clear-Host {}
        Mock Read-Host { return '' }
        Mock Select-DeviceFromRecords { return $script:device }
        Mock Read-ValidatedInput { return 'completed' } -ParameterFilter { $Prompt -like 'Enter status*' }
        Mock Read-ValidatedInput { return 'new' } -ParameterFilter { $Prompt -eq 'Status' }
        Mock Read-ValidatedInput { return '0' } -ParameterFilter { $Prompt -like '1. Maintain another*' }
        Mock Write-UserDeviceRecords {}
        Update-DeviceStatus -Records @{ Value = @($script:device) }
        $script:device.Status | Should -Be 'new'
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*Cannot mark this device completed*' }
    }

    It 'allows manual completed status after all normal actions are complete' {
        Mock Clear-Host {}
        Mock Read-Host { return '' }
        foreach ($definition in $script:manifestSteps) {
            if ($definition.ActivationRequirement -eq 'None') { $script:device.Steps[$definition.Id] = @{ CompletionState = 'TechnicianConfirmed' } }
        }
        Mock Select-DeviceFromRecords { return $script:device }
        Mock Read-ValidatedInput { return 'completed' } -ParameterFilter { $Prompt -like 'Enter status*' }
        Mock Read-ValidatedInput { return '0' } -ParameterFilter { $Prompt -like '1. Maintain another*' }
        Mock Write-UserDeviceRecords {}
        Mock Write-AutopilotExpressLog {}
        Update-DeviceStatus -Records @{ Value = @($script:device) }
        $script:device.Status | Should -Be 'completed'
        Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly
    }

    It 'dispatches imaging guidance with the agreed Y default and technician evidence' {
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        $result.Data.ChecklistVersion | Should -Be '1.4'
        $result.Data.ChecklistSteps | Should -Be @(6, 7, 8, 9, 10)
        Should -Invoke Read-ValidatedInput -Times 1 -Exactly -ParameterFilter { $Default -eq 'Y' -and $Type -eq 'Choice' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*Windows key five times*' }
    }

    It 'blocks profile validation until imaging and OOBE are confirmed' {
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'D' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeFalse
        $script:device.Steps.K = @{ CompletionState = 'TechnicianConfirmed' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeTrue
    }

    It 'blocks reseal before profile validation without prompting' {
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'L' }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step).CompletionState | Should -Be 'Blocked'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'records reseal against checklist step 13 after profile confirmation' {
        $script:device.Steps.D = @{ CompletionState = 'TechnicianConfirmed' }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'L' }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        $result.Data.ChecklistSteps | Should -Be @(13)
    }

    It 'records boot-to-sign-in against checklist step 14 after reseal' {
        $script:device.Steps.L = @{ CompletionState = 'TechnicianConfirmed' }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'M' }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step).Data.ChecklistSteps | Should -Be @(14)
    }

    It 'blocks technician assignment until boot-to-sign-in is confirmed' {
        $script:device.Steps.D = @{ CompletionState = 'TechnicianConfirmed' }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'G' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeFalse
        $script:device.Steps.M = @{ CompletionState = 'TechnicianConfirmed' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeTrue
    }

    It 'keeps a negative confirmation incomplete and resumable' {
        Mock Read-ValidatedInput { return 'n' }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step
        $result.CompletionState | Should -Be 'Submitted'
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        Test-ManifestStepCompleted -Device $script:device -StepId 'K' | Should -BeFalse
    }

    It 'preserves technician evidence through a saved step JSON round trip' {
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        $saved = $script:device.Steps.K | ConvertTo-Json -Depth 10 | ConvertFrom-Json
        $saved.CompletionState | Should -Be 'TechnicianConfirmed'
        $saved.Data.ConfirmationDefault | Should -Be 'Y'
        $saved.Data.ChecklistSteps.Count | Should -Be 5
        $saved.Timestamp | Should -Not -BeNullOrEmpty
        $script:device.Status | Should -Be 'in-progress'
    }

    It 'keeps Demo confirmation simulated' {
        $script:Runtime.IsDemoMode = $true
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step).CompletionState | Should -Be 'Simulated'
    }

    It 'does not fabricate new milestones from pre-existing completed records' {
        $script:device.Steps.G = @{ CompletionState = 'LegacyCompleted' }
        Test-ManifestStepCompleted -Device $script:device -StepId 'G' | Should -BeTrue
        foreach ($stepId in @('K', 'L', 'M')) { Test-ManifestStepCompleted -Device $script:device -StepId $stepId | Should -BeFalse }
    }

    It 'blocks first sign-in until assignment, group removal and boot are complete' {
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'N' }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step).CompletionState | Should -Be 'Blocked'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
        foreach ($stepId in @('G', 'I', 'M')) { $script:device.Steps[$stepId] = @{ CompletionState = 'TechnicianConfirmed' } }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $step).Eligible | Should -BeTrue
    }

    It 'dispatches post-login milestones and persists checklist evidence: <StepId>' -TestCases @(
        @{ StepId = 'N'; Prerequisites = @('G', 'I', 'M'); ChecklistSteps = @(17) }
        @{ StepId = 'O'; Prerequisites = @('N'); ChecklistSteps = @(18, 19) }
        @{ StepId = 'P'; Prerequisites = @('O'); ChecklistSteps = @(20, 21, 22) }
    ) {
        param($StepId, $Prerequisites, $ChecklistSteps)
        foreach ($prerequisite in $Prerequisites) { $script:device.Steps[$prerequisite] = @{ CompletionState = 'TechnicianConfirmed' } }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq $StepId }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        $result.Data.ChecklistSteps | Should -Be $ChecklistSteps
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        Test-ManifestStepCompleted -Device $script:device -StepId $StepId | Should -BeTrue
        Should -Invoke Read-ValidatedInput -Times 1 -Exactly -ParameterFilter { $Default -eq 'Y' }
    }

    It 'presents ordered application guidance without claiming sync invokes remediation' {
        $script:device.Steps.N = @{ CompletionState = 'TechnicianConfirmed' }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'O' }
        [void](Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step)
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*Install only one application at a time*' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*Laptops only: Global Protect*' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*does not invoke that named remediation*' }
    }

    It 'does not unlock final ownership after negative application confirmation' {
        $script:device.Steps.N = @{ CompletionState = 'TechnicianConfirmed' }
        $script:device.Steps.I = @{ CompletionState = 'Verified' }
        Mock Read-ValidatedInput { return 'N' }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq 'O' }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step
        Write-ManifestStepResult -Device $script:device -StepDefinition $step -Result $result
        $updates = $script:manifestSteps | Where-Object { $_.Id -eq 'P' }
        $ownership = $script:manifestSteps | Where-Object { $_.Id -eq 'J' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $updates).Eligible | Should -BeFalse
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $ownership).Eligible | Should -BeFalse
    }

    It 'unlocks final ownership only after updates and shutdown confirmation' {
        $script:device.Steps.I = @{ CompletionState = 'Verified' }
        $ownership = $script:manifestSteps | Where-Object { $_.Id -eq 'J' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $ownership).Eligible | Should -BeFalse
        $script:device.Steps.P = @{ CompletionState = 'TechnicianConfirmed' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $ownership).Eligible | Should -BeTrue
    }

    It 'keeps post-login Demo confirmations simulated: <StepId>' -TestCases @(
        @{ StepId = 'N'; Prerequisites = @('G', 'I', 'M') }
        @{ StepId = 'O'; Prerequisites = @('N') }
        @{ StepId = 'P'; Prerequisites = @('O') }
    ) {
        param($StepId, $Prerequisites)
        $script:Runtime.IsDemoMode = $true
        foreach ($prerequisite in $Prerequisites) { $script:device.Steps[$prerequisite] = @{ CompletionState = 'Simulated' } }
        $step = $script:manifestSteps | Where-Object { $_.Id -eq $StepId }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $step).CompletionState | Should -Be 'Simulated'
    }
}

Describe 'Recovery close-out and restart' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false; ModeDisplayName = 'Live' }
        $script:GraphSession = @{ Connected = $true; IsSimulated = $false; TenantId = $script:fixtureTenantId }
        Mock Get-MgContext { return @{ TenantId = $script:fixtureTenantId } }
        $script:device = @{
            TenantId = $script:fixtureTenantId
            Serial = 'SERIAL1'; AutopilotDeviceId = 'auto-1'; RecoveryActive = $true
            RecoveryStartedAt = (Get-Date).AddMinutes(-10); RecoveryReason = 'Setup failed'; RecoveryHistory = @()
            Steps = @{ A = @{ CompletionState = 'Verified' }; F = @{ CompletionState = 'Submitted'; Timestamp = (Get-Date).AddMinutes(-3) }; O = @{ CompletionState = 'TechnicianConfirmed' } }
            Status = 'in-progress'; ManagedDeviceId = 'old-id'; IntuneDeviceName = 'Old name'
            TechnicianUserPrincipalName = 'old@example.invalid'; FinalPrimaryUserId = 'old-user'
            FinalPrimaryUserPrincipalName = 'old@example.invalid'; FinalPrimaryUserDisplayName = 'Old user'
            CompletedAt = [DateTime]::MinValue; CompletedBy = ''; IsCompletionVerified = $false
        }
        $script:recoveryStep = $script:manifestSteps | Where-Object { $_.Id -eq 'Q' }
        Mock Read-ValidatedInput { return 'Y' }
        Mock Write-Host {}
        Mock Write-AutopilotExpressLog {}
        Mock Resolve-LiveManagedDeviceBySerial { return $null }
    }
    It 'preserves recovery timestamps and scalar evidence through repeated JSON normalisation' {
        $saved = $script:device | ConvertTo-Json -Depth 15 | ConvertFrom-Json
        $normalised = ConvertTo-NormalisedValue -Value $saved
        $script:device = ConvertTo-NormalisedValue -Value ($normalised | ConvertTo-Json -Depth 15 | ConvertFrom-Json)
        $script:device.Steps.F.Timestamp | Should -BeOfType ([string])
        $script:device.RecoveryActive | Should -BeOfType ([bool])
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        Write-ManifestStepResult -Device $script:device -StepDefinition $script:recoveryStep -Result $result
        $reloaded = ConvertTo-NormalisedValue -Value ($script:device | ConvertTo-Json -Depth 15 | ConvertFrom-Json)
        $reloaded.RecoveryHistory[0].Timestamp | Should -BeOfType ([string])
        (ConvertTo-RecordDate -Value $reloaded.RecoveryHistory[0].Timestamp) | Should -Not -Be ([DateTime]::MinValue)
    }
    It 'preserves an evidence array of <Count> items' -TestCases @(
        @{ Count = 0; Items = @() }
        @{ Count = 1; Items = @('One') }
        @{ Count = 2; Items = @('One', 'Two') }
    ) {
        param($Count, $Items)
        $normalised = ConvertTo-NormalisedValue -Value @{ Items = $Items }
        ($normalised.Items -is [array]) | Should -BeTrue
        $normalised.Items.Count | Should -Be $Count
        $reloaded = ConvertTo-NormalisedValue -Value ($normalised | ConvertTo-Json -Depth 5 | ConvertFrom-Json)
        ($reloaded.Items -is [array]) | Should -BeTrue
        $reloaded.Items.Count | Should -Be $Count
    }
    It 'requires an unblock submission before prompting' {
        $script:device.Steps.F = $null
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep).CompletionState | Should -Be 'Blocked'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }
    It 'requires the two-minute wait without sleeping or mutating progress' {
        $script:device.Steps.F.Timestamp = Get-Date
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep
        $result.CompletionState | Should -Be 'Blocked'
        $script:device.Steps.O.CompletionState | Should -Be 'TechnicianConfirmed'
        Should -Invoke Resolve-LiveManagedDeviceBySerial -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }
    It 'rejects a timestamp from an earlier recovery cycle' {
        $script:device.Steps.F.Timestamp = (Get-Date).AddHours(-1)
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep).CompletionState | Should -Be 'Failed'
    }
    It 'blocks close-out while an Intune record remains' {
        Mock Resolve-LiveManagedDeviceBySerial { return @{ id = 'still-present' } }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep).CompletionState | Should -Be 'Blocked'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }
    It 'fails closed on a serial read error' {
        Mock Resolve-LiveManagedDeviceBySerial { throw 'Read denied' }
        (Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep).CompletionState | Should -Be 'Failed'
    }
    It 'retains progress and active recovery after negative confirmation' {
        Mock Read-ValidatedInput { return 'N' }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep
        Write-ManifestStepResult -Device $script:device -StepDefinition $script:recoveryStep -Result $result
        $script:device.RecoveryActive | Should -BeTrue
        $script:device.Steps.O.CompletionState | Should -Be 'TechnicianConfirmed'
        $script:device.RecoveryHistory.Count | Should -Be 0
    }
    It 'archives prior results and restarts from B only after confirmed readiness' {
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        $result.Data.AllowedEvidence | Should -Be 'TechnicianConfirmedInIntune'
        Write-ManifestStepResult -Device $script:device -StepDefinition $script:recoveryStep -Result $result
        $script:device.RecoveryActive | Should -BeFalse
        $script:device.RecoveryHistory[0].Steps.O.CompletionState | Should -Be 'TechnicianConfirmed'
        $script:device.Steps.O | Should -BeNullOrEmpty
        $script:device.Steps.A.CompletionState | Should -Be 'Verified'
        $script:device.Steps.F.CompletionState | Should -Be 'Submitted'
        $script:device.FinalPrimaryUserId | Should -Be ''
        $cleanup = $script:manifestSteps | Where-Object { $_.Id -eq 'B' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $cleanup).Eligible | Should -BeTrue
    }
    It 'keeps ordinary device work blocked during recovery but allows cleanup B' {
        $imaging = $script:manifestSteps | Where-Object { $_.Id -eq 'K' }
        $cleanup = $script:manifestSteps | Where-Object { $_.Id -eq 'B' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $imaging).Eligible | Should -BeFalse
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $cleanup).Eligible | Should -BeTrue
    }
    It 'clears old recovery actions on entry and retains their history' {
        $script:device.RecoveryActive = $false
        $script:device.Steps.Q = @{ CompletionState = 'TechnicianConfirmed' }
        Enter-DeviceRecoveryMode -Device $script:device
        $script:device.RecoveryActive | Should -BeTrue
        $script:device.Steps.F | Should -BeNullOrEmpty
        $script:device.Steps.Q | Should -BeNullOrEmpty
        $script:device.RecoveryHistory[0].Steps.Q.CompletionState | Should -Be 'TechnicianConfirmed'
    }
    It 'keeps Demo recovery simulated without a serial read or real wait' {
        $script:Runtime.IsDemoMode = $true
        $script:device.Steps.F = @{ CompletionState = 'Simulated'; Timestamp = Get-Date }
        $result = Invoke-AutopilotManifestStep -Device $script:device -StepDefinition $script:recoveryStep
        $result.CompletionState | Should -Be 'Simulated'
        Should -Invoke Resolve-LiveManagedDeviceBySerial -Times 0 -Exactly
    }
    It 'offers recovery close-out rather than repeating a submitted unblock as the next bench action' {
        Mock Get-EnabledManifestSteps { return @($script:manifestSteps | Where-Object { $_.Id -in @('F', 'Q') }) }
        $eligible = @(Get-EligibleManifestSteps -Device $script:device)
        $eligible.Count | Should -Be 1
        $eligible[0].Id | Should -Be 'Q'
        $unblockStep = $script:manifestSteps | Where-Object { $_.Id -eq 'F' }
        (Test-ManifestStepEligibility -Device $script:device -StepDefinition $unblockStep).Eligible | Should -BeTrue
    }
}