<#
.SYNOPSIS
    Checks local workflow identity safety without starting Graph or the operator menu.
.DESCRIPTION
    Extracts production helpers and uses synthetic records and isolated temporary files.
    No operational session data is read or changed.
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('Assert-DeviceRecordIdentity', 'Assert-BenchPositionIdentity', 'Add-DeviceRecord', 'Start-LocalSessionLock', 'Stop-LocalSessionLock')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if (-not $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function Get-DataFolderPath { return $script:lockRoot }
}

Describe 'Local workflow identity safeguards' {
    BeforeEach {
        $script:first = @{ RecordId = 'one'; Serial = 'DEVICE-01'; ConfigItem = 'CI-01'; Status = 'in-progress' }
        $script:second = @{ RecordId = 'two'; Serial = 'DEVICE-02'; ConfigItem = 'CI-02'; Status = 'new' }
        $script:records = @{ Value = @($script:first) }
    }

    It 'accepts an empty collection' {
        { Assert-DeviceRecordIdentity -Records @() } | Should -Not -Throw
    }

    It 'appends a distinct device' {
        Add-DeviceRecord -Records $script:records -Record $script:second
        $script:records.Value.Count | Should -Be 2
    }

    It 'rejects a duplicate serial without changing the collection' {
        $script:second.Serial = ' device-01 '
        { Add-DeviceRecord -Records $script:records -Record $script:second } | Should -Throw '*Duplicate serial*'
        $script:records.Value.Count | Should -Be 1
        $script:records.Value[0].RecordId | Should -Be 'one'
    }

    It 'rejects a duplicate record ID' {
        $script:second.RecordId = 'ONE'
        { Add-DeviceRecord -Records $script:records -Record $script:second } | Should -Throw '*record ID*'
        $script:records.Value.Count | Should -Be 1
    }

    It 'rejects an active CI conflict' {
        $script:second.ConfigItem = ' ci-01 '
        { Add-DeviceRecord -Records $script:records -Record $script:second } | Should -Throw '*Configuration Item*'
        $script:records.Value.Count | Should -Be 1
    }

    It 'allows a CI previously used by a removed device with a different serial' {
        $script:first.Status = 'removed'
        $script:second.ConfigItem = 'CI-01'
        { Add-DeviceRecord -Records $script:records -Record $script:second } | Should -Not -Throw
    }

    It 'does not create a second record for a removed serial' {
        $script:first.Status = 'removed'
        $script:second.Serial = 'DEVICE-01'
        { Add-DeviceRecord -Records $script:records -Record $script:second } | Should -Throw '*Duplicate serial*'
    }

    It 'rejects a missing serial' {
        $script:second.Serial = ' '
        { Assert-DeviceRecordIdentity -Records @($script:second) } | Should -Throw '*no serial*'
    }

    It 'rejects a serial matching another device CI' {
        $script:second.ConfigItem = 'device-01'
        { Add-DeviceRecord -Records $script:records -Record $script:second } | Should -Throw '*ambiguous scan identifier*'
        $script:records.Value.Count | Should -Be 1
    }
}

Describe 'Saved bench identity validation' {
    It 'accepts distinct occupied and empty positions' {
        { Assert-BenchPositionIdentity -Positions @(@{ Index = 1; Serial = 'DEVICE-01'; ConfigItem = 'CI-01' }, @{ Index = 2; Serial = ''; ConfigItem = '' }) } | Should -Not -Throw
    }

    It 'rejects duplicate position numbers' {
        { Assert-BenchPositionIdentity -Positions @(@{ Index = 1 }, @{ Index = 1 }) } | Should -Throw '*duplicate numbers*'
    }

    It 'rejects non-positive position numbers' {
        { Assert-BenchPositionIdentity -Positions @(@{ Index = 0 }) } | Should -Throw '*invalid*'
    }

    It 'rejects repeated occupied serials' {
        { Assert-BenchPositionIdentity -Positions @(@{ Index = 1; Serial = 'DEVICE-01' }, @{ Index = 2; Serial = 'device-01' }) } | Should -Throw '*Duplicate serial*'
    }

    It 'rejects a CI without a serial' {
        { Assert-BenchPositionIdentity -Positions @(@{ Index = 1; ConfigItem = 'CI-01' }) } | Should -Throw '*no serial*'
    }
}

Describe 'Exclusive local session reservation' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $true }
        $script:lockRoot = Join-Path $TestDrive ([guid]::NewGuid().Guid)
        New-Item -ItemType Directory -Path $script:lockRoot | Out-Null
    }

    It 'creates ownership evidence and releases its own lock' {
        $lock = Start-LocalSessionLock
        $owner = Get-Content -LiteralPath $lock.Path -Raw | ConvertFrom-Json
        $owner.Token | Should -Be $lock.Token
        $owner.ProcessId | Should -Be $PID
        $owner.StartedAt | Should -Not -BeNullOrEmpty
        Stop-LocalSessionLock -Lock $lock
        Test-Path -LiteralPath $lock.Path | Should -BeFalse
    }

    It 'rejects another session without overwriting its evidence' {
        $lock = Start-LocalSessionLock
        $original = Get-Content -LiteralPath $lock.Path -Raw
        { Start-LocalSessionLock } | Should -Throw '*Cannot reserve local*'
        Get-Content -LiteralPath $lock.Path -Raw | Should -Be $original
        Stop-LocalSessionLock -Lock $lock
    }

    It 'allows a new session after the original session releases' {
        $firstLock = Start-LocalSessionLock
        Stop-LocalSessionLock -Lock $firstLock
        $secondLock = Start-LocalSessionLock
        $secondLock.Token | Should -Not -Be $firstLock.Token
        Stop-LocalSessionLock -Lock $secondLock
    }

    It 'isolates Demo and Live reservations' {
        $demoLock = Start-LocalSessionLock
        $script:Runtime.IsDemoMode = $false
        $liveLock = Start-LocalSessionLock
        $liveLock.Path | Should -Not -Be $demoLock.Path
        Stop-LocalSessionLock -Lock $demoLock
        Stop-LocalSessionLock -Lock $liveLock
    }

    It 'does not remove a lock with changed ownership' {
        $lock = Start-LocalSessionLock
        Set-Content -LiteralPath $lock.Path -Value '{"Token":"replacement"}'
        { Stop-LocalSessionLock -Lock $lock } | Should -Throw '*ownership changed*'
        Test-Path -LiteralPath $lock.Path | Should -BeTrue
    }

    It 'fails closed for an unreadable ownership payload' {
        $lock = Start-LocalSessionLock
        Set-Content -LiteralPath $lock.Path -Value '{invalid-json'
        { Stop-LocalSessionLock -Lock $lock } | Should -Throw
        Test-Path -LiteralPath $lock.Path | Should -BeTrue
    }

    It 'never expires or steals an abandoned lock' {
        $path = Join-Path $script:lockRoot 'autopilot-express-demo.session.lock'
        New-Item -ItemType File -Path $path -Value '{"StartedAt":"2000-01-01T00:00:00Z"}' | Out-Null
        { Start-LocalSessionLock } | Should -Throw '*Cannot reserve local*'
        Test-Path -LiteralPath $path | Should -BeTrue
    }

    It 'releases on a workflow exception through finally' {
        $lock = Start-LocalSessionLock
        { try { throw 'Synthetic workflow failure' } finally { Stop-LocalSessionLock -Lock $lock } } | Should -Throw 'Synthetic workflow failure'
        Test-Path -LiteralPath $lock.Path | Should -BeFalse
    }

    It 'honours the reservation from another constrained process' {
        $lock = Start-LocalSessionLock
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Start-LocalSessionLock' }, $true).Extent.Text
        $body = @(
            ('function Get-DataFolderPath {{ return ''{0}'' }}' -f $script:lockRoot.Replace("'", "''"))
            '$script:Runtime = @{ IsDemoMode = $true }'
            $definition
            'try { $null = Start-LocalSessionLock; throw "UNEXPECTED_ACQUISITION" } catch { if ($_.Exception.Message -notlike "Cannot reserve local*") { throw }; Write-Output "CONTENTION_PASS" }'
        ) -join [Environment]::NewLine
        $bootstrap = '$body = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String(''{0}'')); $ExecutionContext.SessionState.LanguageMode = ''ConstrainedLanguage''; Invoke-Expression $body' -f [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($body))
        try {
            $output = $bootstrap | & powershell.exe -NoProfile -NonInteractive -Command - 2>&1
            $LASTEXITCODE | Should -Be 0
            $output | Should -Contain 'CONTENTION_PASS'
            (Get-Content -LiteralPath $lock.Path -Raw | ConvertFrom-Json).Token | Should -Be $lock.Token
        }
        finally { Stop-LocalSessionLock -Lock $lock }
    }

    It 'acquires and releases from a fresh constrained process' {
        $definitions = foreach ($functionName in @('Start-LocalSessionLock', 'Stop-LocalSessionLock', 'Assert-DeviceRecordIdentity')) {
            $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true).Extent.Text
        }
        $body = @(
            ('function Get-DataFolderPath {{ return ''{0}'' }}' -f $script:lockRoot.Replace("'", "''"))
            '$script:Runtime = @{ IsDemoMode = $true }'
            ($definitions -join [Environment]::NewLine)
            '$lock = Start-LocalSessionLock; try { Assert-DeviceRecordIdentity -Records @(@{ Serial = "ONE"; ConfigItem = "CI-ONE" }) } finally { Stop-LocalSessionLock -Lock $lock }; if (Test-Path -LiteralPath $lock.Path) { throw "LOCK_NOT_RELEASED" }; Write-Output "CONSTRAINED_PASS"'
        ) -join [Environment]::NewLine
        $bootstrap = '$body = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String(''{0}'')); $ExecutionContext.SessionState.LanguageMode = ''ConstrainedLanguage''; Invoke-Expression $body' -f [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($body))
        $output = $bootstrap | & powershell.exe -NoProfile -NonInteractive -Command - 2>&1
        $LASTEXITCODE | Should -Be 0
        $output | Should -Contain 'CONSTRAINED_PASS'
        @(Get-ChildItem -LiteralPath $script:lockRoot).Count | Should -Be 0
    }
}