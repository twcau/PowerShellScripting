<#
.SYNOPSIS
    Offline regression checks for fail-closed Autopilot and Entra resolution.
.DESCRIPTION
    Extracts actual functions without launching the CLI. Graph responses are
    synthetic; no operational storage, authentication or device changes occur.
    Requires Pester 5 and FullLanguage for source parsing.
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('New-OperationResult', 'Get-GraphVerificationPolicy', 'Invoke-StepResolveAutopilotDevice', 'Get-LiveTenantBinding', 'Get-GraphDiscoveryCollection', 'Resolve-LiveAutopilotDeviceBySerial', 'Resolve-LiveEntraDeviceObject', 'Resolve-LiveManagedDeviceBySerial', 'Resolve-LiveAutopilotContext')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if (-not $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function Invoke-GraphApiRequest { param($Method, $Uri) throw ('Unexpected Graph request: {0} {1}' -f $Method, $Uri) }
    function Get-MgContext { throw 'Unexpected actual tenant lookup.' }
    function Get-ConfiguredMissingSerialHandoffNote { return 'Follow the approved upload guide.' }
    function Read-ValidatedInput { param($Prompt, $Default, $Type, $Choices) throw 'Unexpected prompt.' }
}

Describe 'Fail-closed unique device lookups' {
    It 'returns a unique Autopilot identity with the matching serial' {
        Mock Invoke-GraphApiRequest { return @{ value = @(@{ id = 'autopilot-one'; serialNumber = 'SERIAL1' }) } }
        (Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1').id | Should -Be 'autopilot-one'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter { $Method -eq 'GET' }
    }

    It 'finds a local exact serial match on a later complete page' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*skiptoken*') { return @{ value = @(@{ id = 'autopilot-one'; serialNumber = 'SERIAL1' }) } }
            return @{ value = @(@{ id = 'other'; serialNumber = 'SERIAL10' }); '@odata.nextLink' = 'https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities?$skiptoken=next' }
        }
        (Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1').id | Should -Be 'autopilot-one'
        Should -Invoke Invoke-GraphApiRequest -Times 2 -Exactly
    }

    It 'rejects duplicate serial matches across distinct identities' {
        Mock Invoke-GraphApiRequest { return @{ value = @(@{ id = 'one'; serialNumber = 'SERIAL1' }, @{ id = 'two'; serialNumber = 'serial1' }) } }
        { Resolve-LiveAutopilotDeviceBySerial -Serial SERIAL1 } | Should -Throw '*Multiple Autopilot*'
    }

    It 'does not infer absence from a valid first page followed by a failed page' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*skiptoken*') { throw 'Later page denied' }
            return @{ value = @(); '@odata.nextLink' = 'https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities?$skiptoken=next' }
        }
        { Resolve-LiveAutopilotDeviceBySerial -Serial SERIAL1 } | Should -Throw '*Later page denied*'
    }

    It 'returns an Entra object ID only for its matching registration ID' {
        Mock Invoke-GraphApiRequest { return @{ value = @(@{ id = 'object-one'; deviceId = 'registration-one' }) } }
        (Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one').id | Should -Be 'object-one'
    }

    It 'treats a complete empty collection as absent on both surfaces' {
        Mock Invoke-GraphApiRequest { return @{ value = @() } }
        Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1' | Should -BeNullOrEmpty
        Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one' | Should -BeNullOrEmpty
    }

    It 'rejects missing null scalar and object collections rather than treating them as absent' {
        foreach ($response in @($null, @{}, @{ value = $null }, @{ value = 'invalid' }, @{ value = @{ id = 'one' } })) {
            $script:identityResponse = $response
            Mock Invoke-GraphApiRequest { return $script:identityResponse }
            { Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1' } | Should -Throw '*malformed*'
            { Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one' } | Should -Throw '*malformed*'
        }
    }

    It 'rejects incomplete pages including empty pages with a continuation' {
        Mock Invoke-GraphApiRequest { return @{ value = @(); '@odata.nextLink' = 'https://graph.microsoft.com/more' } }
        { Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1' } | Should -Throw '*continuation*'
        { Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one' } | Should -Throw '*incomplete*'
        Should -Invoke Invoke-GraphApiRequest -Times 2 -Exactly
    }

    It 'rejects multiple results even when both entries have the same ID' {
        Mock Invoke-GraphApiRequest { return @{ value = @(@{ id = 'one'; serialNumber = 'SERIAL1' }, @{ id = 'one'; serialNumber = 'SERIAL1' }) } }
        { Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1' } | Should -Throw '*repeated identity*'
        { Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one' } | Should -Throw '*Multiple Entra*'
    }

    It 'rejects missing blank wrong and non-text Autopilot identities' {
        foreach ($identity in @($null, @{}, @{ id = ' '; serialNumber = 'SERIAL1' }, @{ id = 'one'; serialNumber = '' }, @{ id = 1; serialNumber = 'SERIAL1' }, @{ id = 'one'; serialNumber = @('SERIAL1') })) {
            $script:identityResponse = @{ value = @($identity) }
            Mock Invoke-GraphApiRequest { return $script:identityResponse }
            { Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1' } | Should -Throw '*unexpected identity*'
        }
    }

    It 'rejects missing blank wrong and non-text Entra identities' {
        foreach ($identity in @($null, @{}, @{ id = ' '; deviceId = 'registration-one' }, @{ id = 'one'; deviceId = 'OTHER' }, @{ id = 1; deviceId = 'registration-one' }, @{ id = 'one'; deviceId = @('registration-one') })) {
            $script:identityResponse = @{ value = @($identity) }
            Mock Invoke-GraphApiRequest { return $script:identityResponse }
            { Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one' } | Should -Throw '*unexpected identity*'
        }
    }

    It 'propagates read failures without retrying locally' {
        Mock Invoke-GraphApiRequest { throw 'Synthetic lookup denied' }
        { Resolve-LiveAutopilotDeviceBySerial -Serial 'SERIAL1' } | Should -Throw '*lookup denied*'
        { Resolve-LiveEntraDeviceObject -AzureAdDeviceId 'registration-one' } | Should -Throw '*lookup denied*'
        Should -Invoke Invoke-GraphApiRequest -Times 2 -Exactly
    }

    It 'escapes quoted filter values without changing the matching identity' {
        Mock Invoke-GraphApiRequest { return @{ value = @(@{ id = 'one'; serialNumber = "SER'IAL"; deviceId = "registration'one" }) } }
        (Resolve-LiveAutopilotDeviceBySerial -Serial "SER'IAL").id | Should -Be 'one'
        (Resolve-LiveEntraDeviceObject -AzureAdDeviceId "registration'one").id | Should -Be 'one'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter { $Uri -eq 'https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities' }
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter { $Uri -like "*deviceId eq 'registration''one'*" }
    }
}

Describe 'Autopilot upload confirmation requires fresh presence evidence' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false }
        $script:Config = @{ MaxRetryAttempts = 3; RetryBackoffSeconds = 2 }
        $script:device = @{ Serial = 'SERIAL1'; AutopilotDeviceId = ''; ManagedDeviceId = ''; EntraDeviceId = '' }
        $script:step = @{ ActionName = 'ResolveAutopilotDevice' }
        $script:uploadReads = 0
        Mock Write-Host {}
        Mock Start-Sleep {}
        Mock Read-ValidatedInput { return 'Y' }
        Mock Resolve-LiveAutopilotContext { return @{ Autopilot = $null } }
    }

    It 'verifies immediate presence without an upload prompt' {
        Mock Resolve-LiveAutopilotContext { return @{ Autopilot = @{ id = 'auto-1'; serialNumber = 'SERIAL1' } } }
        $result = Invoke-StepResolveAutopilotDevice -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be Verified
        $result.Data.AutopilotDeviceId | Should -Be 'auto-1'
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'automatically rechecks after Yes and observes delayed upload propagation' {
        Mock Resolve-LiveAutopilotContext {
            $script:uploadReads++
            if ($script:uploadReads -lt 3) { return @{ Autopilot = $null } }
            return @{ Autopilot = @{ id = 'auto-1'; serialNumber = 'SERIAL1' } }
        }
        $result = Invoke-StepResolveAutopilotDevice -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be Verified
        $result.Data.HandoffRecorded | Should -BeTrue
        $result.Data.VerificationAttempts | Should -Be 2
        Should -Invoke Resolve-LiveAutopilotContext -Times 3 -Exactly
        Should -Invoke Start-Sleep -Times 1 -Exactly
    }

    It 'keeps reported upload Submitted after bounded absent reads' {
        $result = Invoke-StepResolveAutopilotDevice -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be Submitted
        $result.Success | Should -BeFalse
        $result.Data.VerificationAttempts | Should -Be 3
        Should -Invoke Resolve-LiveAutopilotContext -Times 4 -Exactly
        Should -Invoke Start-Sleep -Times 2 -Exactly
    }

    It 'does not requery when the upload handoff is declined' {
        Mock Read-ValidatedInput { return 'N' }
        (Invoke-StepResolveAutopilotDevice -Device $script:device -StepDefinition $script:step).CompletionState | Should -Be Failed
        Should -Invoke Resolve-LiveAutopilotContext -Times 1 -Exactly
    }

    It 'fails closed on a post-upload read error without inferring absence' {
        Mock Resolve-LiveAutopilotContext {
            $script:uploadReads++
            if ($script:uploadReads -eq 1) { return @{ Autopilot = $null } }
            throw 'Permission denied'
        }
        $result = Invoke-StepResolveAutopilotDevice -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be Failed
        $result.Data.HandoffRecorded | Should -BeTrue
        Should -Invoke Resolve-LiveAutopilotContext -Times 2 -Exactly
    }

    It 'refuses mismatched observed serial evidence' {
        Mock Resolve-LiveAutopilotContext { return @{ Autopilot = @{ id = 'auto-1'; serialNumber = 'OTHER' } } }
        (Invoke-StepResolveAutopilotDevice -Device $script:device -StepDefinition $script:step).CompletionState | Should -Be Failed
    }
}

Describe 'Device context refresh without partial identity updates' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false }
        $script:GraphSession = @{ Connected = $true; IsSimulated = $false; TenantId = '11111111-1111-1111-1111-111111111111' }
        Mock Get-MgContext { return @{ TenantId = '11111111-1111-1111-1111-111111111111' } }
        $script:device = @{ TenantId = '11111111-1111-1111-1111-111111111111'; Serial = 'SERIAL1'; AutopilotDeviceId = 'old-ap'; ManagedDeviceId = 'old-managed'; AzureAdDeviceId = 'old-registration'; EntraDeviceId = 'old-object'; IntuneDeviceName = 'old-name'; GroupTag = 'old-tag' }
        Mock Resolve-LiveAutopilotDeviceBySerial { return @{ id = 'new-ap'; groupTag = 'new-tag'; azureActiveDirectoryDeviceId = 'new-registration'; managedDeviceId = 'stale-managed' } }
        Mock Resolve-LiveManagedDeviceBySerial { return @{ id = 'new-managed'; deviceName = 'new-name'; azureADDeviceId = 'current-registration' } }
        Mock Resolve-LiveEntraDeviceObject { return @{ id = 'new-object' } }
    }

    It 'leaves every cached field unchanged when Entra resolution fails' {
        $before = $script:device | ConvertTo-Json -Compress
        Mock Resolve-LiveEntraDeviceObject { throw 'Ambiguous Entra identity' }
        { Resolve-LiveAutopilotContext -Device $script:device } | Should -Throw '*Ambiguous Entra*'
        ($script:device | ConvertTo-Json -Compress) | Should -Be $before
    }

    It 'leaves cached fields unchanged when managed resolution fails' {
        $before = $script:device | ConvertTo-Json -Compress
        Mock Resolve-LiveManagedDeviceBySerial { throw 'Ambiguous managed identity' }
        { Resolve-LiveAutopilotContext -Device $script:device } | Should -Throw '*Ambiguous managed*'
        ($script:device | ConvertTo-Json -Compress) | Should -Be $before
        Should -Invoke Resolve-LiveEntraDeviceObject -Times 0 -Exactly
    }

    It 'commits resolved identifiers together using current managed registration evidence' {
        $context = Resolve-LiveAutopilotContext -Device $script:device
        $script:device.AutopilotDeviceId | Should -Be 'new-ap'
        $script:device.ManagedDeviceId | Should -Be 'new-managed'
        $script:device.AzureAdDeviceId | Should -Be 'current-registration'
        $script:device.EntraDeviceId | Should -Be 'new-object'
        $script:device.IntuneDeviceName | Should -Be 'new-name'
        $script:device.GroupTag | Should -Be 'new-tag'
        $context.Entra.id | Should -Be 'new-object'
        Should -Invoke Resolve-LiveEntraDeviceObject -Times 1 -Exactly -ParameterFilter { $AzureAdDeviceId -eq 'current-registration' }
    }

    It 'clears stale mutation IDs when both serial lookups confirm absence' {
        Mock Resolve-LiveAutopilotDeviceBySerial { return $null }
        Mock Resolve-LiveManagedDeviceBySerial { return $null }
        [void](Resolve-LiveAutopilotContext -Device $script:device)
        foreach ($field in @('AutopilotDeviceId', 'ManagedDeviceId', 'AzureAdDeviceId', 'EntraDeviceId')) { $script:device[$field] | Should -BeNullOrEmpty }
        Should -Invoke Resolve-LiveEntraDeviceObject -Times 0 -Exactly
    }

    It 'does not reuse an Autopilot managed-device association after a complete absent managed read' {
        Mock Resolve-LiveManagedDeviceBySerial { return $null }
        [void](Resolve-LiveAutopilotContext -Device $script:device)
        $script:device.ManagedDeviceId | Should -BeNullOrEmpty
        $script:device.AutopilotDeviceId | Should -Be 'new-ap'
    }

    It 'clears a stale Entra object ID when the current registration has no directory object' {
        Mock Resolve-LiveEntraDeviceObject { return $null }
        [void](Resolve-LiveAutopilotContext -Device $script:device)
        $script:device.EntraDeviceId | Should -BeNullOrEmpty
        $script:device.AzureAdDeviceId | Should -Be 'current-registration'
    }
}