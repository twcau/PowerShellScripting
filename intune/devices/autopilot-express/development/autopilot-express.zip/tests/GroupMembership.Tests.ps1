<#
.SYNOPSIS
    Isolated pre-provisioning membership transition regression tests.
.DESCRIPTION
    Extracts only required functions without starting the CLI. Graph and pauses
    are mocked; no tenant or operational records are modified. Requires Pester 5.
#>

BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('New-OperationResult', 'Get-GraphVerificationPolicy', 'Wait-GroupMembershipVerification', 'Invoke-PreProvisioningMembershipChange', 'Invoke-StepAddPreProvisioningGroup', 'Invoke-StepRemovePreProvisioningGroup')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if ($null -eq $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function Get-ConfiguredPreProvisioningGroupDisplayName { return 'Test pre-provisioning' }
    function Get-LivePreProvisioningGroup { throw 'Unexpected group lookup.' }
    function Resolve-LiveAutopilotContext {
        param($Device)
        throw ('Unexpected context lookup for {0}.' -f $Device.Serial)
    }
    function Test-LiveGroupMembership {
        param([string]$GroupId, [string]$DirectoryObjectId)
        throw ('Unexpected membership read: {0}, {1}.' -f $GroupId, $DirectoryObjectId)
    }
    function Invoke-GraphApiRequest {
        param([string]$Method, [string]$Uri, [hashtable]$Body)
        throw ('Unexpected Graph request: {0} {1}; body keys {2}.' -f $Method, $Uri, ($Body.Keys -join ','))
    }
}

Describe 'Pre-provisioning membership transitions' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false }
        $script:Config = @{ MaxRetryAttempts = 3; RetryBackoffSeconds = 2 }
        $script:device = @{ Serial = 'SERIAL1'; EntraDeviceId = 'device-1' }
        $script:step = @{ ActionName = 'AddToPreProvisioningGroup' }
        $script:removeStep = @{ ActionName = 'RemoveFromPreProvisioningGroup' }
        $script:reads = 0
        Mock Start-Sleep {}
        Mock Resolve-LiveAutopilotContext {}
        Mock Get-LivePreProvisioningGroup { return @{ id = 'group-1'; displayName = 'Test pre-provisioning'; securityEnabled = $true; mailEnabled = $false; groupTypes = @(); isAssignableToRole = $false } }
        Mock Invoke-GraphApiRequest {}
        Mock Test-LiveGroupMembership { return $false }
    }

    It 'refreshes cached membership identity before reading or removing a relationship' {
        Mock Resolve-LiveAutopilotContext { $Device.EntraDeviceId = 'current-device' }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:removeStep
        $result.CompletionState | Should -Be 'Verified'
        $result.Data.DirectoryObjectId | Should -Be 'current-device'
        Should -Invoke Test-LiveGroupMembership -Times 1 -Exactly -ParameterFilter { $DirectoryObjectId -eq 'current-device' }
    }
    It 'stops before membership access when cached identity refresh fails' {
        Mock Resolve-LiveAutopilotContext { throw 'Identity read denied' }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        Should -Invoke Test-LiveGroupMembership -Times 0 -Exactly
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }
    It 'skips a write when addition is already verified' {
        Mock Test-LiveGroupMembership { return $true }
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Verified'
        $result.Data.Submitted | Should -BeFalse
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'refuses unsupported group eligibility before membership writes' {
        foreach ($metadata in @(
            @{ securityEnabled = $false; mailEnabled = $false; groupTypes = @() }
            @{ securityEnabled = $true; mailEnabled = $true; groupTypes = @() }
            @{ securityEnabled = $true; mailEnabled = $false; groupTypes = @('DynamicMembership') }
            @{ securityEnabled = $true; mailEnabled = $false; groupTypes = @(); isAssignableToRole = $true }
            @{ securityEnabled = $true; mailEnabled = $false }
        )) {
            $script:groupMetadata = $metadata
            Mock Get-LivePreProvisioningGroup { return (@{ id = 'group-1'; displayName = 'Test pre-provisioning' } + $script:groupMetadata) }
            $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
            $result.CompletionState | Should -Be Failed
        }
        Should -Invoke Test-LiveGroupMembership -Times 5 -Exactly
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'preserves read-only verified no-op outcomes for groups that cannot be mutated' {
        Mock Get-LivePreProvisioningGroup { return @{ id = 'group-1'; displayName = 'Test pre-provisioning'; groupTypes = @('DynamicMembership') } }
        Mock Test-LiveGroupMembership { return $true }
        (Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step).CompletionState | Should -Be Verified
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'refuses a non-Boolean membership observation without writing' {
        Mock Test-LiveGroupMembership { return $null }
        (Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step).CompletionState | Should -Be Failed
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'skips a write when removal is already verified' {
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:removeStep
        $result.CompletionState | Should -Be 'Verified'
        $result.Data.ObservedMember | Should -BeFalse
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'polls delayed addition after exactly one POST' {
        Mock Test-LiveGroupMembership { $script:reads++; return $script:reads -ge 3 }
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Verified'
        $result.Data.VerificationAttempts | Should -Be 2
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter {
            $Method -eq 'POST' -and $Uri -eq 'https://graph.microsoft.com/v1.0/groups/group-1/members/$ref' -and
            $Body.'@odata.id' -eq 'https://graph.microsoft.com/v1.0/directoryObjects/device-1'
        }
        Should -Invoke Start-Sleep -Times 1 -Exactly -ParameterFilter { $Seconds -eq 2 }
    }

    It 'polls delayed removal after exactly one reference DELETE' {
        Mock Test-LiveGroupMembership { $script:reads++; return $script:reads -lt 3 }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:removeStep
        $result.CompletionState | Should -Be 'Verified'
        $result.Data.VerificationAttempts | Should -Be 2
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter {
            $Method -eq 'DELETE' -and $Uri -eq 'https://graph.microsoft.com/v1.0/groups/group-1/members/device-1/$ref'
        }
        Should -Invoke Start-Sleep -Times 1 -Exactly
    }

    It 'keeps exhausted addition Submitted with absence evidence' {
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Submitted'
        $result.Success | Should -BeFalse
        $result.Data.Submitted | Should -BeTrue
        $result.Data.VerificationAttempts | Should -Be 3
        $result.Data.ObservedMember | Should -BeFalse
        Should -Invoke Start-Sleep -Times 2 -Exactly
    }

    It 'keeps exhausted removal Submitted with presence evidence' {
        Mock Test-LiveGroupMembership { return $true }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Submitted'
        $result.Success | Should -BeFalse
        $result.Data.ObservedMember | Should -BeTrue
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Start-Sleep -Times 2 -Exactly
    }

    It 'does not hide a membership read error as successful removal' {
        Mock Test-LiveGroupMembership { throw 'Permission denied: resource was not found' }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Success | Should -BeFalse
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'retains submission evidence when post-write verification fails' {
        Mock Test-LiveGroupMembership { $script:reads++; if ($script:reads -gt 1) { throw 'Read denied' }; return $false }
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Data.Submitted | Should -BeTrue
        Should -Invoke Start-Sleep -Times 0 -Exactly
    }

    It 'does not treat duplicate-error wording as read-back verification' {
        Mock Invoke-GraphApiRequest { throw 'Permission denied; relationship already exists' }
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Data.Submitted | Should -BeFalse
    }

    It 'blocks a missing device identity without issuing a write' {
        $script:device.EntraDeviceId = ''
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Blocked'
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'resolves missing device context before checking membership' {
        $script:device.EntraDeviceId = ''
        Mock Resolve-LiveAutopilotContext { $Device.EntraDeviceId = 'device-1' }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:removeStep
        $result.CompletionState | Should -Be 'Verified'
        Should -Invoke Resolve-LiveAutopilotContext -Times 1 -Exactly
    }

    It 'rejects invalid policy before context lookup or mutation' {
        $script:Config.MaxRetryAttempts = 0
        $script:device.EntraDeviceId = ''
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        Should -Invoke Resolve-LiveAutopilotContext -Times 0 -Exactly
        Should -Invoke Get-LivePreProvisioningGroup -Times 0 -Exactly
    }

    It 'does not convert a missing-group error to successful removal' {
        Mock Get-LivePreProvisioningGroup { throw 'Resource group does not exist' }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }

    It 'rejects a group response without an object ID' {
        Mock Get-LivePreProvisioningGroup { return @{ displayName = 'Unknown' } }
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        Should -Invoke Test-LiveGroupMembership -Times 0 -Exactly
    }

    It 'keeps Demo addition isolated from lookups, mutations and pauses' {
        $script:Runtime.IsDemoMode = $true
        $result = Invoke-StepAddPreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Simulated'
        Should -Invoke Test-LiveGroupMembership -Times 0 -Exactly
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
        Should -Invoke Start-Sleep -Times 0 -Exactly
    }

    It 'keeps Demo removal isolated from Graph' {
        $script:Runtime.IsDemoMode = $true
        $result = Invoke-StepRemovePreProvisioningGroup -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Simulated'
        Should -Invoke Get-LivePreProvisioningGroup -Times 0 -Exactly
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
    }
}

Describe 'Direct membership absence evidence' {
    BeforeAll {
        $collectionDefinition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-GraphDiscoveryCollection' }, $true)
        . ([scriptblock]::Create($collectionDefinition.Extent.Text))
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Test-LiveGroupMembership' }, $true)
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    BeforeEach {
        Mock Invoke-GraphApiRequest { return @{ value = @(@{ id = 'device-1' }) } }
    }

    It 'returns presence from a complete direct members collection' {
        Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' | Should -BeTrue
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter {
            $Method -eq 'GET' -and $Uri -eq 'https://graph.microsoft.com/v1.0/groups/group-1/members'
        }
    }

    It 'verifies presence on a later page with limited-information member IDs' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*skiptoken*') { return @{ value = @(@{ id = 'device-1'; displayName = $null }) } }
            return @{ value = @(@{ id = 'other-device' }); '@odata.nextLink' = 'https://graph.microsoft.com/v1.0/groups/group-1/members?$skiptoken=next' }
        }
        Test-LiveGroupMembership -GroupId group-1 -DirectoryObjectId device-1 | Should -BeTrue
        Should -Invoke Invoke-GraphApiRequest -Times 2 -Exactly
    }

    It 'does not confirm absence after a failed later page' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*skiptoken*') { throw 'Later page denied' }
            return @{ value = @(); '@odata.nextLink' = 'https://graph.microsoft.com/v1.0/groups/group-1/members?$skiptoken=next' }
        }
        { Test-LiveGroupMembership -GroupId group-1 -DirectoryObjectId device-1 } | Should -Throw '*Later page denied*'
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly -ParameterFilter { $Uri -like '*/directoryObjects/*' }
    }

    It 'rejects malformed member collections rather than confirming absence' {
        foreach ($response in @($null, @{}, @{ value = $null }, @{ value = 'invalid' }, @{ value = @(@{ id = '' }) })) {
            $script:membershipResponse = $response
            Mock Invoke-GraphApiRequest { return $script:membershipResponse }
            { Test-LiveGroupMembership -GroupId group-1 -DirectoryObjectId device-1 } | Should -Throw
        }
    }

    It 'rejects not-found text without a structured HTTP status' {
        Mock Invoke-GraphApiRequest { throw 'Resource not found; does not exist' }
        { Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' } | Should -Throw '*not found*'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
    }

    It 'rejects a structured permission failure even with not-found text' {
        Mock Invoke-GraphApiRequest {
            $exception = [System.Exception]::new('Permission denied: resource not found')
            $exception | Add-Member -NotePropertyName ResponseStatusCode -NotePropertyValue 403
            throw $exception
        }
        { Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' } | Should -Throw '*Permission denied*'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
    }

    It 'verifies absence from a complete empty collection and both identities' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*/members') { return @{ value = @() } }
            if ($Uri -like '*/directoryObjects/*') { return @{ id = 'device-1' } }
            return @{ id = 'group-1' }
        }
        Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' | Should -BeFalse
        Should -Invoke Invoke-GraphApiRequest -Times 3 -Exactly
    }

    It 'rejects 404 instead of interpreting it as absent membership' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*/members') {
                $exception = [System.Exception]::new('Membership absent')
                $exception | Add-Member -NotePropertyName Response -NotePropertyValue @{ StatusCode = 'NotFound' }
                throw $exception
            }
            if ($Uri -like '*/directoryObjects/*') { return @{ id = 'device-1' } }
            return @{ id = 'group-1' }
        }
        { Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' } | Should -Throw '*Membership absent*'
    }

    It 'rejects absence when the expected directory identity is missing' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*/members') { return @{ value = @() } }
            return @{ id = 'group-1' }
        }
        { Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' } | Should -Throw '*expected group and device*'
    }

    It 'propagates identity lookup errors rather than confirming absence' {
        Mock Invoke-GraphApiRequest {
            if ($Uri -like '*/members') { return @{ value = @() } }
            throw 'Group lookup denied'
        }
        { Test-LiveGroupMembership -GroupId 'group-1' -DirectoryObjectId 'device-1' } | Should -Throw '*Group lookup denied*'
    }
}