<#
.SYNOPSIS
    Rehearses the actual Demo CLI through device creation, reload and completion.
.DESCRIPTION
    Copies the entry point and definitions into Pester temporary storage. Only host
    prompts and screen clearing are mocked. No Graph or physical actions occur.
    Requires Pester 5; preserves inherited root variables after the rehearsal.
#>
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidGlobalVars', '', Justification = 'The real entry point has a separate script scope. This uniquely named test-only prompt fixture crosses that boundary and is restored in finally; no product global is introduced.')]
param()

Describe 'Consistent application screen header' {
    BeforeAll {
        $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
        $tokens = $null
        $parseErrors = $null
        $ast = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
        if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
        $definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Show-ScriptScreen' }, $true)
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    BeforeEach {
        $script:screenLines = @()
        $script:Runtime = @{ IsDemoMode = $true }
        Mock Clear-Host {}
        Mock Write-Host { $script:screenLines += [string]$Object }
    }
    It 'clears every refresh and leaves a blank line below the blue title' {
        Show-ScriptScreen -Title 'Main Menu'
        Should -Invoke Clear-Host -Times 1 -Exactly
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $BackgroundColor -eq 'DarkBlue' -and $ForegroundColor -eq 'White' }
        ($script:screenLines -join '').Trim() | Should -Be 'Autopilot Express - Main Menu | Demo'
        $script:screenLines[-1] | Should -Be ''
    }
    It 'retains long titles without truncating screen names' {
        $title = 'Screen ' * 80
        Show-ScriptScreen -Title $title
        $rendered = ($script:screenLines | ForEach-Object { $_.Trim() }) -join ''
        $rendered.Replace(' ', '') | Should -Be ('AutopilotExpress-' + $title.Replace(' ', '') + '|Demo')
        $script:screenLines[-1] | Should -Be ''
    }
}

Describe 'Initial setup gates before session setup' {
    BeforeAll {
        $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
        $source = Get-Content -LiteralPath $sourcePath -Raw
        $script:startupBlock = [scriptblock]::Create($source.Substring($source.LastIndexOf("`nInitialize-AutopilotExpressDefinitions")))
        function Initialize-AutopilotExpressDefinitions { }
        function Show-ScriptScreen { param($Title, $ModeLabel) throw ('Unexpected screen: {0}/{1}' -f $Title, $ModeLabel) }
        function Start-LocalSessionLock {
            [CmdletBinding(SupportsShouldProcess)]
            [OutputType([hashtable])]
            param()
            if ($PSCmdlet.ShouldProcess('Test storage', 'Reserve')) { return @{} }
        }
        function Stop-LocalSessionLock {
            [CmdletBinding(SupportsShouldProcess)]
            param($Lock)
            if ($PSCmdlet.ShouldProcess('Test storage', 'Release')) { throw ('Unexpected release: {0}' -f $Lock.Count) }
        }
        function Assert-LocalStorageWriteState { }
        function Initialize-GraphSession { return $true }
        function Close-GraphSession { }
        function Initialize-SessionState { return , @() }
        function Get-SessionDefaultSiteCode { param($Records) if (@($Records).Count -eq 0) { return 'SITE' }; throw 'Unexpected records' }
        function Select-Site { param($CurrentSiteCode) return $CurrentSiteCode }
        function Write-AutopilotExpressLog { param($Message, $Level) throw ('Unexpected log: {0}/{1}' -f $Level, $Message) }
        function Show-MainMenu { return 'Exit' }
        function Show-SessionArchive { param($Records) throw ('Unexpected archive: {0}' -f @($Records.Value).Count) }
        function Write-UserDeviceRecords { param($Records) throw ('Unexpected save: {0}' -f @($Records).Count) }
    }
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false; Mode = 'Live' }
        $script:startupEvents = @()
        Mock Show-ScriptScreen { $script:startupEvents += ('screen:{0}' -f $Title) }
        Mock Assert-LocalStorageWriteState { $script:startupEvents += 'storage' }
        Mock Initialize-GraphSession { $script:startupEvents += 'graph'; return $true }
        Mock Initialize-SessionState { $script:startupEvents += 'session'; return , @() }
        Mock Select-Site { $script:startupEvents += 'site'; return $CurrentSiteCode }
        Mock Close-GraphSession {}
        Mock Stop-LocalSessionLock {}
        Mock Write-AutopilotExpressLog {}
        Mock Write-UserDeviceRecords {}
        Mock Write-Host {}
    }
    It 'renders initial setup and checks Live before resume and site selection' {
        & $script:startupBlock
        $script:startupEvents -join ',' | Should -Be 'screen:Initial setup and testing,storage,graph,session,site'
        Should -Invoke Stop-LocalSessionLock -Times 1 -Exactly
    }
    It 'never resumes or selects a site after unsuccessful Live setup' {
        Mock Initialize-GraphSession { return $false }
        & $script:startupBlock
        Should -Invoke Initialize-SessionState -Times 0 -Exactly
        Should -Invoke Select-Site -Times 0 -Exactly
        Should -Invoke Close-GraphSession -Times 1 -Exactly
        Should -Invoke Stop-LocalSessionLock -Times 1 -Exactly
    }
    It 'never attempts Graph when local recovery checks fail' {
        Mock Assert-LocalStorageWriteState { throw 'Synthetic local recovery required' }
        { & $script:startupBlock } | Should -Throw '*local recovery required*'
        Should -Invoke Initialize-GraphSession -Times 0 -Exactly
        Should -Invoke Initialize-SessionState -Times 0 -Exactly
        Should -Invoke Stop-LocalSessionLock -Times 1 -Exactly
    }
    It 'opens fresh site setup after confirmed archive without reconnecting Graph' {
        $script:Sites = @(@{ Code = 'FIRST' })
        $script:menuCalls = 0
        Mock Show-MainMenu { $script:menuCalls++; if ($script:menuCalls -eq 1) { return 'ArchiveSession' }; return 'Exit' }
        Mock Show-SessionArchive { return $true }
        & $script:startupBlock
        Should -Invoke Select-Site -Times 1 -Exactly -ParameterFilter { $CurrentSiteCode -eq 'FIRST' }
        Should -Invoke Initialize-GraphSession -Times 1 -Exactly
    }
}

Describe 'Technician navigation and readable feedback' {
    BeforeAll {
        $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
        $tokens = $null
        $parseErrors = $null
        $ast = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
        if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
        foreach ($name in @('Show-ScriptScreen', 'Show-SessionArchive', 'Add-ScreenFeedback', 'Get-MainMenuDefinition', 'Show-MainMenu', 'Show-AboutScript', 'Show-WorkflowOutcome', 'Invoke-AutopilotSequence', 'Show-DeviceWorkflowStatus', 'Get-DeviceOutstanding', 'Update-DeviceStatus', 'Read-NewDeviceIdentityField', 'Start-NewDeviceWorkflow', 'Assert-DeviceRecordIdentity', 'Add-DeviceRecord', 'Select-DeviceType', 'ConvertTo-OptionalInteger', 'Read-NormalisedSerialInput', 'ConvertTo-NormalisedSerialInput', 'Get-ConfiguredSerialPattern', 'Get-ConfiguredScannerSerialRules', 'Get-UriQueryParameterValues', 'Read-ValidatedInput', 'Get-EnabledManifestSteps', 'Get-ManifestStepDefinition', 'Show-ReturnToMainMenu')) {
            $definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name }, $true)
            if (-not $definition) { throw ('Missing function: {0}' -f $name) }
            . ([scriptblock]::Create($definition.Extent.Text))
        }
        function Select-DeviceFromRecords { param($Records, $Purpose) if ($Purpose) { return $Records.Value[0] } }
        function Get-NextStepId { param($Device) if ($Device.Serial) { return 'A' } }
        function Test-DeviceReadyForDispatch { param($Device) return @{ Ready = -not $Device.Serial; BlockingStepIds = @('A') } }
        function Test-ManifestStepCompleted { param($Device, $StepId) return ($Device.Steps.ContainsKey($StepId)) }
        function Test-ManifestStepAttempted { param($Device, $StepId) return ($Device.Steps.ContainsKey($StepId)) }
        function Test-ManifestStepEligibility { param($Device, $StepDefinition) return @{ Eligible = [bool]($Device.Serial -and $StepDefinition.Id); MissingStepIds = @(); ActivationRequirement = '' } }
        function Invoke-AutopilotManifestStep { param($Device, $StepDefinition) throw ('Unexpected action {0} for {1}' -f $StepDefinition.Id, $Device.Serial) }
        function Write-ManifestStepResult { param($Device, $StepDefinition, $Result) throw ('Unexpected result {0} for {1}/{2}' -f $Result.CompletionState, $Device.Serial, $StepDefinition.Id) }
        function Write-UserDeviceRecords { param($Records) throw ('Unexpected save of {0} records' -f @($Records).Count) }
        function Write-AutopilotExpressLog { param($Message, $Level) throw ('Unexpected log {0}: {1}' -f $Level, $Message) }
        function Enter-DeviceRecoveryMode { param($Device) throw ('Unexpected recovery for {0}' -f $Device.Serial) }
        function Select-Site { param($CurrentSiteCode) return $CurrentSiteCode }
        function Get-UserDataFilePath { return (Join-Path $TestDrive 'ui-devices.json') }
        function Get-BuildBenchStatePath { return (Join-Path $TestDrive 'ui-bench.json') }
        function Assert-LocalStorageWriteState { }
        function Reset-CurrentSessionState {
            [CmdletBinding(SupportsShouldProcess)]
            [OutputType([object[]])]
            param()
            if ($PSCmdlet.ShouldProcess('Test session', 'Reset')) { return , @() }
        }
        function New-DeviceRecordObject {
            [CmdletBinding(SupportsShouldProcess)]
            [OutputType([hashtable])]
            param($Serial, $ConfigItem, $SiteCode, $DeviceType, $GroupTag)
            if ($PSCmdlet.ShouldProcess($Serial, 'Construct test record')) {
                return @{ Serial = $Serial; ConfigItem = $ConfigItem; SiteCode = $SiteCode; DeviceType = $DeviceType; GroupTag = $GroupTag; Status = 'new' }
            }
        }
    }
    BeforeEach {
        $script:uiLines = @()
        $script:uiAnswers = @('0')
        $script:uiReadIndex = 0
        $script:StepManifest = @(
            @{ Id = 'A'; Enabled = $true; DisplayName = 'Resolve identity'; IsConditional = $false }
            @{ Id = 'B'; Enabled = $true; DisplayName = 'Prepare device'; IsConditional = $false }
            @{ Id = 'F'; Enabled = $true; DisplayName = 'Recovery only'; IsConditional = $true }
        )
        $script:uiRecords = @{ Value = @(@{ Serial = 'UI-ONE'; ConfigItem = 'CI-ONE'; Status = 'in-progress'; Steps = @{} }, @{ Serial = 'UI-TWO'; ConfigItem = 'CI-TWO'; Status = 'in-progress'; Steps = @{} }) }
        $script:Sites = @(@{ Code = 'MI'; Name = 'Midland' })
        $script:GraphSession = @{ Connected = $false }
        $script:Runtime = @{ IsDemoMode = $true; Mode = 'Demo' }
        $script:BuildBench = @{ Active = $false; Positions = @() }
        $script:RuntimeConfig = @{}
        $script:DeviceTypes = @('Desktop', 'Laptop')
        $script:Config = @{ Nomenclature = @{ Serial = 'Serial'; ConfigItem = 'Configuration Item'; Site = 'Site'; DeviceType = 'Device Type'; GroupTag = 'Group Tag' } }
        Mock Clear-Host {}
        Mock Write-Host { $script:uiLines += [string]$Object }
        Mock Read-Host {
            if ($script:uiReadIndex -ge $script:uiAnswers.Count) { throw ('Unexpected UI prompt: {0}' -f $Prompt) }
            $answer = $script:uiAnswers[$script:uiReadIndex]
            $script:uiReadIndex++
            return $answer
        }
        Mock Write-UserDeviceRecords {}
        Mock Write-ManifestStepResult {}
        Mock Write-AutopilotExpressLog {}
        Mock Invoke-AutopilotManifestStep { return @{ Success = $true; CompletionState = 'Simulated'; Summary = 'Action finished'; Notes = '' } }
    }
    It 'places bench first and session archive immediately before exit' {
        Show-MainMenu -CurrentSiteCode 'MI' | Should -Be 'Exit'
        $script:uiLines.IndexOf('1. Build bench - manage active builds') | Should -BeLessThan $script:uiLines.IndexOf('2. Start work on a new device')
        $script:uiLines.IndexOf('10. Archive saved session and start fresh') | Should -Be ($script:uiLines.IndexOf('0. Exit') - 1)
        $script:uiLines | Should -Contain '3. Work on a tracked device'
        $script:uiLines | Should -Contain '8. About this script'
    }
    It 'routes every displayed number to its ordered stable action' {
        $menu = @(Get-MainMenuDefinition)
        for ($index = 0; $index -lt $menu.Count; $index++) {
            $script:uiAnswers = @([string]($index + 1))
            $script:uiReadIndex = 0
            Show-MainMenu -CurrentSiteCode 'MI' | Should -Be $menu[$index].Action
        }
    }
    It 'follows a changed menu order without a separate routing table' {
        Mock Get-MainMenuDefinition { @(@{ Action = 'About'; Label = 'About this script' }, @{ Action = 'Bench'; Label = 'Build bench' }) }
        $script:uiAnswers = @('1')
        Show-MainMenu -CurrentSiteCode 'MI' | Should -Be 'About'
        $script:uiLines | Should -Contain '1. About this script'
    }
    It 'returns from About on zero with exactly one navigation prompt' {
        Show-AboutScript
        Should -Invoke Read-Host -Times 1 -Exactly
        $script:uiLines | Should -Contain 'Version: 0.1.0 - development; not production-approved'
    }
    It 'acknowledges a report once using the zero default on Enter' {
        $script:uiAnswers = @('')
        Show-ReturnToMainMenu
        Should -Invoke Read-Host -Times 1 -Exactly -ParameterFilter { $Prompt -like '*Default: 0*' }
        Should -Invoke Clear-Host -Times 1 -Exactly
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }
    It 'rejects invalid report navigation and tolerates unsupported screen clearing' {
        $script:uiAnswers = @('bad', '0')
        Mock Clear-Host { throw 'Host cannot clear its screen' }
        { Show-ReturnToMainMenu } | Should -Not -Throw
        Should -Invoke Read-Host -Times 2 -Exactly
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }
    It 're-prompts numeric input instead of returning an invalid value from the switch' {
        $script:uiAnswers = @('not-a-number', '2')
        Read-ValidatedInput -Prompt 'Number' -Default '1' -Type Int | Should -Be '2'
        Should -Invoke Read-Host -Times 2 -Exactly
    }
    It 'retains only the five newest feedback lines without changing workflow records' {
        $state = @{ Lines = @() }
        $before = $script:uiRecords | ConvertTo-Json -Depth 20
        Add-ScreenFeedback -State $state -Text @('one', 'two', 'three', 'four', 'five', 'six')
        $state.Lines.Count | Should -Be 5
        $state.Lines[0] | Should -Be 'two'
        $state.Lines[-1] | Should -Be 'six'
        ($script:uiRecords | ConvertTo-Json -Depth 20) | Should -BeExactly $before
    }
    It 'wraps long messages and preserves the newest error text' {
        $state = @{ Lines = @() }
        Add-ScreenFeedback -State $state -Text @(('word ' * 500), "Failed action`nPermission denied")
        $state.Lines.Count | Should -Be 5
        $state.Lines[-2] | Should -Be 'Failed action'
        $state.Lines[-1] | Should -Be 'Permission denied'
    }
    It 'runs consecutive next steps without reselecting the device or returning to main' {
        $script:uiAnswers = @('8', '8', '0')
        $script:nextCalls = 0
        Mock Get-NextStepId { $script:nextCalls++; if ($script:nextCalls -eq 1) { return 'A' }; return 'B' }
        Mock Invoke-AutopilotManifestStep { return @{ Success = $true; CompletionState = 'Simulated'; Summary = 'Action finished'; Notes = 'Demo evidence only' } }
        Invoke-AutopilotSequence -Records $script:uiRecords
        Should -Invoke Invoke-AutopilotManifestStep -Times 2 -Exactly -ParameterFilter { $Device.Serial -eq 'UI-ONE' }
        Should -Invoke Write-UserDeviceRecords -Times 2 -Exactly
        Should -Invoke Read-Host -Times 3 -Exactly
        $script:uiLines | Should -Contain 'A. Resolve identity [Simulated]'
        $script:uiLines | Should -Contain 'B. Prepare device [Simulated]'
        $script:uiLines | Should -Contain 'Demo evidence only'
    }
    It 'switches selected devices explicitly without losing the first record' {
        $script:uiAnswers = @('a', '9', 'b', '0')
        $script:selectionCount = 0
        Mock Select-DeviceFromRecords { $script:selectionCount++; return $Records.Value[$script:selectionCount - 1] }
        Mock Invoke-AutopilotManifestStep { return @{ Success = $true; CompletionState = 'Simulated'; Summary = 'Action finished'; Notes = '' } }
        Invoke-AutopilotSequence -Records $script:uiRecords
        Should -Invoke Invoke-AutopilotManifestStep -Times 1 -Exactly -ParameterFilter { $Device.Serial -eq 'UI-ONE' -and $StepDefinition.Id -eq 'A' }
        Should -Invoke Invoke-AutopilotManifestStep -Times 1 -Exactly -ParameterFilter { $Device.Serial -eq 'UI-TWO' -and $StepDefinition.Id -eq 'B' }
        $script:uiRecords.Value.Count | Should -Be 2
    }
    It 'does not save or invoke an action after an explicit return' {
        Invoke-AutopilotSequence -Records $script:uiRecords
        Should -Invoke Read-Host -Times 1 -Exactly
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Invoke-AutopilotManifestStep -Times 0 -Exactly
    }
    It 'uses non-conflicting shortcuts when customised steps use 8 and 9' {
        $script:StepManifest[0].Id = '8'
        $script:StepManifest[1].Id = '9'
        $script:uiAnswers = @('8', '0')
        Invoke-AutopilotSequence -Records $script:uiRecords
        $script:uiLines | Should -Contain 'NEXT-8. Run next eligible step'
        $script:uiLines | Should -Contain 'SELECT-9. Select another device'
        Should -Invoke Invoke-AutopilotManifestStep -Times 1 -Exactly -ParameterFilter { $StepDefinition.Id -eq '8' }
    }
    It 'keeps no-eligible-action refusal visible and performs no mutation' {
        $script:uiAnswers = @('8', '0')
        Mock Get-NextStepId { return $null }
        Invoke-AutopilotSequence -Records $script:uiRecords
        $script:uiLines | Should -Contain 'No next action is eligible. Required steps remain: A.'
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Invoke-AutopilotManifestStep -Times 0 -Exactly
    }
    It 'reports one action per line and separates conditional recovery' {
        Show-DeviceWorkflowStatus -Device $script:uiRecords.Value[0]
        $script:uiLines | Should -Contain '  A. Resolve identity [Eligible]'
        $script:uiLines | Should -Contain '  B. Prepare device [Eligible]'
        $script:uiLines | Should -Contain 'Conditional recovery Steps:'
        $script:uiLines.IndexOf('  F. Recovery only [Eligible]') | Should -BeGreaterThan $script:uiLines.IndexOf('Conditional recovery Steps:')
    }
    It 'allows another outstanding-work inspection before returning' {
        $script:uiAnswers = @('2', '0')
        $script:selectionCount = 0
        Mock Select-DeviceFromRecords { $script:selectionCount++; return $Records.Value[$script:selectionCount - 1] }
        Get-DeviceOutstanding -Records $script:uiRecords
        $script:uiLines | Should -Contain 'Device Serial=UI-ONE CI=CI-ONE Status=in-progress'
        $script:uiLines | Should -Contain 'Device Serial=UI-TWO CI=CI-TWO Status=in-progress'
        Should -Invoke Read-Host -Times 2 -Exactly
    }
    It 'opens outstanding work directly on the selected record without another selection' {
        $script:uiAnswers = @('1', '0', '0')
        Mock Select-DeviceFromRecords { return $Records.Value[1] }
        Get-DeviceOutstanding -Records $script:uiRecords
        Should -Invoke Select-DeviceFromRecords -Times 1 -Exactly
        $script:uiLines | Should -Contain 'Serial: UI-TWO   CI: CI-TWO   Status: in-progress'
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }
    It 'does not label a submitted successful request as completed success' {
        Show-WorkflowOutcome -Device $script:uiRecords.Value[0] -Step $script:StepManifest[0] -Result @{ Success = $true; CompletionState = 'Submitted'; Summary = 'Request accepted' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like 'PENDING: Serial=UI-ONE*' -and $BackgroundColor -eq 'DarkYellow' -and $ForegroundColor -eq 'White' }
        $script:uiLines | Should -Contain '---------------- LAST STEP RESULT ----------------'
    }
    It 'labels failure and simulated completion using text as well as colour' {
        Show-WorkflowOutcome -Device $script:uiRecords.Value[0] -Step $script:StepManifest[0] -Result @{ Success = $false; CompletionState = 'Failed'; Summary = 'Denied' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like 'FAILED / NOT COMPLETED:*' -and $BackgroundColor -eq 'DarkRed' }
        Show-WorkflowOutcome -Device $script:uiRecords.Value[1] -Step $script:StepManifest[0] -Result @{ Success = $true; CompletionState = 'Simulated'; Summary = 'Simulation finished' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like 'SIMULATED: Serial=UI-TWO*' -and $BackgroundColor -eq 'DarkGreen' }
    }
    It 'retains serial CI site and device type defaults after declining confirmation' {
        $script:uiAnswers = @('N', 'UI-NEW', 'CI-NEW', 'Laptop', 'N', '', '', '', '', 'Y', '0')
        Start-NewDeviceWorkflow -Records $script:uiRecords -CurrentSiteCode 'MI' | Should -Be 'MI'
        $created = $script:uiRecords.Value[-1]
        $created.Serial | Should -Be 'UI-NEW'
        $created.ConfigItem | Should -Be 'CI-NEW'
        $created.DeviceType | Should -Be 'Laptop'
        $created.GroupTag | Should -Be 'MI-Laptop'
        Should -Invoke Read-Host -Times 1 -Exactly -ParameterFilter { $Prompt -like 'Enter Serial*(default: UI-NEW)*' }
        Should -Invoke Read-Host -Times 1 -Exactly -ParameterFilter { $Prompt -like 'Enter Configuration Item*(default: CI-NEW)*' }
        Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly
    }
    It 'never colours failed simulation metadata or submitted simulation as completed success' {
        Show-WorkflowOutcome -Device $script:uiRecords.Value[0] -Step $script:StepManifest[0] -Result @{ Success = $false; CompletionState = 'Failed'; IsSimulated = $true; Summary = 'Failed demo'; Notes = '' }
        Show-WorkflowOutcome -Device $script:uiRecords.Value[0] -Step $script:StepManifest[0] -Result @{ Success = $true; CompletionState = 'Submitted'; IsSimulated = $true; Summary = 'Pending demo'; Notes = '' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like 'FAILED / NOT COMPLETED:*' -and $BackgroundColor -eq 'DarkRed' }
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like 'PENDING:*' -and $BackgroundColor -eq 'DarkYellow' }
        Should -Invoke Write-Host -Times 0 -Exactly -ParameterFilter { $BackgroundColor -eq 'DarkGreen' }
    }
    It 'corrects duplicate serial and CI during entry before confirmation' {
        $script:uiAnswers = @('N', 'UI-ONE', 'UI-NEW', 'CI-ONE', 'CI-NEW', 'Desktop', 'Y', '0')
        Start-NewDeviceWorkflow -Records $script:uiRecords -CurrentSiteCode 'MI' | Should -Be 'MI'
        $script:uiRecords.Value.Count | Should -Be 3
        Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly
        $script:uiLines | Should -Contain 'Serial UI-ONE already identifies an existing workflow. Correct it or cancel to resume that device.'
        $script:uiLines | Should -Contain 'Configuration Item CI-ONE conflicts with an existing workflow. Enter the correct CI or 0 to cancel.'
    }
    It 'cancels a conflicted new device without creating saving or acknowledging again' {
        $script:uiAnswers = @('N', 'UI-ONE', '0')
        Start-NewDeviceWorkflow -Records $script:uiRecords -CurrentSiteCode 'MI' | Should -Be 'MI'
        $script:uiRecords.Value.Count | Should -Be 2
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Read-Host -Times 3 -Exactly
    }
    It 'rejects cross-identifier conflicts while allowing reuse of a removed CI' {
        $script:uiAnswers = @('CI-ONE', 'UI-NEW', 'UI-ONE', 'CI-NEW', 'CI-ONE', 'UI-ONE', '0')
        Read-NewDeviceIdentityField -Field Serial -Records $script:uiRecords | Should -Be 'UI-NEW'
        Read-NewDeviceIdentityField -Field ConfigItem -Records $script:uiRecords | Should -Be 'CI-NEW'
        $script:uiRecords.Value[0].Status = 'removed'
        Read-NewDeviceIdentityField -Field ConfigItem -Records $script:uiRecords | Should -Be 'CI-ONE'
        Read-NewDeviceIdentityField -Field Serial -Records $script:uiRecords | Should -BeNullOrEmpty
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }
    It 'retains the final identity guard when records change during confirmation' {
        $script:uiAnswers = @('N', 'UI-NEW', 'CI-NEW', 'Desktop', 'Y', '0')
        Mock Read-Host {
            if ($Prompt -like 'Proceed with these details*') { $script:uiRecords.Value += @{ Serial = 'UI-RACE'; ConfigItem = 'CI-NEW'; Status = 'new' } }
            $answer = $script:uiAnswers[0]; $script:uiAnswers = @($script:uiAnswers | Select-Object -Skip 1); return $answer
        }
        Start-NewDeviceWorkflow -Records $script:uiRecords -CurrentSiteCode 'MI' | Should -Be 'MI'
        @($script:uiRecords.Value | Where-Object Serial -eq 'UI-NEW').Count | Should -Be 0
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        $script:uiLines | Should -Contain 'Correct the identifiers below, or enter 0 to cancel and maintain the existing list.'
    }
    It 'maintains two independent devices without returning to the main menu' {
        $script:uiAnswers = @('new', '1', 'removed', '0')
        $script:selectionCount = 0
        Mock Select-DeviceFromRecords { $script:selectionCount++; return $Records.Value[$script:selectionCount - 1] }
        Update-DeviceStatus -Records $script:uiRecords
        $script:uiRecords.Value[0].Status | Should -Be 'new'
        $script:uiRecords.Value[1].Status | Should -Be 'removed'
        Should -Invoke Write-UserDeviceRecords -Times 2 -Exactly
        Should -Invoke Read-Host -Times 4 -Exactly
    }
    It 'refuses completed status and permits a correction without losing the device' {
        $script:uiAnswers = @('completed', 'new', '0')
        Update-DeviceStatus -Records $script:uiRecords
        $script:uiRecords.Value[0].Status | Should -Be 'new'
        $script:uiLines | Should -Contain 'Cannot mark this device completed. Required steps remain: A.'
        Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly
    }
    It 'does not save unchanged maintenance status' {
        $script:uiAnswers = @('', '0')
        Update-DeviceStatus -Records $script:uiRecords
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }
    It 'defaults archive selection and both safety prompts to cancellation' {
        Mock Reset-CurrentSessionState {}
        foreach ($answers in @(@(''), @('1', ''), @('1', 'y', ''))) {
            $script:uiAnswers = $answers
            $script:uiReadIndex = 0
            Show-SessionArchive -Records $script:uiRecords | Should -BeFalse
        }
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Reset-CurrentSessionState -Times 0 -Exactly
        $script:uiRecords.Value.Count | Should -Be 2
    }
    It 'saves then archives only after explicit confirmation and clears the active list' {
        $script:uiAnswers = @('1', 'y', 'clear')
        Mock Reset-CurrentSessionState { Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly; return , @() }
        Show-SessionArchive -Records $script:uiRecords | Should -BeTrue
        $script:uiRecords.Value.Count | Should -Be 0
        Should -Invoke Reset-CurrentSessionState -Times 1 -Exactly
    }
    It 'preserves the active list and does not archive when saving fails' {
        $script:uiAnswers = @('1', 'Y', 'CLEAR')
        Mock Reset-CurrentSessionState {}
        Mock Write-UserDeviceRecords { throw 'Synthetic archive save failure' }
        { Show-SessionArchive -Records $script:uiRecords } | Should -Throw '*archive save failure*'
        Should -Invoke Reset-CurrentSessionState -Times 0 -Exactly
        $script:uiRecords.Value.Count | Should -Be 2
    }
}

Describe 'Read-only build bench workflow guide' {
    BeforeAll {
        $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
        $tokens = $null
        $parseErrors = $null
        $ast = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
        if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
        foreach ($name in @('Get-EnabledManifestSteps', 'Show-BenchWorkflowGuide', 'Get-TerminalViewport', 'Get-ScreenTextPage', 'Read-BenchCommand', 'Read-ValidatedInput', 'Show-ScriptScreen')) {
            $definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name }, $true)
            . ([scriptblock]::Create($definition.Extent.Text))
        }
    }
    BeforeEach {
        $script:StepManifest = @(
            @{ Id = 'E'; DisplayName = 'First action'; Summary = 'First summary'; Notes = 'First detail'; ExecutionType = 'graph'; Enabled = $true; PrerequisiteStepIds = @(); IsConditional = $false }
            @{ Id = 'D'; DisplayName = 'Second action'; Summary = 'Second summary'; ExecutionType = 'guided'; Enabled = $true; PrerequisiteStepIds = @('E'); IsConditional = $false }
            @{ Id = 'F'; DisplayName = 'Recovery action'; Summary = 'Recovery summary'; ExecutionType = 'graph'; Enabled = $true; PrerequisiteStepIds = @('E'); IsConditional = $true }
            @{ Id = 'Z'; DisplayName = 'Disabled action'; Enabled = $false }
        )
        $script:guideLines = @()
        Mock Get-TerminalViewport { return @{ Width = 120; Height = 60 } }
        Mock Clear-Host {}
        Mock Write-Host { $script:guideLines += [string]$Object }
        Mock Read-Host { return '' }
    }
    It 'preserves workflow order and explains prerequisites and conditional recovery' {
        Show-BenchWorkflowGuide
        $script:guideLines.IndexOf('E. First action [Graph action]') | Should -BeLessThan $script:guideLines.IndexOf('D. Second action [Technician observation]')
        $script:guideLines | Should -Contain '   Requires: E'
        $script:guideLines | Should -Contain 'Conditional recovery - only after a recorded failure'
        $script:guideLines | Should -Not -Contain 'Z. Disabled action [Technician observation]'
    }
    It 'shows details for a lower-case step and returns on Enter without changing the manifest' {
        $before = $script:StepManifest | ConvertTo-Json -Depth 20
        $script:guideReads = 0
        Mock Read-Host { $script:guideReads++; if ($script:guideReads -eq 1) { return 'e' }; return '' }
        Show-BenchWorkflowGuide
        $script:guideLines | Should -Contain 'First detail'
        ($script:StepManifest | ConvertTo-Json -Depth 20) | Should -BeExactly $before
        Should -Invoke Read-Host -Times 2 -Exactly
    }
    It 'rejects an unknown letter without invoking a workflow action' {
        $script:guideReads = 0
        Mock Read-Host { $script:guideReads++; if ($script:guideReads -eq 1) { return 'z' }; return 'r' }
        Show-BenchWorkflowGuide
        Should -Invoke Read-Host -Times 2 -Exactly
    }
    It 'leaves existing device evidence and occupied bench positions unchanged' {
        $script:BuildBench = @{ Active = $true; Positions = @(@{ Index = 1; Serial = 'GUIDE-01'; ConfigItem = 'CI-01' }); Faults = @('Retained fault') }
        $records = @{ Value = @(@{ Serial = 'GUIDE-01'; Steps = @{ E = @{ Completed = $true; CompletionState = 'Verified' } } }) }
        $benchBefore = $script:BuildBench | ConvertTo-Json -Depth 20
        $recordsBefore = $records | ConvertTo-Json -Depth 20
        Show-BenchWorkflowGuide
        ($script:BuildBench | ConvertTo-Json -Depth 20) | Should -BeExactly $benchBefore
        ($records | ConvertTo-Json -Depth 20) | Should -BeExactly $recordsBefore
    }
    It 'explains conditional recovery prerequisites when its letter is selected' {
        $script:guideReads = 0
        Mock Read-Host { $script:guideReads++; if ($script:guideReads -eq 1) { return 'f' }; return 'r' }
        Show-BenchWorkflowGuide
        $script:guideLines | Should -Contain 'F. Recovery action'
        $script:guideLines | Should -Contain 'Recovery summary'
        $script:guideLines | Should -Contain 'Requires completed steps: E'
        Should -Invoke Read-Host -Times 2 -Exactly
    }
    It 'pages wrapped text within the available body rows' {
        $pages = Get-ScreenTextPage -Lines @('a very long line containing many words and averylongwordwithoutspaces1234567890', 'last line') -Viewport @{ Width = 20; Height = 13 } -Title 'Guide'
        $pages.Count | Should -BeGreaterThan 1
        foreach ($page in $pages) {
            $page.Lines.Count | Should -BeLessOrEqual 3
            foreach ($line in $page.Lines) { $line.Length | Should -BeLessOrEqual 20 }
        }
    }
    It 'keeps Previous available on the last page and redraws the blue header each time' {
        Mock Get-TerminalViewport { return @{ Width = 120; Height = 20 } }
        $script:guideAnswers = @('>', '<', '0')
        Mock Read-Host { $answer = $script:guideAnswers[0]; $script:guideAnswers = @($script:guideAnswers | Select-Object -Skip 1); return $answer }
        Show-BenchWorkflowGuide
        $script:guideLines | Should -Contain '<. Previous page'
        $script:guideLines | Should -Contain 'Last page'
        Should -Invoke Write-Host -Times 3 -Exactly -ParameterFilter { ([string]$Object).Trim() -like 'Autopilot Express - Workflow Step Guide*' -and $BackgroundColor -eq 'DarkBlue' }
    }
    It 'uses command then separated results in linear hosts without consuming extra input' {
        Mock Read-Host { $script:guideLines += 'COMMAND ENTERED'; return '0' }
        Read-BenchCommand -Lines @('FAILED: UI-ONE, action E', 'Retry remains blocked') -LinearOutput | Should -Be '0'
        $script:guideLines.IndexOf('COMMAND ENTERED') | Should -BeLessThan $script:guideLines.IndexOf('Recent results and messages (last five lines):')
        $script:guideLines | Should -Contain '------------------------------------------------------------'
        $script:guideLines | Should -Contain '  FAILED: UI-ONE, action E'
        Should -Invoke Read-Host -Times 1 -Exactly
    }
    It 'preserves N and P manifest step details using collision-free paging commands' {
        $script:StepManifest += @{ Id = 'N'; DisplayName = 'Sign in'; Summary = 'Sign-in detail'; ExecutionType = 'guided'; Enabled = $true; PrerequisiteStepIds = @(); IsConditional = $false }
        $script:StepManifest += @{ Id = 'P'; DisplayName = 'Update'; Summary = 'Update detail'; ExecutionType = 'guided'; Enabled = $true; PrerequisiteStepIds = @(); IsConditional = $false }
        Mock Get-TerminalViewport { return @{ Width = 120; Height = 20 } }
        $script:guideAnswers = @('>', 'n', 'p', 'STEP LIST', '0')
        Mock Read-Host { $answer = $script:guideAnswers[0]; $script:guideAnswers = @($script:guideAnswers | Select-Object -Skip 1); return $answer }
        Show-BenchWorkflowGuide
        $script:guideLines | Should -Contain '>. Next page'
        $script:guideLines | Should -Contain '<. Previous page'
        $script:guideLines | Should -Contain 'N. Sign in'
        $script:guideLines | Should -Contain 'Sign-in detail'
        $script:guideLines | Should -Contain 'P. Update'
        $script:guideLines | Should -Contain 'Update detail'
        Should -Invoke Read-Host -Times 5 -Exactly
    }
    It 'rebuilds page boundaries and clamps navigation after a window resize' {
        $script:viewportRead = 0
        Mock Get-TerminalViewport { $script:viewportRead++; return @{ Width = 120; Height = $(if ($script:viewportRead -eq 1) { 20 } else { 60 }) } }
        $script:guideAnswers = @('>', '0')
        Mock Read-Host { $answer = $script:guideAnswers[0]; $script:guideAnswers = @($script:guideAnswers | Select-Object -Skip 1); return $answer }
        Show-BenchWorkflowGuide
        Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { ([string]$Object).Trim() -like '*Workflow Step Guide | Page 1 of 1*' -and $BackgroundColor -eq 'DarkBlue' }
        Should -Invoke Read-Host -Times 2 -Exactly
    }
}

Describe 'Full Demo operator workflow' {
    BeforeEach {
        $script:previousLocalAppData = [Environment]::GetEnvironmentVariable('LOCALAPPDATA', 'Process')
        $isolatedLocalAppData = Join-Path $TestDrive ('local-app-data-{0}' -f [guid]::NewGuid().Guid)
        New-Item -ItemType Directory -Path $isolatedLocalAppData -ErrorAction Stop | Out-Null
        [Environment]::SetEnvironmentVariable('LOCALAPPDATA', $isolatedLocalAppData, 'Process')
    }

    AfterEach {
        [Environment]::SetEnvironmentVariable('LOCALAPPDATA', $script:previousLocalAppData, 'Process')
    }

    It 'stops before operational storage when bootstrap mode selection is interrupted' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'bootstrap-interrupted'
        New-Item -ItemType Directory -Path $rehearsalFolder | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        Mock Read-Host { throw 'Synthetic bootstrap cancellation' }
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            { & (Join-Path $rehearsalFolder 'autopilot-express.ps1') -Mode '' } | Should -Throw '*Synthetic bootstrap cancellation*'
            Should -Invoke Read-Host -Times 1 -Exactly -ParameterFilter { $Prompt -eq 'Select mode: Live or Demo (default: Demo)' }
            Test-Path -LiteralPath (Join-Path $rehearsalFolder 'data') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
        }
    }

    It 'rejects an invalid manifest before prompts or operational storage' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'invalid-manifest'
        New-Item -ItemType Directory -Path $rehearsalFolder | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $manifestPath = Join-Path $rehearsalFolder 'autopilot-express.manifest.json'
        $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
        $manifest.steps[0].actionName = 'UnsupportedAction'
        $manifest | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        Mock Read-Host { throw 'Unexpected prompt before manifest validation' }
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            { & (Join-Path $rehearsalFolder 'autopilot-express.ps1') -Mode Demo } | Should -Throw '*unsupported actionName*'
            Should -Invoke Read-Host -Times 0 -Exactly
            Test-Path -LiteralPath (Join-Path $rehearsalFolder 'data') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
        }
    }

    It 'rejects configured Shared storage before prompts or operational files' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'unsupported-shared'
        New-Item -ItemType Directory -Path $rehearsalFolder | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $runtimePath = Join-Path $rehearsalFolder 'autopilot-express.runtime.json'
        $runtime = Get-Content -LiteralPath $runtimePath -Raw | ConvertFrom-Json
        $runtime.storage.mode = 'Shared'
        $runtime | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $runtimePath -Encoding UTF8
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        Mock Read-Host { throw 'Unexpected prompt before storage-mode validation' }
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            { & (Join-Path $rehearsalFolder 'autopilot-express.ps1') -Mode Demo } | Should -Throw '*Shared storage is disabled*'
            Should -Invoke Read-Host -Times 0 -Exactly
            Test-Path -LiteralPath (Join-Path $rehearsalFolder 'data') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
        }
    }

    It 'stops before resume prompts for an interrupted device save' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'interrupted-save'
        $dataFolder = Join-Path $rehearsalFolder 'data'
        New-Item -ItemType Directory -Path $dataFolder -Force | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $markerPath = Join-Path $dataFolder ('autopilot-devices-demo-{0}.json.write-in-progress' -f $env:USERNAME)
        New-Item -ItemType File -Path $markerPath -Value 'interrupted' | Out-Null
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        Mock Read-Host { throw 'Unexpected prompt before interrupted-save check' }
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            { & (Join-Path $rehearsalFolder 'autopilot-express.ps1') -Mode Demo } | Should -Throw '*Interrupted save recovery is required*'
            Should -Invoke Read-Host -Times 0 -Exactly
            Get-Content -LiteralPath $markerPath -Raw | Should -BeExactly 'interrupted'
            Test-Path -LiteralPath (Join-Path $dataFolder 'autopilot-express-demo.session.lock') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
        }
    }

    It 'releases its reservation when actual startup fails' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'interrupted'
        New-Item -ItemType Directory -Path $rehearsalFolder | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        Mock Read-Host { throw 'Synthetic startup interruption' }
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            { & (Join-Path $rehearsalFolder 'autopilot-express.ps1') -Mode Demo } | Should -Throw '*Synthetic startup interruption*'
            Test-Path -LiteralPath (Join-Path $rehearsalFolder 'data/autopilot-express-demo.session.lock') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
        }
    }

    It 'stops before prompts when the local store is reserved' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'reserved'
        $dataFolder = Join-Path $rehearsalFolder 'data'
        New-Item -ItemType Directory -Path $dataFolder -Force | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $lockPath = Join-Path $dataFolder 'autopilot-express-demo.session.lock'
        New-Item -ItemType File -Path $lockPath -Value '{"Token":"owning-session"}' | Out-Null
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        Mock Read-Host { throw 'Unexpected prompt before storage reservation' }
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            { & (Join-Path $rehearsalFolder 'autopilot-express.ps1') -Mode Demo } | Should -Throw '*Cannot reserve local*'
            Should -Invoke Read-Host -Times 0 -Exactly
            (Get-Content -LiteralPath $lockPath -Raw | ConvertFrom-Json).Token | Should -Be 'owning-session'
            @(Get-ChildItem -LiteralPath $dataFolder -File).Count | Should -Be 1
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
        }
    }

    It 'persists incomplete work and completes only after every normal action' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'operator'
        New-Item -ItemType Directory -Path $rehearsalFolder | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $entryPoint = Join-Path $rehearsalFolder 'autopilot-express.ps1'
        $recordPath = Join-Path $rehearsalFolder ('data/autopilot-devices-demo-{0}.json' -f $env:USERNAME)
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        $previousInputState = $global:AutopilotExpressRehearsalInput
        $global:AutopilotExpressRehearsalInput = @{ Answers = @('1', '2', 'N', 'DEMO-FULL-01', 'CI-DEMO-01', 'Desktop', 'Y', ''); Index = 0 }
        foreach ($stepId in @('A', 'B', 'C', 'E', 'K', 'D', 'L', 'M', 'G', 'I', 'N', 'H')) {
            $global:AutopilotExpressRehearsalInput.Answers += @('3', '1', $stepId)
            if ($stepId -in @('K', 'L', 'M', 'N')) { $global:AutopilotExpressRehearsalInput.Answers += 'Y' }
            $global:AutopilotExpressRehearsalInput.Answers += ''
        }
        $global:AutopilotExpressRehearsalInput.Answers += @('3', '1', 'O', 'N', '', '0')
        Mock Read-Host {
            if ($global:AutopilotExpressRehearsalInput.Index -ge $global:AutopilotExpressRehearsalInput.Answers.Count) { throw ('Unexpected prompt: {0}' -f $Prompt) }
            $answer = $global:AutopilotExpressRehearsalInput.Answers[$global:AutopilotExpressRehearsalInput.Index]
            $global:AutopilotExpressRehearsalInput.Index++
            return $answer
        }
        Mock Clear-Host {}
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            & $entryPoint -Mode Demo
            $global:AutopilotExpressRehearsalInput.Index | Should -Be $global:AutopilotExpressRehearsalInput.Answers.Count
            Test-Path -LiteralPath $recordPath | Should -BeTrue
            $savedRecords = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
            $savedRecords = @($savedRecords)
            $savedRecords.Count | Should -Be 1
            $savedRecords[0].Serial | Should -Be 'DEMO-FULL-01'
            $savedRecords[0].GroupTag | Should -Be 'MI-Desktop'
            $savedRecords[0].Status | Should -Be 'in-progress'
            $savedRecords[0].Steps.O.CompletionState | Should -Be 'Submitted'
            $savedRecords[0].Steps.J | Should -BeNullOrEmpty

            $global:AutopilotExpressRehearsalInput.Answers = @('Y', '1', '3', '1', 'J', '', '3', '1', 'O', 'Y', '', '3', '1', 'P', 'Y', '', '3', '1', 'J', '1', '1', '', '0')
            $global:AutopilotExpressRehearsalInput.Index = 0
            & $entryPoint -Mode Demo
            $global:AutopilotExpressRehearsalInput.Index | Should -Be $global:AutopilotExpressRehearsalInput.Answers.Count
            $reloadedRecords = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
            $reloadedRecords = @($reloadedRecords)
            $reloadedRecords[0].RecordId | Should -Be $savedRecords[0].RecordId
            $reloadedRecords[0].Status | Should -Be 'completed'
            $reloadedRecords[0].CompletedAt | Should -Not -BeNullOrEmpty
            $reloadedRecords[0].FinalPrimaryUserPrincipalName | Should -Not -BeNullOrEmpty
            $manifest = Get-Content -LiteralPath (Join-Path $rehearsalFolder 'autopilot-express.manifest.json') -Raw | ConvertFrom-Json
            foreach ($definition in @($manifest.steps | Where-Object { $_.enabled -and $_.activationRequirement -ne 'RecoveryMode' })) {
                $reloadedRecords[0].Steps.($definition.id).CompletionState | Should -Be 'Simulated'
            }
            Test-Path -LiteralPath (Join-Path $rehearsalFolder 'data/autopilot-master-audit.json') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
            $global:AutopilotExpressRehearsalInput = $previousInputState
        }
    }

    It 'keeps two bench devices independent through induction, move, reload and dispatch' {
        $sourceFolder = Split-Path -Parent $PSScriptRoot
        $rehearsalFolder = Join-Path $TestDrive 'bench'
        New-Item -ItemType Directory -Path $rehearsalFolder | Out-Null
        foreach ($fileName in @('autopilot-express.ps1', 'autopilot-express.manifest.json', 'autopilot-express.runtime.json')) {
            Copy-Item -LiteralPath (Join-Path $sourceFolder $fileName) -Destination $rehearsalFolder
        }
        $entryPoint = Join-Path $rehearsalFolder 'autopilot-express.ps1'
        $recordPath = Join-Path $rehearsalFolder ('data/autopilot-devices-demo-{0}.json' -f $env:USERNAME)
        $benchPath = Join-Path $rehearsalFolder ('data/build-bench-demo-{0}.json' -f $env:USERNAME)
        $previousRoot = $env:PowerShellScriptingNewRoot
        $previousDefinitions = $env:AutopilotExpressDefinitionDirectory
        $previousInputState = $global:AutopilotExpressRehearsalInput
        $global:AutopilotExpressRehearsalInput = @{
            Answers = @(
                '1', '1', '3', 'Desktop',
                'I', '1', 'Y', 'Desktop', 'DEMO-BENCH-01', 'CI-BENCH-01',
                'I', '2', 'Y', 'Laptop', 'DEMO-BENCH-02', 'CI-BENCH-02',
                'I', '3', 'Y', 'Desktop', 'DEMO-BENCH-01', 'CI-BENCH-01',
                'S', 'DEMO-BENCH-02', 'C', 'CI-BENCH-01', 'A', 'C', '1', 'B',
                'M', '1', '2', '3', 'D', '3', 'V', 'CI-BENCH-02', '0', '', 'E', '0'
            )
            Index   = 0
        }
        Mock Read-Host {
            if ($global:AutopilotExpressRehearsalInput.Index -ge $global:AutopilotExpressRehearsalInput.Answers.Count) { throw ('Unexpected bench prompt: {0}' -f $Prompt) }
            $answer = $global:AutopilotExpressRehearsalInput.Answers[$global:AutopilotExpressRehearsalInput.Index]
            $global:AutopilotExpressRehearsalInput.Index++
            return $answer
        }
        Mock Clear-Host {}
        Mock Write-Host {}
        try {
            $env:AutopilotExpressDefinitionDirectory = $rehearsalFolder
            & $entryPoint -Mode Demo
            $global:AutopilotExpressRehearsalInput.Index | Should -Be $global:AutopilotExpressRehearsalInput.Answers.Count
            $savedRecords = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
            $savedRecords = @($savedRecords)
            $savedRecords.Count | Should -Be 2
            $desktop = $savedRecords | Where-Object { $_.Serial -eq 'DEMO-BENCH-01' }
            $laptop = $savedRecords | Where-Object { $_.Serial -eq 'DEMO-BENCH-02' }
            $desktop.GroupTag | Should -Be 'MI-Desktop'
            $laptop.GroupTag | Should -Be 'MI-Laptop'
            $desktop.Steps.B.CompletionState | Should -Be 'Simulated'
            $laptop.Steps.A.CompletionState | Should -Be 'Simulated'
            $laptop.Steps.B | Should -BeNullOrEmpty
            $bench = Get-Content -LiteralPath $benchPath -Raw | ConvertFrom-Json
            $bench.Positions[0].Serial | Should -BeNullOrEmpty
            $bench.Positions[1].Serial | Should -Be 'DEMO-BENCH-02'
            $bench.Positions[2].Serial | Should -Be 'DEMO-BENCH-01'
            Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*serial is already on the bench*' }
            Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -like '*Position 2 is occupied*' }
            Should -Invoke Write-Host -Times 2 -ParameterFilter { $Object -like '*Cannot dispatch device*' }
            Should -Invoke Read-Host -Times 1 -ParameterFilter { $Prompt -like 'Command (Enter refreshes)*' }

            $global:AutopilotExpressRehearsalInput.Answers = @('Y', '1', '1')
            foreach ($stepId in @('C', 'E', 'K', 'D', 'L', 'M', 'G', 'I', 'N', 'H', 'O', 'P', 'J')) {
                $global:AutopilotExpressRehearsalInput.Answers += @('C', 'CI-BENCH-01', $stepId)
                if ($stepId -in @('K', 'L', 'M', 'N', 'O', 'P')) { $global:AutopilotExpressRehearsalInput.Answers += 'Y' }
                if ($stepId -eq 'J') { $global:AutopilotExpressRehearsalInput.Answers += @('1', '1') }
            }
            $global:AutopilotExpressRehearsalInput.Answers += @('D', 'DEMO-BENCH-01', 'E', '0')
            $global:AutopilotExpressRehearsalInput.Index = 0
            & $entryPoint -Mode Demo
            $global:AutopilotExpressRehearsalInput.Index | Should -Be $global:AutopilotExpressRehearsalInput.Answers.Count
            $reloadedRecords = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
            $reloadedRecords = @($reloadedRecords)
            $finished = $reloadedRecords | Where-Object { $_.Serial -eq 'DEMO-BENCH-01' }
            $remaining = $reloadedRecords | Where-Object { $_.Serial -eq 'DEMO-BENCH-02' }
            $finished.RecordId | Should -Be $desktop.RecordId
            $finished.Status | Should -Be 'completed'
            $remaining.RecordId | Should -Be $laptop.RecordId
            $remaining.Status | Should -Be 'in-progress'
            $remaining.Steps.B | Should -BeNullOrEmpty
            Should -Invoke Write-Host -Times 1 -Exactly -ParameterFilter { $Object -eq 'Remaining checklist handoffs (v1.4, steps 24-26)' }
            $bench = Get-Content -LiteralPath $benchPath -Raw | ConvertFrom-Json
            $bench.Positions[2].Serial | Should -BeNullOrEmpty
            $bench.Positions[1].Serial | Should -Be 'DEMO-BENCH-02'

            $global:AutopilotExpressRehearsalInput.Answers = @('Y', '1', '1', 'R', 'CI-BENCH-02', 'E', '0')
            $global:AutopilotExpressRehearsalInput.Index = 0
            & $entryPoint -Mode Demo
            $global:AutopilotExpressRehearsalInput.Index | Should -Be $global:AutopilotExpressRehearsalInput.Answers.Count
            $bench = Get-Content -LiteralPath $benchPath -Raw | ConvertFrom-Json
            @($bench.Positions | Where-Object { $_.Serial }).Count | Should -Be 0
            $retainedRecords = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
            @($retainedRecords).Count | Should -Be 2
            Test-Path -LiteralPath (Join-Path $rehearsalFolder 'data/autopilot-master-audit.json') | Should -BeFalse
        }
        finally {
            $env:PowerShellScriptingNewRoot = $previousRoot
            $env:AutopilotExpressDefinitionDirectory = $previousDefinitions
            $global:AutopilotExpressRehearsalInput = $previousInputState
        }
    }
}