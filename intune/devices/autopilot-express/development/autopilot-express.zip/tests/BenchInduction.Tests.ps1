<#
.SYNOPSIS
    Checks local bench identity and metadata guards before state or storage changes.
.DESCRIPTION
    Extracts the actual induction and collection helper. Record construction and
    persistence are mocked; no operational files, physical devices or tenant calls occur.
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('Add-DeviceToBenchPosition', 'Add-DeviceRecord', 'Assert-DeviceRecordIdentity')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if (-not $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function New-DeviceRecordObject {
        [CmdletBinding(SupportsShouldProcess)]
        [OutputType([hashtable])]
        param($Serial, $ConfigItem, $SiteCode, $DeviceType, $GroupTag)
        if ($PSCmdlet.ShouldProcess($Serial, 'Create synthetic record')) {
            return @{ Serial = $Serial; ConfigItem = $ConfigItem; SiteCode = $SiteCode; DeviceType = $DeviceType; GroupTag = $GroupTag; Status = 'new'; Steps = @{} }
        }
    }
    function Write-UserDeviceRecords { param($Records) throw ('Unexpected save: {0}' -f @($Records).Count) }
    function Save-BuildBenchState { throw 'Unexpected bench save' }
}

Describe 'Local bench induction safeguards' {
    BeforeEach {
        $script:BuildBench = @{ Positions = @(@{ Index = 1; Serial = ''; ConfigItem = '' }, @{ Index = 2; Serial = ''; ConfigItem = '' }) }
        $script:records = @{ Value = @() }
        $script:record = @{ Serial = 'BENCH-01'; ConfigItem = 'CI-01'; SiteCode = 'MI'; DeviceType = 'Desktop'; Status = 'in-progress'; Steps = @{ A = @{ CompletionState = 'Simulated' } } }
        Mock Write-UserDeviceRecords { Save-BuildBenchState }
        Mock Save-BuildBenchState {}
        Mock Write-Host {}
    }

    It 'creates one new record and saves the intended slot' {
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:records.Value.Count | Should -Be 1
        $script:records.Value[0].GroupTag | Should -Be 'MI-Desktop'
        $script:BuildBench.Positions[0].Serial | Should -Be 'BENCH-01'
        Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly
        Should -Invoke Save-BuildBenchState -Times 1 -Exactly
    }

    It 'reuses a unique matching record without losing its progress' {
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:records.Value.Count | Should -Be 1
        $script:records.Value[0].Steps.A.CompletionState | Should -Be 'Simulated'
        $script:BuildBench.Positions[0].ConfigItem | Should -Be 'CI-01'
    }

    It 'rejects duplicate serial slots without changing state or saving' {
        $script:BuildBench.Positions[0].Serial = 'BENCH-01'
        $script:BuildBench.Positions[0].ConfigItem = 'CI-01'
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 2 -Serial 'bench-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[1].Serial | Should -Be ''
        $script:records.Value.Count | Should -Be 1
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }

    It 'does not replace an occupied slot' {
        $script:BuildBench.Positions[0].Serial = 'OTHER-DEVICE'
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be 'OTHER-DEVICE'
        $script:records.Value.Count | Should -Be 0
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }

    It 'rejects ambiguous workflow records' {
        $script:records.Value = @($script:record, $script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be ''
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }

    It 'rejects a removed workflow record' {
        $script:record.Status = 'removed'
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be ''
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }

    It 'rejects mismatched <Field> rather than relabelling progress' -TestCases @(
        @{ Field = 'ConfigItem'; Value = 'OTHER-CI' }
        @{ Field = 'SiteCode'; Value = 'MU' }
        @{ Field = 'DeviceType'; Value = 'Laptop' }
    ) {
        param($Field, $Value)
        $script:record[$Field] = $Value
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be ''
        $script:record[$Field] | Should -Be $Value
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }

    It 'rejects another active device using the same Configuration Item' {
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 2 -Serial 'BENCH-02' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Laptop' -Records $script:records
        $script:records.Value.Count | Should -Be 1
        $script:BuildBench.Positions[1].Serial | Should -Be ''
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }
}<#
.SYNOPSIS
    Checks local bench identity and metadata guards before state or storage changes.
.DESCRIPTION
    Extracts the actual induction and collection helper. Record construction and
    persistence are mocked; no operational files, physical devices or tenant calls occur.
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('Add-DeviceToBenchPosition', 'Add-DeviceRecord', 'Assert-DeviceRecordIdentity')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if (-not $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function New-DeviceRecordObject {
        [CmdletBinding(SupportsShouldProcess)]
        [OutputType([hashtable])]
        param($Serial, $ConfigItem, $SiteCode, $DeviceType, $GroupTag)
        if ($PSCmdlet.ShouldProcess($Serial, 'Create synthetic record')) {
            return @{ Serial = $Serial; ConfigItem = $ConfigItem; SiteCode = $SiteCode; DeviceType = $DeviceType; GroupTag = $GroupTag; Status = 'new'; Steps = @{} }
        }
    }
    function Write-UserDeviceRecords { param($Records) throw ('Unexpected save: {0}' -f @($Records).Count) }
    function Save-BuildBenchState { throw 'Unexpected bench save' }
}

Describe 'Local bench induction safeguards' {
    BeforeEach {
        $script:BuildBench = @{ Positions = @(@{ Index = 1; Serial = ''; ConfigItem = '' }, @{ Index = 2; Serial = ''; ConfigItem = '' }) }
        $script:records = @{ Value = @() }
        $script:record = @{ Serial = 'BENCH-01'; ConfigItem = 'CI-01'; SiteCode = 'MI'; DeviceType = 'Desktop'; Status = 'in-progress'; Steps = @{ A = @{ CompletionState = 'Simulated' } } }
        Mock Write-UserDeviceRecords { Save-BuildBenchState }
        Mock Save-BuildBenchState {}
        Mock Write-Host {}
    }

    It 'creates one new record and saves the intended slot' {
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:records.Value.Count | Should -Be 1
        $script:records.Value[0].GroupTag | Should -Be 'MI-Desktop'
        $script:BuildBench.Positions[0].Serial | Should -Be 'BENCH-01'
        Should -Invoke Write-UserDeviceRecords -Times 1 -Exactly
        Should -Invoke Save-BuildBenchState -Times 1 -Exactly
    }

    It 'reuses a unique matching record without losing its progress' {
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:records.Value.Count | Should -Be 1
        $script:records.Value[0].Steps.A.CompletionState | Should -Be 'Simulated'
        $script:BuildBench.Positions[0].ConfigItem | Should -Be 'CI-01'
    }

    It 'rejects duplicate serial slots without changing state or saving' {
        $script:BuildBench.Positions[0].Serial = 'BENCH-01'
        $script:BuildBench.Positions[0].ConfigItem = 'CI-01'
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 2 -Serial 'bench-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[1].Serial | Should -Be ''
        $script:records.Value.Count | Should -Be 1
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }

    It 'does not replace an occupied slot' {
        $script:BuildBench.Positions[0].Serial = 'OTHER-DEVICE'
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be 'OTHER-DEVICE'
        $script:records.Value.Count | Should -Be 0
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }

    It 'rejects ambiguous workflow records' {
        $script:records.Value = @($script:record, $script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be ''
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }

    It 'rejects a removed workflow record' {
        $script:record.Status = 'removed'
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be ''
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }

    It 'rejects mismatched <Field> rather than relabelling progress' -TestCases @(
        @{ Field = 'ConfigItem'; Value = 'OTHER-CI' }
        @{ Field = 'SiteCode'; Value = 'MU' }
        @{ Field = 'DeviceType'; Value = 'Laptop' }
    ) {
        param($Field, $Value)
        $script:record[$Field] = $Value
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 1 -Serial 'BENCH-01' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Desktop' -Records $script:records
        $script:BuildBench.Positions[0].Serial | Should -Be ''
        $script:record[$Field] | Should -Be $Value
        Should -Invoke Write-UserDeviceRecords -Times 0 -Exactly
    }

    It 'rejects another active device using the same Configuration Item' {
        $script:records.Value = @($script:record)
        Add-DeviceToBenchPosition -Position 2 -Serial 'BENCH-02' -ConfigItem 'CI-01' -SiteCode 'MI' -DeviceType 'Laptop' -Records $script:records
        $script:records.Value.Count | Should -Be 1
        $script:BuildBench.Positions[1].Serial | Should -Be ''
        Should -Invoke Save-BuildBenchState -Times 0 -Exactly
    }
}