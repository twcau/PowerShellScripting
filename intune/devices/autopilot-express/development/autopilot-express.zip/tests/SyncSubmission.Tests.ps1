<#
.SYNOPSIS
    Tests durable sync acceptance separately from technician confirmation.
.DESCRIPTION
    Extracts production functions without starting the CLI. Requests, refreshed
    targets and input are mocked; a wrapper exercises the real UTF-8 writer in
    TestDrive, never operational storage or a tenant.
.FILECREATED
    2026-10-08
.FILELASTUPDATED
    2026-10-08
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('New-OperationResult', 'Get-SyncSubmissionReceiptPath', 'Get-SyncSubmissionReceipt', 'Invoke-StepRetryFailedApps', 'New-ParentDirectory', 'Get-StorageFileEncoding', 'Assert-FileWriteRecoveryState', 'Write-Utf8File')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if ($null -eq $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    $script:realWriter = ${function:Write-Utf8File}
    function Assert-ActiveStorageReservation { throw 'Unexpected reservation check' }
    function Resolve-LiveAutopilotContext { param($Device) throw ('Unexpected refresh: {0}' -f $Device.Serial) }
    function Invoke-GraphApiRequest { param($Method, $Uri) throw ('Unexpected request: {0} {1}' -f $Method, $Uri) }
    function Read-ValidatedInput {
        param($Prompt, $Default, $Type, $Choices)
        throw ('Unexpected input: {0} {1} {2} {3}' -f $Prompt, $Default, $Type, ($Choices -join ','))
    }
}

Describe 'Sync submission receipt' {
    BeforeEach {
        $script:Runtime = @{ IsDemoMode = $false }
        $script:GraphSession = @{ TenantId = 'tenant-1' }
        $script:SyncSubmissionPersistenceFailure = $false
        $script:Storage = @{ DataPath = (Join-Path $TestDrive ([guid]::NewGuid().Guid)) }
        New-Item -ItemType Directory -Path $script:Storage.DataPath | Out-Null
        $script:device = @{ RecordId = 'record-1'; Serial = 'SERIAL1'; ManagedDeviceId = 'cached' }
        $script:step = @{ ActionName = 'RetryFailedApplications' }
        $script:path = Join-Path $script:Storage.DataPath 'sync-submission-record-1.json'
        Mock Assert-ActiveStorageReservation {}
        Mock Resolve-LiveAutopilotContext { $Device.ManagedDeviceId = 'current-managed' }
        Mock Invoke-GraphApiRequest {}
        Mock Write-Utf8File { & $script:realWriter -Path $Path -Content $Content }
        Mock Read-ValidatedInput {
            Test-Path -LiteralPath $script:path | Should -BeTrue
            return 'Y'
        }
    }

    It 'persists accepted refreshed evidence before input and never repeats POST' {
        $first = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $first.CompletionState | Should -Be 'TechnicianConfirmed'
        $saved = Get-Content -LiteralPath $script:path -Raw | ConvertFrom-Json
        $saved.RecordId | Should -Be 'record-1'
        $saved.Serial | Should -Be 'SERIAL1'
        $saved.ManagedDeviceId | Should -Be 'current-managed'
        $saved.TenantId | Should -Be 'tenant-1'
        ([DateTimeOffset]$saved.SubmittedAt).ToString('o') | Should -Be $first.Data.SubmittedAt
        $second = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $second.CompletionState | Should -Be 'TechnicianConfirmed'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly -ParameterFilter { $Method -eq 'POST' -and $Uri -eq 'https://graph.microsoft.com/v1.0/deviceManagement/managedDevices/current-managed/syncDevice' }
        Should -Invoke Write-Utf8File -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 2 -Exactly
    }

    It 'retains Submitted after negative input and prompt failure without resubmitting' {
        Mock Read-ValidatedInput { return 'N' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Submitted'
        $result.Data.SyncAccepted | Should -BeTrue
        Mock Read-ValidatedInput { throw 'Input interrupted' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Submitted'
        $result.Notes | Should -Match 'Input interrupted'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Write-Utf8File -Times 1 -Exactly
    }

    It 'creates no receipt or confirmation when POST fails' {
        Mock Invoke-GraphApiRequest { throw 'POST rejected' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Data.SyncAccepted | Should -BeFalse
        Test-Path -LiteralPath $script:path | Should -BeFalse
        Should -Invoke Write-Utf8File -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'resumes from disk after the first confirmation throws and record state is lost' {
        Mock Read-ValidatedInput { throw 'First input interrupted' }
        $first = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $first.CompletionState | Should -Be 'Submitted'
        $first.Data.ReceiptPersisted | Should -BeTrue
        $first.Notes | Should -Match 'First input interrupted'
        $script:device = @{ RecordId = 'record-1'; Serial = 'SERIAL1'; ManagedDeviceId = 'stale-after-restart' }
        Mock Read-ValidatedInput { return 'Y' }
        $second = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $second.CompletionState | Should -Be 'TechnicianConfirmed'
        $second.Data.SubmittedAt | Should -BeExactly $first.Data.SubmittedAt
        $second.Data.ManagedDeviceId | Should -BeExactly 'current-managed'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Write-Utf8File -Times 1 -Exactly
    }

    It 'keeps receipts per RecordId without overwriting other records or all-record state' {
        $recordsPath = Join-Path $script:Storage.DataPath 'allrecords.json'
        Set-Content -LiteralPath $recordsPath -Value '[{"Serial":"DO-NOT-OVERWRITE"}]' -NoNewline
        Mock Read-ValidatedInput { return 'N' }
        $first = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $originalReceipt = Get-Content -LiteralPath $script:path -Raw
        $script:device = @{ RecordId = 'record-2'; Serial = 'SERIAL2'; ManagedDeviceId = 'cached' }
        $second = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $first.CompletionState | Should -Be 'Submitted'
        $second.CompletionState | Should -Be 'Submitted'
        Get-Content -LiteralPath $script:path -Raw | Should -BeExactly $originalReceipt
        $other = Get-Content -LiteralPath (Join-Path $script:Storage.DataPath 'sync-submission-record-2.json') -Raw | ConvertFrom-Json
        $other.RecordId | Should -BeExactly 'record-2'
        $other.Serial | Should -BeExactly 'SERIAL2'
        Get-Content -LiteralPath $recordsPath -Raw | Should -BeExactly '[{"Serial":"DO-NOT-OVERWRITE"}]'
        Should -Invoke Invoke-GraphApiRequest -Times 2 -Exactly
    }

    It 'refuses a changed <Field> without POST, confirmation or retargeting the receipt' -ForEach @(
        @{ Field = 'ManagedDeviceId' }, @{ Field = 'Serial' }, @{ Field = 'RecordId' }, @{ Field = 'TenantId' }
    ) {
        Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step | Out-Null
        $receipt = @{ RecordId = 'record-1'; Serial = 'SERIAL1'; ManagedDeviceId = 'current-managed'; TenantId = 'tenant-1'; SubmittedAt = (Get-Date -Format o) }
        $receipt[$Field] = 'different-target'
        Set-Content -LiteralPath $script:path -Value ($receipt | ConvertTo-Json -Compress) -NoNewline
        $originalReceipt = Get-Content -LiteralPath $script:path -Raw
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Notes | Should -Match ('target changed \({0}\)' -f $Field)
        Get-Content -LiteralPath $script:path -Raw | Should -BeExactly $originalReceipt
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 1 -Exactly
        Should -Invoke Write-Utf8File -Times 1 -Exactly
    }

    It 'rejects re-enrolment even when a cached managed identity matches the receipt' {
        Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step | Out-Null
        Mock Resolve-LiveAutopilotContext { $Device.ManagedDeviceId = 'reenrolled-managed' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Notes | Should -Match 'target changed \(ManagedDeviceId\)'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 1 -Exactly
    }

    It 'accepts GUID RecordId as well as fixture identifiers' {
        $script:device.RecordId = [guid]::NewGuid().Guid
        Mock Read-ValidatedInput { return 'Y' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'TechnicianConfirmed'
        Test-Path -LiteralPath (Join-Path $script:Storage.DataPath ('sync-submission-{0}.json' -f $script:device.RecordId)) | Should -BeTrue
    }

    It 'rejects unsafe RecordId <Label> before any POST or write' -ForEach @(
        @{ Label = 'empty'; Value = '' }, @{ Label = 'null'; Value = $null },
        @{ Label = 'number'; Value = 17 }, @{ Label = 'traversal'; Value = '../outside' },
        @{ Label = 'backslash'; Value = '..\outside' }, @{ Label = 'rooted'; Value = 'C:\outside' },
        @{ Label = 'dot'; Value = '.' }, @{ Label = 'whitespace'; Value = 'record 1' },
        @{ Label = 'newline'; Value = "record-1`n" }
    ) {
        $script:device.RecordId = $Value
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
        Should -Invoke Write-Utf8File -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'rejects malformed receipt <Label> without POST or confirmation' -ForEach @(
        @{ Label = 'broken JSON'; Json = '{' }, @{ Label = 'null root'; Json = 'null' },
        @{ Label = 'array root'; Json = '[{"RecordId":"record-1"}]' },
        @{ Label = 'fully populated singleton array'; Json = '[{"RecordId":"record-1","Serial":"SERIAL1","ManagedDeviceId":"current-managed","TenantId":"tenant-1","SubmittedAt":"2026-10-08T12:00:00.0000000Z"}]' },
        @{ Label = 'missing fields'; Json = '{}' },
        @{ Label = 'numeric RecordId'; Field = 'RecordId'; Value = 42 },
        @{ Label = 'unsafe RecordId'; Field = 'RecordId'; Value = '../outside' },
        @{ Label = 'empty Serial'; Field = 'Serial'; Value = '' },
        @{ Label = 'array Serial'; Field = 'Serial'; Value = @('SERIAL1') },
        @{ Label = 'Boolean ManagedDeviceId'; Field = 'ManagedDeviceId'; Value = $true },
        @{ Label = 'null TenantId'; Field = 'TenantId'; Value = $null },
        @{ Label = 'number TenantId'; Field = 'TenantId'; Value = 7 },
        @{ Label = 'missing timestamp'; Field = 'SubmittedAt'; Value = $null },
        @{ Label = 'numeric timestamp'; Field = 'SubmittedAt'; Value = 123 },
        @{ Label = 'locale timestamp'; Field = 'SubmittedAt'; Value = '08/10/2026' },
        @{ Label = 'impossible ISO date'; Field = 'SubmittedAt'; Value = '2026-02-30T12:00:00.0000000Z' },
        @{ Label = 'no ISO offset'; Field = 'SubmittedAt'; Value = '2026-10-08T12:00:00.0000000' }
    ) {
        if ($Json) { $content = $Json }
        else {
            $receipt = @{ RecordId = 'record-1'; Serial = 'SERIAL1'; ManagedDeviceId = 'current-managed'; TenantId = 'tenant-1'; SubmittedAt = (Get-Date -Format o) }
            $receipt[$Field] = $Value
            $content = $receipt | ConvertTo-Json -Compress
        }
        Set-Content -LiteralPath $script:path -Value $content -NoNewline
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        Get-Content -LiteralPath $script:path -Raw | Should -BeExactly $content
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
        Should -Invoke Write-Utf8File -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'blocks unresolved receipt recovery artefact <Suffix>' -ForEach @(
        @{ Suffix = '.write-in-progress' }, @{ Suffix = '.pending' }, @{ Suffix = '.previous' }
    ) {
        Set-Content -LiteralPath ('{0}{1}' -f $script:path, $Suffix) -Value 'retained-evidence' -NoNewline
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Notes | Should -Match 'Interrupted save recovery'
        Get-Content -LiteralPath ('{0}{1}' -f $script:path, $Suffix) -Raw | Should -BeExactly 'retained-evidence'
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
        Should -Invoke Write-Utf8File -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'checks recovery artefacts before reading an otherwise valid receipt' {
        Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step | Out-Null
        Set-Content -LiteralPath ('{0}.write-in-progress' -f $script:path) -Value 'unfinished'
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Notes | Should -Match 'Interrupted save recovery'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 1 -Exactly
    }

    It 'records accepted evidence and stops every subsequent sync if persistence fails before an artefact exists' {
        Mock Write-Utf8File { throw 'Synthetic receipt writer failure' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Submitted'
        $result.Success | Should -BeFalse
        $result.Data.SyncAccepted | Should -BeTrue
        $result.Data.ReceiptPersisted | Should -BeFalse
        $result.Data.DurableGap | Should -BeTrue
        $result.Data.ManagedDeviceId | Should -BeExactly 'current-managed'
        $result.Data.SubmittedAt | Should -Not -BeNullOrEmpty
        $result.Notes | Should -Match 'durability across restart is unknown'
        Test-Path -LiteralPath $script:path | Should -BeFalse
        { Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step } | Should -Throw '*Further sync is stopped*'
        $script:device.RecordId = 'record-2'
        { Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step } | Should -Throw '*Further sync is stopped*'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'retains the real writer marker on failure and blocks replay after an in-memory reset' {
        Mock Set-Content { throw 'Synthetic staging failure' } -ParameterFilter { $LiteralPath -like '*.pending' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Submitted'
        $result.Data.SyncAccepted | Should -BeTrue
        Test-Path -LiteralPath ('{0}.write-in-progress' -f $script:path) | Should -BeTrue
        $script:SyncSubmissionPersistenceFailure = $false
        $resumed = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $resumed.CompletionState | Should -Be 'Failed'
        $resumed.Notes | Should -Match 'Interrupted save recovery'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Write-Utf8File -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'requires the active reservation before receipt access or POST' {
        Mock Assert-ActiveStorageReservation { throw 'Reservation ownership changed' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Notes | Should -Match 'Reservation ownership changed'
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
        Should -Invoke Write-Utf8File -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }

    It 'supports absent tenant context without inventing a tenant binding' {
        $script:GraphSession = @{}
        $first = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $first.CompletionState | Should -Be 'TechnicianConfirmed'
        $first.Data.ContainsKey('TenantId') | Should -BeFalse
        $second = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $second.CompletionState | Should -Be 'TechnicianConfirmed'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
    }

    It 'refuses a receipt lacking tenant evidence when the current tenant is available' {
        $script:GraphSession = @{}
        Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step | Out-Null
        $script:GraphSession = @{ TenantId = 'tenant-1' }
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Failed'
        $result.Notes | Should -Match 'target changed \(TenantId\)'
        Should -Invoke Invoke-GraphApiRequest -Times 1 -Exactly
        Should -Invoke Read-ValidatedInput -Times 1 -Exactly
    }

    It 'leaves Demo unchanged without receipt access, filesystem writes, refresh or input' {
        $script:Runtime.IsDemoMode = $true
        $script:SyncSubmissionPersistenceFailure = $true
        $script:device.RecordId = '../invalid-for-live'
        $result = Invoke-StepRetryFailedApps -Device $script:device -StepDefinition $script:step
        $result.CompletionState | Should -Be 'Simulated'
        $result.Success | Should -BeTrue
        @(Get-ChildItem -LiteralPath $script:Storage.DataPath).Count | Should -Be 0
        Should -Invoke Assert-ActiveStorageReservation -Times 0 -Exactly
        Should -Invoke Resolve-LiveAutopilotContext -Times 0 -Exactly
        Should -Invoke Invoke-GraphApiRequest -Times 0 -Exactly
        Should -Invoke Write-Utf8File -Times 0 -Exactly
        Should -Invoke Read-ValidatedInput -Times 0 -Exactly
    }
}