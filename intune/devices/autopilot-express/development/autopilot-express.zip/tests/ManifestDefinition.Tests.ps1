<#
.SYNOPSIS
    Validate manifest contracts without operational storage or tenant access.
.DESCRIPTION
    Uses the actual loader and current JSON as the baseline, then injects invalid
    definitions. Requires Pester 5 and FullLanguage for source parsing.
#>
BeforeAll {
    $definitionRoot = Split-Path -Parent $PSScriptRoot
    $tokens = $null
    $parseErrors = $null
    $script:sourceAst = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $definitionRoot 'autopilot-express.ps1'), [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('ConvertTo-NormalisedValue', 'Assert-ManifestDefinition', 'Test-ManifestDependencyGraph', 'Initialize-AutopilotExpressDefinitions')) {
        $definition = $script:sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        if (-not $definition) { throw ('Missing function: {0}' -f $functionName) }
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    $script:manifestJson = Get-Content -LiteralPath (Join-Path $definitionRoot 'autopilot-express.manifest.json') -Raw
    function Get-RuntimeConfigFilePath { return 'synthetic-runtime' }
    function Get-ManifestFilePath { return 'synthetic-manifest' }
    function Read-JsonDefinitionFile { param($Path, $Description) throw ('Unexpected read: {0} {1}' -f $Description, $Path) }
    function Write-AutopilotExpressLog { param($Message, $Level) throw ('Unexpected log: {0} {1}' -f $Level, $Message) }
}

Describe 'Manifest definition startup contract' {
    BeforeEach {
        $script:manifest = ConvertTo-NormalisedValue -Value ($script:manifestJson | ConvertFrom-Json)
        $script:RuntimeConfig = @{ sentinel = 'old-runtime' }
        $script:Config = @{ OrganisationName = 'old-organisation' }
        $script:StepManifest = @(@{ Id = 'old-step' })
        $script:WorkflowPhases = @(@{ Id = 'old-phase' })
        Mock Read-JsonDefinitionFile {
            if ($Path -eq 'synthetic-manifest') { return $script:manifest }
            return @{ organisationName = 'new-organisation' }
        }
        Mock Write-AutopilotExpressLog {}
    }

    It 'loads the current manifest with all 17 steps and six phases' {
        Initialize-AutopilotExpressDefinitions
        $script:StepManifest.Count | Should -Be 17
        $script:WorkflowPhases.Count | Should -Be 6
        $script:Config.OrganisationName | Should -Be 'new-organisation'
    }

    It 'displays every prerequisite before its dependent action without changing step IDs' {
        Initialize-AutopilotExpressDefinitions
        $displayedIds = @($script:StepManifest.Id)
        ($displayedIds | Sort-Object) -join ',' | Should -Be 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q'
        $displayedEarlier = @()
        foreach ($step in $script:StepManifest) {
            foreach ($prerequisiteId in $step.PrerequisiteStepIds) {
                $prerequisiteId | Should -BeIn $displayedEarlier -Because ('step {0} depends on {1}' -f $step.Id, $prerequisiteId)
            }
            $displayedEarlier += $step.Id
        }
    }

    It 'includes every enabled action in exactly one workflow phase' {
        Initialize-AutopilotExpressDefinitions
        $phaseActions = @($script:WorkflowPhases | ForEach-Object { $_.ActionNames })
        foreach ($step in $script:StepManifest | Where-Object { $_.Enabled }) {
            @($phaseActions | Where-Object { $_ -eq $step.ActionName }).Count | Should -Be 1
        }
        $completion = $script:WorkflowPhases | Where-Object { $_.Id -eq 'PhysicalCompletion' }
        $completion.ActionNames | Should -Contain 'RetryFailedApplications'
    }

    It 'preserves application retry prerequisites and conditional recovery activation' {
        Initialize-AutopilotExpressDefinitions
        $retry = $script:StepManifest | Where-Object { $_.ActionName -eq 'RetryFailedApplications' }
        $retry.Id | Should -Be 'H'
        ($retry.PrerequisiteStepIds -join ',') | Should -Be 'G,N'
        foreach ($actionName in @('ClearUserlessEnrollmentStatus', 'ConfirmRecoveryReadiness')) {
            $recovery = $script:StepManifest | Where-Object { $_.ActionName -eq $actionName }
            $recovery.ActivationRequirement | Should -Be 'RecoveryMode'
            ($recovery.PrerequisiteStepIds -join ',') | Should -Be 'A'
        }
    }

    It 'accepts schema 1.6 patch revisions and rejects unsupported versions' {
        $script:manifest.manifestVersion = '1.6.12'
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Not -Throw
        foreach ($version in @($null, 1, '', '1.6', '1.6.0-preview', '1.5.0', '1.7.0', '2.0.0', '1.6.01')) {
            $script:manifest.manifestVersion = $version
            { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*manifestVersion*'
        }
    }

    It 'rejects a non-object definition and missing empty or scalar top-level arrays' {
        { Assert-ManifestDefinition -Manifest $null } | Should -Throw '*JSON object*'
        foreach ($field in @('steps', 'workflowPhases')) {
            foreach ($value in @($null, @(), 'wrong', @{})) {
                $candidate = ConvertTo-NormalisedValue -Value ($script:manifestJson | ConvertFrom-Json)
                $candidate[$field] = $value
                { Assert-ManifestDefinition -Manifest $candidate } | Should -Throw '*non-empty JSON array*'
            }
        }
    }

    It 'rejects incomplete steps instead of silently dropping them' {
        $script:manifest.steps[0].Remove('actionName')
        { Initialize-AutopilotExpressDefinitions } | Should -Throw '*unsupported actionName*'
        $script:StepManifest[0].Id | Should -Be 'old-step'
        $script:RuntimeConfig.sentinel | Should -Be 'old-runtime'
    }

    It 'rejects null entries and non-text blank or padded required fields' {
        $script:manifest.steps += , $null
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*JSON object*'
        $script:manifest.steps = @($script:manifest.steps | Where-Object { $null -ne $_ })
        foreach ($value in @(3, '', ' ', ' A ')) {
            $script:manifest.steps[0].id = $value
            { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*non-blank id*'
        }
    }

    It 'requires JSON Booleans rather than truthy strings' {
        $script:manifest.steps[0].enabled = 'false'
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*JSON Boolean*'
        $script:manifest.steps[0].enabled = $true
        $script:manifest.workflowPhases[0].isConditional = 1
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*JSON Boolean*'
    }

    It 'requires typed array metadata and non-blank text entries' {
        foreach ($field in @('prerequisiteStepIds', 'requiredPermissions', 'graphEndpoints')) {
            $candidate = ConvertTo-NormalisedValue -Value ($script:manifestJson | ConvertFrom-Json)
            $candidate.steps[0][$field] = 'scalar'
            { Assert-ManifestDefinition -Manifest $candidate } | Should -Throw '*JSON array*'
            $candidate.steps[0][$field] = @('')
            { Assert-ManifestDefinition -Manifest $candidate } | Should -Throw '*non-blank text*'
        }
    }

    It 'rejects unsupported and duplicate actions including on disabled steps' {
        $script:manifest.steps[0].enabled = $false
        $script:manifest.steps[0].actionName = 'UnknownAction'
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*unsupported actionName*'
        $script:manifest.steps[0].actionName = $script:manifest.steps[1].actionName
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*action*duplicated*'
    }

    It 'rejects duplicate step and phase IDs case-insensitively' {
        $script:manifest.steps[1].id = 'a'
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*step ID*duplicated*'
        $script:manifest.steps[1].id = 'B'
        $script:manifest.workflowPhases[1].id = $script:manifest.workflowPhases[0].id.ToLowerInvariant()
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*phase ID*duplicated*'
    }

    It 'rejects enabled dependencies on disabled prerequisites' {
        $script:manifest.steps[0].enabled = $false
        { Initialize-AutopilotExpressDefinitions } | Should -Throw '*depends on disabled prerequisite*'
    }

    It 'rejects a workflow with no enabled steps' {
        foreach ($step in $script:manifest.steps) { $step.enabled = $false }
        { Initialize-AutopilotExpressDefinitions } | Should -Throw '*at least one enabled*'
    }

    It 'keeps optional defaults when flags and descriptive fields are omitted' {
        $script:manifest.steps[0].Remove('enabled')
        $script:manifest.steps[0].Remove('executionType')
        $script:manifest.steps[0].Remove('notes')
        Initialize-AutopilotExpressDefinitions
        $script:StepManifest[0].Enabled | Should -BeTrue
        $script:StepManifest[0].ActivationRequirement | Should -Be 'None'
        $script:StepManifest[0].ExecutionType | Should -Be 'graph'
        $script:StepManifest[0].Notes | Should -Be ''
    }

    It 'rejects unsupported execution and activation metadata' {
        $script:manifest.steps[0].executionType = 'remote'
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*executionType*'
        $script:manifest.steps[0].executionType = 'graph'
        $script:manifest.steps[0].activationRequirement = 'AlwaysBypass'
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*activationRequirement*'
    }

    It 'rejects undefined repeated and empty phase action collections' {
        $script:manifest.workflowPhases[0].actionNames = @('UnknownAction')
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*undefined action*'
        $script:manifest.workflowPhases[0].actionNames = @('ResolveAutopilotDevice', 'ResolveAutopilotDevice')
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*repeats action*'
        $script:manifest.workflowPhases[0].actionNames = @()
        { Assert-ManifestDefinition -Manifest $script:manifest } | Should -Throw '*non-empty actionNames*'
    }

    It 'preserves all published definitions if dependency graph validation fails' {
        $script:manifest.steps[0].prerequisiteStepIds = @('B')
        { Initialize-AutopilotExpressDefinitions } | Should -Throw '*cycle*'
        $script:StepManifest[0].Id | Should -Be 'old-step'
        $script:WorkflowPhases[0].Id | Should -Be 'old-phase'
        $script:RuntimeConfig.sentinel | Should -Be 'old-runtime'
        $script:Config.OrganisationName | Should -Be 'old-organisation'
    }

    It 'continues to reject undefined self and duplicate prerequisites' {
        foreach ($prerequisites in @(@('Undefined'), @('A'), @('B', 'B'))) {
            $script:manifest.steps[0].prerequisiteStepIds = $prerequisites
            { Initialize-AutopilotExpressDefinitions } | Should -Throw '*dependency graph is invalid*'
        }
    }

    It 'keeps the accepted action set identical to the actual dispatcher cases' {
        $dispatcher = $script:sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Invoke-AutopilotManifestStep' }, $true)
        $switchStatement = $dispatcher.Find({ param($node) $node -is [System.Management.Automation.Language.SwitchStatementAst] }, $true)
        $dispatcherActions = @($switchStatement.Clauses | ForEach-Object { $_.Item1.Value } | Sort-Object)
        $manifestActions = @($script:manifest.steps.actionName | Sort-Object)
        ($dispatcherActions -join ',') | Should -Be ($manifestActions -join ',')
        foreach ($actionName in $dispatcherActions) {
            $candidate = ConvertTo-NormalisedValue -Value ($script:manifestJson | ConvertFrom-Json)
            $candidate.steps = @(@{ id = 'Test'; displayName = 'Test'; actionName = $actionName; prerequisiteStepIds = @() })
            $candidate.workflowPhases = @(@{ id = 'Test'; displayName = 'Test'; actionNames = @($actionName) })
            { Assert-ManifestDefinition -Manifest $candidate } | Should -Not -Throw
        }
    }
}