<#
.SYNOPSIS
    Check deterministic installed SDK selection without installation or tenant calls.
.DESCRIPTION
    Extract production import functions and mock module discovery and imports.
    Requires Pester 5 and FullLanguage for source parsing.
#>
BeforeAll {
    $sourcePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'autopilot-express.ps1'
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [System.Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
    foreach ($functionName in @('Get-GraphModuleImportPlan', 'Import-RequiredGraphModules')) {
        $definition = $sourceAst.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $functionName }, $true)
        . ([scriptblock]::Create($definition.Extent.Text))
    }
    function Get-ConfiguredGraphModules { return @('Microsoft.Graph.DeviceManagement.Enrollment') }
    function Install-RequiredGraphModules { param($RequiredModules) return ($RequiredModules.Count -gt 0) }
    function Write-AutopilotExpressLog { param($Message, $Level) throw ('Unexpected log: {0}: {1}' -f $Level, $Message) }
}
Describe 'Installed Graph SDK selection' {
    BeforeEach {
        $script:available = @(
            @{ Name = 'Microsoft.Graph.Authentication'; Version = [version]'2.29.1'; Path = 'C:\SDK\Auth\2.29.1\Auth.psd1'; ModuleBase = 'C:\SDK\Auth\2.29.1' }
            @{ Name = 'Microsoft.Graph.Authentication'; Version = [version]'2.27.0'; Path = 'C:\SDK\Auth\2.27.0\Auth.psd1'; ModuleBase = 'C:\SDK\Auth\2.27.0' }
            @{ Name = 'Microsoft.Graph.DeviceManagement.Enrollment'; Version = [version]'2.27.0'; Path = 'C:\SDK\Enrollment\2.27.0\Enrollment.psd1'; ModuleBase = 'C:\SDK\Enrollment\2.27.0' }
        )
        $script:loaded = @()
        Mock Get-Module { if ($ListAvailable) { return $script:available } else { return $script:loaded } }
        Mock Import-Module {}
        Mock Write-AutopilotExpressLog {}
    }
    It 'chooses the newest common version with Authentication first' {
        $plan = Get-GraphModuleImportPlan -RequiredModules @('Microsoft.Graph.DeviceManagement.Enrollment')
        $plan.Count | Should -Be 2
        $plan[0].Name | Should -Be 'Microsoft.Graph.Authentication'
        $plan[0].Version | Should -Be ([version]'2.27.0')
    }
    It 'selects a newer complete set when installed' {
        $script:available += @{ Name = 'Microsoft.Graph.DeviceManagement.Enrollment'; Version = [version]'2.29.1'; Path = 'C:\SDK\Enrollment\2.29.1\Enrollment.psd1'; ModuleBase = 'C:\SDK\Enrollment\2.29.1' }
        (Get-GraphModuleImportPlan -RequiredModules @('Microsoft.Graph.DeviceManagement.Enrollment'))[0].Version | Should -Be ([version]'2.29.1')
    }
    It 'refuses missing common versions before importing' {
        $script:available = @($script:available | Where-Object { $_.Version -eq [version]'2.29.1' -or $_.Name -ne 'Microsoft.Graph.Authentication' })
        Import-RequiredGraphModules | Should -BeFalse
        Should -Invoke Import-Module -Times 0 -Exactly
    }
    It 'refuses a conflicting preloaded SDK version' {
        $script:loaded = @($script:available[0])
        Import-RequiredGraphModules | Should -BeFalse
        Should -Invoke Import-Module -Times 0 -Exactly
    }
    It 'refuses the same version from another installation' {
        $script:loaded = @(@{ Name = 'Microsoft.Graph.Authentication'; Version = [version]'2.27.0'; ModuleBase = 'C:\Other' })
        Import-RequiredGraphModules | Should -BeFalse
        Should -Invoke Import-Module -Times 0 -Exactly
    }
    It 'imports exact manifest paths rather than module names' {
        Import-RequiredGraphModules | Should -BeTrue
        Should -Invoke Import-Module -Times 1 -Exactly -ParameterFilter { $Name -eq 'C:\SDK\Auth\2.27.0\Auth.psd1' }
        Should -Invoke Import-Module -Times 1 -Exactly -ParameterFilter { $Name -eq 'C:\SDK\Enrollment\2.27.0\Enrollment.psd1' }
    }
    It 'returns failure when an import fails' {
        Mock Import-Module { throw 'Synthetic import failure' }
        Import-RequiredGraphModules | Should -BeFalse
    }
    It 'rejects dependency drift after imports' {
        Mock Import-Module { $script:loaded = @($script:available[0]) }
        Import-RequiredGraphModules | Should -BeFalse
    }
}