# <!-- omit from toc -->
# .SYNOPSIS
#    Technician CLI for Intune Autopilot device preparation and workflow tracking.
# .DESCRIPTION
#    This script provides an accessible, menu-driven UI for technicians performing Autopilot builds.
#    It captures device metadata, tracks progress across Autopilot steps, and implements selected live
#    Microsoft Graph / Intune / Entra ID actions while keeping tenant-specific or uncertain flows guided.
# .FILECREATED     2025-12-01
# .FILELASTUPDATED 2026-10-11
# .AUTHOR          Michael Harris (Developed collaboratively)
# .VERSION         0.1.0 (development; not production-approved)
# .LICENSE         Refer to root LICENSE (MIT)
# .DOCUMENTATION   README.md, .website/ (canonical)
# .ACCESSIBILITY   All prompts support screen readers (no colour-only cues)
# .NOTES
#    Root-resolution pattern, logging, validation, and menu structure follow project standards.
#    EN-AU spelling is used for documentation and comments.
#    Supports PowerShell 7 and Windows PowerShell 5.1, including supported pasted execution.
#    Live tenant and physical-device pilot approval is still required before rollout.
#
# ==============================================================================================
# Targeted ScriptAnalyzer suppressions for intentional interactive CLI and internal helper patterns.
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Autopilot Express is an interactive technician CLI and intentionally writes prompts and menu output directly to the host.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseBOMForUnicodeEncodedFile', '', Justification = 'This repository keeps PowerShell source in UTF-8 without BOM.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-UserDeviceRecords', Justification = 'Internal helper returns a collection by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Write-UserDeviceRecords', Justification = 'Internal helper persists a collection by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-UserStats', Justification = 'Interactive report helper intentionally summarises plural device stats.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Show-EnhancementsQuestions', Justification = 'Interactive helper intentionally presents multiple enhancement questions.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-ConfiguredTechnicianPrefixes', Justification = 'Internal helper returns the configured prefix collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-ConfiguredGraphScopes', Justification = 'Internal helper returns the configured Graph scope collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-ConfiguredGraphModules', Justification = 'Internal helper returns the configured module collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-ConfiguredScannerSerialRules', Justification = 'Internal helper returns the configured scanner serial-rule collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-UriQueryParameterValues', Justification = 'Internal helper returns all values for a repeated URI query parameter so ambiguity can be rejected.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-EnabledManifestSteps', Justification = 'Internal helper returns the enabled manifest-step collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-EligibleManifestSteps', Justification = 'Internal helper returns the eligible manifest-step collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-DispatchBlockingManifestSteps', Justification = 'Internal helper returns the incomplete steps that block build-bench dispatch.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-ManifestStepPrerequisiteIds', Justification = 'Internal helper returns the prerequisite step-ID collection.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Initialize-AutopilotExpressDefinitions', Justification = 'Initialisation intentionally loads multiple external definitions.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Install-RequiredGraphModules', Justification = 'Internal helper installs the configured module collection after explicit technician consent.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Import-RequiredGraphModules', Justification = 'Internal helper imports multiple Graph modules by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Test-GraphCapabilities', Justification = 'Internal preflight validates multiple required Graph read capabilities.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Test-DirectoryUserMatchesConfiguredPrefixes', Justification = 'Internal validation intentionally checks multiple configured prefixes.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-EligibleDirectoryUsers', Justification = 'Internal helper returns a filtered user collection by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-RecentUsers', Justification = 'Internal helper returns the recent-user collection by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Save-RecentUsers', Justification = 'Internal helper persists a recent-user collection by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Search-DemoDirectoryUsers', Justification = 'Internal search helper returns multiple possible user matches by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Search-LiveDirectoryUsers', Justification = 'Internal search helper returns multiple possible user matches by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Select-UserFromResults', Justification = 'Interactive selection helper intentionally presents multiple user results.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Get-LiveManagedDevicePrimaryUsers', Justification = 'Internal helper returns multiple managed-device primary-user relationships when present.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Invoke-StepRetryFailedApps', Justification = 'Manifest step intentionally retries multiple failed applications.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Sync-BenchRecords', Justification = 'Internal helper synchronises multiple bench-backed records by design.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Scope = 'Function', Target = 'Select-DeviceFromRecords', Justification = 'Interactive selection helper intentionally presents multiple device records.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'New-DeviceRecordObject', Justification = 'Internal object factory only constructs in-memory state for this interactive script.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'New-EmptyDeviceRecord', Justification = 'Internal factory only constructs a ConstrainedLanguage-compatible in-memory record.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'New-ParentDirectory', Justification = 'Internal file helper is not exposed as a user-invoked cmdlet.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'Reset-CurrentSessionState', Justification = 'Internal session-reset helper is driven by explicit menu confirmation rather than -WhatIf semantics.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'Update-MasterAuditLedger', Justification = 'Internal ledger writer is called from controlled persistence paths only.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'Start-NewDeviceWorkflow', Justification = 'This interactive workflow is already confirmation-driven and not intended for cmdlet-style WhatIf support.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'Update-DeviceStatus', Justification = 'This interactive workflow is already confirmation-driven and not intended for cmdlet-style WhatIf support.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'New-OperationResult', Justification = 'Internal result factory only constructs in-memory objects.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'New-BuildBench', Justification = 'This internal workflow initialiser is menu-driven and not intended for cmdlet-style WhatIf support.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Scope = 'Function', Target = 'Remove-DeviceFromBenchPosition', Justification = 'This internal bench helper is menu-driven and not intended for cmdlet-style WhatIf support.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Scope = 'Function', Target = 'Invoke-StepValidateDeploymentProfile', Justification = 'Manifest step handlers share a standard signature even when a specific step does not currently need every argument.')]
[CmdletBinding()]
param(
    [string]$Mode
)

# ==============================================================================================
# MENU STRUCTURE (ASCII, Accessible)
# The manifest supplies workflow labels, prerequisites and enabled actions.
#
# Main Menu:
#   1. Build bench - manage active builds (Induct, move, advance, reload and dispatch devices)
#   2. Start work on a new device        (Capture metadata and validate local identifiers)
#   3. Work on a tracked device          (Remain on its workflow after each eligible action)
#   4. What's outstanding for a device   (Show outstanding steps and open the selected workflow)
#   5. Maintain my device list           (Repeat edits; completion requires workflow evidence)
#   6. My stats and progress             (Per-user totals and site/device-type breakdown)
#   7. Change current site               (Select a different site for subsequent work)
#   8. About this script                 (Editable information; 0 returns immediately)
#   9. Enhancements & questions          (Show development status and open design questions)
#   0. Exit                              (Close Graph and release the local session reservation)
#
# Tracked Device Workflow (Option 3):
#   Manifest steps                       (Graph actions or guided physical confirmation)
#     Preparation                        (Identity, managed-device cleanup, Group Tag and membership)
#     Physical build                     (Imaging/OOBE, profile confirmation, reseal and boot)
#     Post-provisioning                  (Technician assignment, membership removal and sign-in)
#     Device completion                  (Applications, sync, approved updates and shutdown)
#     Final ownership                    (Explicit eligible C/E selection and assignment evidence)
#     Conditional recovery               (Unblock submission and guided recovery close-out)
#   X. Record Autopilot failure           (Default N; archive evidence and enter recovery)
#   8. Run next eligible step             (Alternative command if a manifest ID conflicts)
#   9. Select another device              (Alternative command if a manifest ID conflicts)
#   0. Return                            (Immediate return; R is a safe legacy alias)
#
# ==============================================================================================
# GRAPH / INTUNE / ENTRA REQUIREMENTS
# Delegated browser authentication uses the runtime JSON module and scope lists.
# Default scopes (tenant consent and operator permissions still require approval):
#   DeviceManagementServiceConfig.ReadWrite.All, DeviceManagementManagedDevices.ReadWrite.All,
#   Group.ReadWrite.All, GroupMember.ReadWrite.All, User.Read.All, Directory.Read.All.
# Active operations:
#   Resolve serial:           GET Autopilot and managed-device serial collections
#   Resolve Entra object:     GET /v1.0/devices filtered by registration deviceId
#   Remove managed device:    DELETE /v1.0/deviceManagement/managedDevices/{id}
#   Update Group Tag:         POST v1.0 Autopilot updateDeviceProperties (guarded REST)
#   Group membership:         POST members/$ref or DELETE members/{id}/$ref
#   Assign Autopilot user:    POST assignUserToDevice (SDK or raw fallback)
#   Assign managed user:      POST managedDevices('{id}')/users/$ref (raw Graph)
#   Request managed sync:     POST managedDevices/{id}/syncDevice
#   Recovery unblock:         POST Autopilot allowNextEnrollment
# No Autopilot-record deletion, manager inference or remote vendor command is performed.
# Application baseline and manufacturer procedures are guided physical observations.
#
# SECURITY & AUDIT CONSIDERATIONS:
#   - Graph wrapper bounds transient GET retries and SDK timeouts; writes are never replayed.
#   - Structured 429/503/504 failures honour bounded Retry-After; unknown outcomes fail closed.
#   - Local state contains no tokens or passwords. Console logs are not a durable transcript.
#   - Local reservation and recoverable saves are implemented; Shared mode remains disabled.
#
# ==============================================================================================
# ROOT RESOLUTION (Robust) & ENV VAR SETUP
function Show-ScriptScreen {
    <#
    .SYNOPSIS
        Clear the terminal and draw the shared blue header, including before mode selection.
    .PARAMETER ModeLabel
        Optional bootstrap label; later screens use the selected runtime mode.
    .OUTPUTS
        Accessible host text only, with one blank row below the title.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Title, [string]$ModeLabel)
    try { Clear-Host } catch { Write-Host '' }
    $width = 120
    try { if ($Host.UI.RawUI.WindowSize.Width -gt 1) { $width = $Host.UI.RawUI.WindowSize.Width - 1 } }
    catch { $width = 120 }
    $mode = if ($ModeLabel) { $ModeLabel } elseif ($Script:Runtime -and $Script:Runtime.IsDemoMode) { 'Demo' } else { 'Live' }
    $text = 'Autopilot Express - {0} | {1}' -f $Title, $mode
    while ($text.Length -gt 0) {
        $length = if ($text.Length -gt $width) { $width } else { $text.Length }
        $line = $text.Substring(0, $length)
        $padding = $width - $line.Length
        $left = [int](($padding - ($padding % 2)) / 2)
        Write-Host ($line.PadLeft($line.Length + $left).PadRight($width)) -BackgroundColor DarkBlue -ForegroundColor White
        $text = $text.Substring($length)
    }
    Write-Host ''
}
Show-ScriptScreen -Title 'Initial setup and testing' -ModeLabel 'Choose mode'
try {
    $runtimeConfigFileName = 'autopilot-express.runtime.json'
    $manifestFileName = 'autopilot-express.manifest.json'
    $definitionDirectoryCandidates = @()

    foreach ($sourcePath in @($PSScriptRoot, $env:AutopilotExpressDefinitionDirectory)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$sourcePath)) { $definitionDirectoryCandidates += [string]$sourcePath }
    }
    if (-not [string]::IsNullOrWhiteSpace($PSCommandPath)) {
        $definitionDirectoryCandidates += Split-Path -Parent $PSCommandPath
    }
    if (-not [string]::IsNullOrWhiteSpace($MyInvocation.MyCommand.Path)) {
        $definitionDirectoryCandidates += Split-Path -Parent $MyInvocation.MyCommand.Path
    }

    $currentDirectory = (Get-Location).Path
    $searchDirectory = $currentDirectory
    for ($searchDepth = 0; $searchDepth -lt 10; $searchDepth++) {
        $definitionDirectoryCandidates += $searchDirectory
        $definitionDirectoryCandidates += Join-Path $searchDirectory 'intune\devices\autopilot-express'
        $parentDirectory = Split-Path -Parent $searchDirectory
        if ([string]::IsNullOrWhiteSpace($parentDirectory) -or $parentDirectory -eq $searchDirectory) { break }
        $searchDirectory = $parentDirectory
    }

    $definitionDirectory = $null
    foreach ($candidateDirectory in @($definitionDirectoryCandidates | Select-Object -Unique)) {
        if ((Test-Path (Join-Path $candidateDirectory $runtimeConfigFileName)) -and (Test-Path (Join-Path $candidateDirectory $manifestFileName))) {
            $definitionDirectory = (Resolve-Path $candidateDirectory).Path
            break
        }
    }

    while ([string]::IsNullOrWhiteSpace($definitionDirectory)) {
        $definitionDirectoryInput = Read-Host ('Enter the folder containing {0} and {1} (default: {2})' -f $runtimeConfigFileName, $manifestFileName, $currentDirectory)
        $candidateDirectory = if ([string]::IsNullOrWhiteSpace($definitionDirectoryInput)) { $currentDirectory } else { $definitionDirectoryInput.Trim() }
        if ((Test-Path (Join-Path $candidateDirectory $runtimeConfigFileName)) -and (Test-Path (Join-Path $candidateDirectory $manifestFileName))) {
            $definitionDirectory = (Resolve-Path $candidateDirectory).Path
            break
        }
        Write-Information -MessageData ('The selected folder does not contain both {0} and {1}.' -f $runtimeConfigFileName, $manifestFileName) -InformationAction Continue
    }

    $Script:AutopilotExpressScriptDirectory = $definitionDirectory

    # The resolved definition folder is authoritative for this run, even when an IDE inherited a stale project-root value.
    $projectRoot = $definitionDirectory
    $current = $definitionDirectory
    $maxDepth = 10
    for ($i = 0; $i -lt $maxDepth; $i++) {
        $anchorReadme = Test-Path (Join-Path $current 'README.md')
        $anchorLicense = Test-Path (Join-Path $current 'LICENSE')
        $anchorGit = Test-Path (Join-Path $current '.git')
        if ($anchorReadme -or $anchorLicense -or $anchorGit) {
            $projectRoot = $current
            break
        }
        $parent = Split-Path -Parent $current
        if ([string]::IsNullOrWhiteSpace($parent) -or $parent -eq $current) { break }
        $current = $parent
    }
    $Script:AutopilotExpressProjectRoot = $projectRoot
    $env:PowerShellScriptingNewRoot = $projectRoot

    while ($true) {
        $modeInput = if ([string]::IsNullOrWhiteSpace($Mode)) { Read-Host 'Select mode: Live or Demo (default: Demo)' } else { $Mode }
        if ([string]::IsNullOrWhiteSpace($modeInput)) {
            $Mode = 'Demo'
            break
        }
        elseif ($modeInput.Trim().ToUpperInvariant() -eq 'LIVE') {
            $Mode = 'Live'
            break
        }
        elseif ($modeInput.Trim().ToUpperInvariant() -eq 'DEMO') {
            $Mode = 'Demo'
            break
        }
        else {
            Write-Information -MessageData 'Enter Live or Demo.' -InformationAction Continue
            $Mode = $null
        }
    }
}
catch {
    Write-Information -MessageData ('Autopilot Express bootstrap failed; startup stopped: {0}' -f $_.Exception.Message) -InformationAction Continue
    throw
}

# LOGGING (timestamped information-stream output; no durable transcript is created)
function Write-AutopilotExpressLog {
    <#
		.SYNOPSIS
            Writes a timestamped message to the information stream and console.
		.PARAMETER Message
			The message text.
		.PARAMETER Level
			Log level (INFO, WARN, ERROR, DEBUG)
	#>
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')][string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Information -MessageData ('[{0}] [{1}] {2}' -f $ts, $Level, $Message) -InformationAction Continue
}

# INTERNAL DEFAULTS & NOMENCLATURE (workflow availability comes from the manifest)
$Script:Config = [ordered]@{
    OrganisationName          = 'Example Health Network'
    Nomenclature              = [ordered]@{ Serial = 'Serial'; ConfigItem = 'Configuration Item'; Site = 'Site'; DeviceType = 'Device Type'; GroupTag = 'Group Tag' }
    DataFolderRelative        = 'data'
    UserDataFilePrefix        = 'autopilot-devices'
    DemoUserDataFilePrefix    = 'autopilot-devices-demo'
    RecentUsersFilePrefix     = 'autopilot-recent-users'
    DemoRecentUsersFilePrefix = 'autopilot-recent-users-demo'
    BuildBenchFilePrefix      = 'build-bench'
    DemoBuildBenchFilePrefix  = 'build-bench-demo'
    ArchiveFolderRelative     = 'archive/autopilot-express'
    MasterAuditFileName       = 'autopilot-master-audit.json'
    RuntimeConfigFileName     = 'autopilot-express.runtime.json'
    ManifestFileName          = 'autopilot-express.manifest.json'
    MaxRetryAttempts          = 5
    RetryBackoffSeconds       = 3
    TransportMaxAttempts      = 3
    TransportBackoffSeconds   = 3
    TransportMaxDelaySeconds  = 60
    TransportTimeoutSeconds   = 60
}

$Script:Runtime = [ordered]@{
    Mode            = $Mode
    IsDemoMode      = $Mode -eq 'Demo'
    ModeDisplayName = if ($Mode -eq 'Demo') { 'demo' } else { 'normal' }
}

$Script:RuntimeConfig = @{}
$Script:GraphSession = [ordered]@{
    Connected   = $false
    IsSimulated = $Script:Runtime.IsDemoMode
    Account     = ''
    DisplayName = ''
    UserId      = ''
    TenantId    = ''
    Scopes      = @()
}

$Script:Storage = [ordered]@{
    BasePath      = ''
    DataPath      = ''
    UsingFallback = $false
    Initialised   = $false
}

# HARD-CODED SITE LIST (Extendable)
$Script:Sites = @(
    [ordered]@{ Code = 'MI'; Name = 'Midland' }
    [ordered]@{ Code = 'MU'; Name = 'Murdoch' }
    [ordered]@{ Code = 'SU'; Name = 'Subiaco' }
    [ordered]@{ Code = 'GE'; Name = 'Geraldton' }
    [ordered]@{ Code = 'AL'; Name = 'Albany' }
)

# HARD-CODED DEVICE TYPES (Extendable)
$Script:DeviceTypes = @('Desktop', 'Laptop', 'WOW', 'NUC')

# STEP MANIFEST (loaded from JSON definition file)
$Script:StepManifest = @()
$Script:WorkflowPhases = @()

# ENHANCEMENT MANIFEST (drives dynamic enhancements list)
$Script:EnhancementManifest = @(
    [ordered]@{ Id = 1; Title = 'Concurrent device locking'; Description = 'Local session reservation is implemented; shared cross-technician transactions remain disabled.'; Status = 'Local only' }
    [ordered]@{ Id = 2; Title = 'Service Management integration'; Description = 'Update ITIL CMDB with device build events.'; Status = 'Planned' }
    [ordered]@{ Id = 3; Title = 'Technician-directed name suggestions'; Description = 'Bounded one-edit suggestions after no literal matches; explicit active C/E selection and revalidation.'; Status = 'Implemented; Live pilot pending' }
    [ordered]@{ Id = 4; Title = 'Baseline policy compliance scan'; Description = 'Check devices for required policies before reseal.'; Status = 'Planned' }
    [ordered]@{ Id = 5; Title = 'Offline caching for field techs'; Description = 'Queue updates when offline, sync later.'; Status = 'Planned' }
    [ordered]@{ Id = 6; Title = 'Export CSV & HTML reports'; Description = 'One-click exports for management reporting.'; Status = 'Planned' }
    [ordered]@{ Id = 7; Title = 'Pester tests'; Description = 'Offline unit and actual Demo CLI regressions are implemented; tenant and physical validation remain pending.'; Status = 'Implemented offline' }
    [ordered]@{ Id = 8; Title = 'Localisation'; Description = 'Multi-language prompts and messages.'; Status = 'Planned' }
    [ordered]@{ Id = 9; Title = 'Telemetry dashboard'; Description = 'Optional Power BI ingestion for trend analysis.'; Status = 'Planned' }
    [ordered]@{ Id = 10; Title = 'Secure token cache & refresh'; Description = 'Hardened auth flow for Graph integration.'; Status = 'Planned' }
)

# DATA SCHEMA (ConstrainedLanguage-compatible device record factory)
function New-EmptyDeviceRecord {
    return [ordered]@{
        RecordId                      = ''
        TenantId                      = ''
        AutopilotDeviceId             = ''
        ManagedDeviceId               = ''
        AzureAdDeviceId               = ''
        IntuneDeviceName              = ''
        Serial                        = ''
        EntraDeviceId                 = ''
        ConfigItem                    = ''
        SiteCode                      = ''
        DeviceType                    = ''
        GroupTag                      = ''
        Status                        = 'new'
        Steps                         = @{}
        AttemptHistory                = @()
        StartedAt                     = [DateTime]::MinValue
        StartedBy                     = ''
        LastUpdatedAt                 = [DateTime]::MinValue
        LastUpdatedBy                 = ''
        CompletedAt                   = [DateTime]::MinValue
        CompletedBy                   = ''
        IsCompletionVerified          = $false
        TechnicianUserPrincipalName   = ''
        FinalPrimaryUserId            = ''
        FinalPrimaryUserPrincipalName = ''
        FinalPrimaryUserDisplayName   = ''
        RecoveryActive                = $false
        RecoveryStartedAt             = [DateTime]::MinValue
        RecoveryReason                = ''
        RecoveryHistory               = @()
    }
}

function Get-DefaultBuildBenchState {
    return [ordered]@{ Positions = @(); Active = $false; SiteCode = $null; DeviceType = $null; Faults = @() }
}

function ConvertTo-NormalisedValue {
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [DateTime]) { return Get-Date -Date $Value -Format o }
    if ($Value -is [string] -or $Value -is [ValueType]) { return $Value }
    if ($Value -is [hashtable]) {
        $normalisedMap = @{}
        foreach ($key in $Value.Keys) {
            $normalisedMap[$key] = ConvertTo-NormalisedValue -Value $Value[$key]
        }
        return $normalisedMap
    }
    if ($Value -is [System.Collections.IDictionary]) {
        $normalisedMap = @{}
        foreach ($key in $Value.Keys) {
            $normalisedMap[$key] = ConvertTo-NormalisedValue -Value $Value[$key]
        }
        return $normalisedMap
    }
    if ($Value -is [pscustomobject]) {
        $normalisedMap = @{}
        foreach ($property in $Value.PSObject.Properties) {
            $normalisedMap[$property.Name] = ConvertTo-NormalisedValue -Value $property.Value
        }
        return $normalisedMap
    }
    if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) {
        $items = @()
        foreach ($item in $Value) {
            $items += , (ConvertTo-NormalisedValue -Value $item)
        }
        return , $items
    }
    return $Value
}

function ConvertTo-StepHashtable {
    <#
    .SYNOPSIS
        Validate persisted step evidence and migrate typed legacy Boolean flags.
    .PARAMETER Value
        Step dictionary, or null when a legacy record has no step evidence.
    .OUTPUTS
        Normalised validated dictionary; damaged evidence raises an error.
    #>
    param($Value)
    if ($null -eq $Value) { return @{} }
    $convertedValue = ConvertTo-NormalisedValue -Value $Value
    if ($convertedValue -is [System.Collections.IDictionary]) {
        foreach ($stepId in @($convertedValue.Keys)) {
            if ($stepId -isnot [string] -or [string]::IsNullOrWhiteSpace($stepId)) { throw 'Saved step IDs must be non-empty strings.' }
            $stepRecord = $convertedValue[$stepId]
            if ($stepRecord -isnot [System.Collections.IDictionary]) { throw ('Saved step {0} must be a dictionary.' -f $stepId) }
            foreach ($flag in @('Completed', 'Success', 'IsSimulated')) {
                if ($stepRecord.Contains($flag) -and $stepRecord[$flag] -isnot [bool]) { throw ('Saved step {0} flag {1} must be a Boolean.' -f $stepId, $flag) }
            }
            if ($stepRecord.Contains('Data') -and $stepRecord.Data -isnot [System.Collections.IDictionary]) { throw ('Saved step {0} data must be a dictionary.' -f $stepId) }
            foreach ($dateField in @('Timestamp', 'InvalidatedAt')) {
                if ($null -ne $stepRecord[$dateField]) {
                    $dateInput = $stepRecord[$dateField]
                    if ($dateInput -is [System.Collections.IDictionary] -and $dateInput.Contains('value')) { $dateInput = $dateInput.value }
                    if ($dateInput -isnot [string] -and $dateInput -isnot [DateTime]) { throw ('Saved step {0} date {1} has an invalid type.' -f $stepId, $dateField) }
                    $null = Get-Date -Date $dateInput -ErrorAction Stop
                }
            }
            if ($stepRecord.Contains('CompletionState')) {
                if ($stepRecord.CompletionState -isnot [string] -or $stepRecord.CompletionState -notin @('Verified', 'TechnicianConfirmed', 'Submitted', 'Blocked', 'Failed', 'AuditedException', 'Simulated', 'LegacyCompleted')) {
                    throw ('Saved step {0} has an unsupported completion state.' -f $stepId)
                }
                continue
            }
            $legacyCompleted = if ($stepRecord.Contains('Completed')) { $stepRecord.Completed } elseif ($stepRecord.Contains('Success')) { $stepRecord.Success } else { $false }
            $stepRecord['CompletionState'] = if ($legacyCompleted) { 'LegacyCompleted' } else { 'Failed' }
        }
        return $convertedValue
    }
    throw 'Saved Steps must be a dictionary; damaged evidence cannot be replaced with empty state.'
}

function New-DeviceRecordObject {
    param(
        [Parameter(Mandatory)][string]$Serial,
        [Parameter(Mandatory)][string]$ConfigItem,
        [string]$SiteCode,
        [string]$DeviceType,
        [string]$EntraDeviceId,
        [string]$GroupTag
    )
    $serialResult = ConvertTo-NormalisedSerialInput -InputValue $Serial
    if (-not $serialResult.Success) { throw ('Invalid serial input: {0}' -f $serialResult.Message) }

    $record = New-EmptyDeviceRecord
    $record.RecordId = [guid]::NewGuid().Guid
    $record.AutopilotDeviceId = ''
    $record.ManagedDeviceId = ''
    $record.AzureAdDeviceId = ''
    $record.IntuneDeviceName = ''
    $record.Serial = $serialResult.Serial
    $record.EntraDeviceId = if ($EntraDeviceId) { $EntraDeviceId } else { '' }
    $record.ConfigItem = $ConfigItem
    $record.SiteCode = $SiteCode
    $record.DeviceType = $DeviceType
    $record.GroupTag = $GroupTag
    $record.Status = 'new'
    $record.Steps = @{}
    $record.StartedAt = Get-Date
    $record.StartedBy = $env:USERNAME
    $record.LastUpdatedAt = $record.StartedAt
    $record.LastUpdatedBy = $record.StartedBy
    $record.CompletedAt = [DateTime]::MinValue
    $record.CompletedBy = ''
    $record.IsCompletionVerified = $false
    $record.TechnicianUserPrincipalName = ''
    $record.FinalPrimaryUserId = ''
    $record.FinalPrimaryUserPrincipalName = ''
    $record.FinalPrimaryUserDisplayName = ''
    $record.RecoveryActive = $false
    $record.RecoveryStartedAt = [DateTime]::MinValue
    $record.RecoveryReason = ''
    return $record
}

# Safely append a device record to the records collection
function Assert-DeviceRecordIdentity {
    <#
    .SYNOPSIS
        Reject ambiguous local workflow identities without changing existing history.
    .DESCRIPTION
        Validates a collection before insertion or session reuse. Serial and record
        identifiers must be unique, including removed records. Configuration Items
        must be unique among non-removed records. Comparisons are case-insensitive.
    .PARAMETER Records
        Workflow records to validate; an empty collection is valid.
    #>
    param([AllowEmptyCollection()][System.Collections.IEnumerable]$Records = @())
    $serials = @{}
    $recordIds = @{}
    $configItems = @{}
    $selectionTokens = @{}
    foreach ($record in $Records) {
        $serial = ([string]$record.Serial).Trim()
        if ([string]::IsNullOrWhiteSpace($serial)) { throw 'A workflow record has no serial. Correct the saved record before continuing.' }
        if ($serials.ContainsKey($serial)) { throw ('Duplicate serial {0}. Resume its existing workflow instead of creating another record.' -f $serial) }
        $serials[$serial] = $true
        $recordId = ([string]$record.RecordId).Trim()
        if ($recordId) {
            if ($recordIds.ContainsKey($recordId)) { throw 'Duplicate workflow record ID. Correct the saved records before continuing.' }
            $recordIds[$recordId] = $true
        }
        $configItem = ([string]$record.ConfigItem).Trim()
        if ($record.Status -ne 'removed' -and $configItem) {
            if ($configItems.ContainsKey($configItem)) { throw ('Configuration Item {0} belongs to more than one active workflow. Resolve the conflict before continuing.' -f $configItem) }
            $configItems[$configItem] = $true
        }
        $recordTokens = @($serial)
        if ($record.Status -ne 'removed' -and $configItem) { $recordTokens += $configItem }
        foreach ($selectionToken in $recordTokens) {
            if (-not $selectionToken) { continue }
            if ($selectionTokens.ContainsKey($selectionToken) -and $selectionTokens[$selectionToken] -ne $serial) {
                throw 'A serial matches another workflow Configuration Item. Resolve the ambiguous scan identifier before continuing.'
            }
            $selectionTokens[$selectionToken] = $serial
        }
    }
}

function Add-DeviceRecord {
    param(
        [Parameter(Mandatory)][hashtable]$Records,
        [Parameter(Mandatory)]$Record
    )
    $existingRecords = if ($null -eq $Records.Value) { @() } else { @($Records.Value) }
    $updatedRecords = @($existingRecords) + , $Record
    Assert-DeviceRecordIdentity -Records $updatedRecords
    $Records.Value = $updatedRecords
}

function Get-RepoStorageBasePath {
    if (-not [string]::IsNullOrWhiteSpace($Script:AutopilotExpressProjectRoot)) {
        return $Script:AutopilotExpressProjectRoot
    }
    return $env:PowerShellScriptingNewRoot
}

function Get-FallbackStorageBasePath {
    return Join-Path $env:LOCALAPPDATA 'PowerShellScriptingNew\AutopilotExpress'
}

function Test-DirectoryWritable {
    param([Parameter(Mandatory)][string]$Path)

    try {
        if (-not (Test-Path $Path)) {
            New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop | Out-Null
        }

        $probePath = Join-Path $Path ('.write-probe-{0}.tmp' -f [guid]::NewGuid().Guid)
        Set-Content -Path $probePath -Value 'probe' -Encoding (Get-StorageFileEncoding) -NoNewline -Force -ErrorAction SilentlyContinue
        if (-not (Test-Path $probePath)) { return $false }
        Remove-Item -Path $probePath -Force -ErrorAction Stop
        return $true
    }
    catch {
        return $false
    }
}

function Assert-StorageModeSupported {
    <#
    .SYNOPSIS
        Reject unsupported storage modes before any operational store access.
    .DESCRIPTION
        Missing storage settings retain legacy Local behaviour. An explicit mode
        must be Local. Shared transactions remain offline development work; a
        configured shared root must never silently fall back to local records.
    #>
    param()
    $storageSettings = $Script:RuntimeConfig.storage
    if ($null -eq $storageSettings) { return }
    if ($storageSettings -isnot [System.Collections.IDictionary]) {
        throw 'Storage settings must be a dictionary with mode Local. No storage was opened.'
    }
    if (-not $storageSettings.Contains('mode')) { return }
    if ($storageSettings.mode -isnot [string] -or [string]::IsNullOrWhiteSpace($storageSettings.mode)) {
        throw 'Storage mode must be Local. Empty or non-text modes are not supported. No storage was opened.'
    }
    if ($storageSettings.mode -ne 'Local') {
        throw 'Only Local storage is supported by this entry point. Shared storage is disabled until transaction and concurrent-writer validation is complete. No local fallback or shared access was attempted.'
    }
}

function Get-OperationalStoragePath {
    <#
    .SYNOPSIS
        Resolve current-mode state paths without creating or selecting a root.
    .PARAMETER BasePath
        Repository or fallback base directory to inspect.
    .OUTPUTS
        Device, bench and recent-user paths, plus common Live audit and receipt
        paths. Receipt recovery artefacts resolve to their canonical target paths.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BasePath)
    $dataPath = Join-Path $BasePath $Script:Config.DataFolderRelative
    foreach ($prefix in @((Get-ModeUserDataFilePrefix), (Get-ModeBuildBenchFilePrefix), (Get-ModeRecentUsersFilePrefix))) {
        Join-Path $dataPath ('{0}-{1}.json' -f $prefix, $env:USERNAME)
    }
    if (-not $Script:Runtime.IsDemoMode) {
        Join-Path $dataPath $Script:Config.MasterAuditFileName
        if (Test-Path -LiteralPath $dataPath) {
            Get-ChildItem -LiteralPath $dataPath -Filter 'sync-submission-*.json*' -File -Force -ErrorAction Stop |
            ForEach-Object {
                if ($_.Name -cmatch '^(sync-submission-[A-Za-z0-9-]+\.json)(?:\.(?:pending|previous|write-in-progress))?$') {
                    Join-Path $dataPath $Matches[1]
                }
            } | Sort-Object -Unique
        }
    }
}

function Get-FallbackStorageAuthorityPath {
    <#
    .SYNOPSIS
        Locate durable fallback authority for this user and operational mode.
    .PARAMETER BasePath
        Fallback base directory; this helper never creates it.
    .OUTPUTS
        Marker path, separate from operational user files and session locks.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BasePath)
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    Join-Path (Join-Path $BasePath $Script:Config.DataFolderRelative) ('autopilot-express-{0}-{1}.storage-authority' -f $modeName, $env:USERNAME)
}

function Test-FallbackStorageAuthority {
    <#
    .SYNOPSIS
        Validate completed migration authority without using file timestamps.
    .DESCRIPTION
        The versioned marker must exactly identify this mode, user and data root.
        Missing markers return false; malformed or interrupted markers fail closed.
    .PARAMETER BasePath
        Fallback base directory whose marker is being checked.
    .OUTPUTS
        True only for the exact completed-migration marker.
    #>
    [OutputType([bool])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$BasePath)
    $path = Get-FallbackStorageAuthorityPath -BasePath $BasePath
    Assert-FileWriteRecoveryState -Path $path
    if (-not (Test-Path -LiteralPath $path)) { return $false }
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    $dataPath = Join-Path $BasePath $Script:Config.DataFolderRelative
    $expected = 'AutopilotExpressFallbackAuthority/1|{0}|{1}|{2}' -f $modeName, $env:USERNAME, $dataPath
    $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
    if ($content -cne $expected) {
        throw ('Invalid fallback storage authority at {0}. Preserve the marker and both roots for operator review; no migration was attempted.' -f $path)
    }
    return $true
}

function Assert-ActiveStorageReservation {
    <#
    .SYNOPSIS
        Require the current invocation's current-root lock before migration writes.
    .DESCRIPTION
        Validates the startup lock path, token and process against the selected
        root. Missing or changed ownership never authorises a copy or marker save.
    #>
    $lockVariable = Get-Variable -Name localSessionLock -Scope Script -ErrorAction SilentlyContinue
    $lock = if ($null -ne $lockVariable) { $lockVariable.Value } else { $null }
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    $expectedPath = Join-Path $Script:Storage.DataPath ('autopilot-express-{0}.session.lock' -f $modeName)
    if (-not $Script:Storage.Initialised -or $lock -isnot [System.Collections.IDictionary] -or
        $lock.Path -ne $expectedPath -or [string]::IsNullOrWhiteSpace([string]$lock.Token)) {
        throw 'Storage migration requires the current-root session reservation. Nothing was written.'
    }
    $owner = Get-Content -LiteralPath $expectedPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($owner.Token -cne $lock.Token -or $owner.ProcessId -ne $PID) {
        throw 'Storage migration reservation ownership changed. Nothing further was written.'
    }
}

function Initialize-StorageLocation {
    <#
    .SYNOPSIS
        Select one stable authoritative local root before reserving the session.
    .DESCRIPTION
        Existing fallback state or completed migration authority takes precedence
        over repository writability. An unavailable authoritative fallback is an
        error, never permission to resume an older repository copy. Both roots'
        current-mode checkpoint proposals must be absent before probing either
        root; migration authority cannot hide unfinished source writes.
    #>
    Assert-StorageModeSupported
    if ($Script:Storage.Initialised) { return }

    $repoBasePath = Get-RepoStorageBasePath
    $repoDataPath = Join-Path $repoBasePath $Script:Config.DataFolderRelative
    $fallbackBasePath = Get-FallbackStorageBasePath
    $fallbackDataPath = Join-Path $fallbackBasePath $Script:Config.DataFolderRelative

    Assert-LocalCheckpointState -BasePath $repoBasePath
    Assert-LocalCheckpointState -BasePath $fallbackBasePath

    $preferFallback = $false
    if (Test-Path -LiteralPath $fallbackDataPath) {
        $preferFallback = Test-FallbackStorageAuthority -BasePath $fallbackBasePath
        foreach ($path in @(Get-OperationalStoragePath -BasePath $fallbackBasePath)) {
            Assert-FileWriteRecoveryState -Path $path
            if (Test-Path -LiteralPath $path) { $preferFallback = $true }
        }
    }

    if (-not $preferFallback -and (Test-DirectoryWritable -Path $repoDataPath)) {
        $Script:Storage.BasePath = $repoBasePath
        $Script:Storage.DataPath = $repoDataPath
        $Script:Storage.UsingFallback = $false
        $storageLevel = 'INFO'
        $storageMode = 'repository data'
    }
    elseif (Test-DirectoryWritable -Path $fallbackDataPath) {
        $Script:Storage.BasePath = $fallbackBasePath
        $Script:Storage.DataPath = $fallbackDataPath
        $Script:Storage.UsingFallback = $true
        $storageLevel = 'WARN'
        $storageMode = 'LocalAppData fallback'
    }
    else {
        throw ('Autopilot Express could not find a writable storage location. Checked {0} and {1}.' -f $repoDataPath, $fallbackDataPath)
    }

    $Script:Storage.Initialised = $true
    Write-AutopilotExpressLog -Message ('Autopilot Express storage root: {0} ({1})' -f $Script:Storage.DataPath, $storageMode) -Level $storageLevel
}

function Start-SharedStoreReservation {
    <#
    .SYNOPSIS
        Reserve an existing filesystem root for offline snapshot development.
    .DESCRIPTION
        Exclusive file creation has no timeout or automatic takeover. This helper
        is not wired into the CLI and does not certify network filesystem locking.
    .PARAMETER Root
        Existing isolated development directory; never created automatically.
    .OUTPUTS
        Reservation path and unique ownership token for snapshot helpers.
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Mandatory offline reservation uses exclusive creation; WhatIf cannot establish ownership and ShouldProcess is unavailable in ConstrainedLanguage.')]
    [CmdletBinding()]
    [OutputType([hashtable])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Root)
    $directory = Get-Item -LiteralPath $Root -ErrorAction Stop
    if ($directory.PSProvider.Name -ne 'FileSystem' -or -not $directory.PSIsContainer) { throw 'Snapshot root must be an existing filesystem directory.' }
    $path = Join-Path $directory.FullName 'autopilot-shared.snapshot.lock'
    $token = [guid]::NewGuid().Guid
    $owner = @{ Token = $token; User = $env:USERNAME; Computer = $env:COMPUTERNAME; ProcessId = $PID; StartedAt = (Get-Date -Format o) }
    New-Item -ItemType File -Path $path -Value ($owner | ConvertTo-Json -Compress) -ErrorAction Stop | Out-Null
    return @{ Path = $path; Token = $token }
}

function Assert-SharedStoreReservation {
    <#
    .SYNOPSIS
        Check that snapshot access owns this root's reservation.
    .PARAMETER Root
        Existing filesystem directory containing the snapshot and reservation.
    .PARAMETER Lock
        Ownership token and path returned by Start-SharedStoreReservation.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Root,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][hashtable]$Lock
    )
    $directory = Get-Item -LiteralPath $Root -ErrorAction Stop
    if ($directory.PSProvider.Name -ne 'FileSystem' -or -not $directory.PSIsContainer) { throw 'Snapshot root must be an existing filesystem directory.' }
    $expectedPath = Join-Path $directory.FullName 'autopilot-shared.snapshot.lock'
    if ($Lock.Path -ne $expectedPath -or [string]::IsNullOrWhiteSpace([string]$Lock.Token)) { throw 'Snapshot reservation does not belong to this root.' }
    $owner = Get-Content -LiteralPath $expectedPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($owner.Token -cne $Lock.Token) { throw 'Snapshot reservation ownership changed. No snapshot was accessed.' }
}

function Assert-SharedStoreSnapshot {
    <#
    .SYNOPSIS
        Validate the offline snapshot envelope and cross-record bench identities.
    .PARAMETER Snapshot
        Normalised dictionary containing schema, revision, devices, bench and audit.
    #>
    param([Parameter(Mandatory)][AllowEmptyCollection()][ValidateNotNull()][System.Collections.IDictionary]$Snapshot)
    if (($Snapshot.SchemaVersion -isnot [int] -and $Snapshot.SchemaVersion -isnot [long]) -or $Snapshot.SchemaVersion -ne 1 -or
        ($Snapshot.Revision -isnot [int] -and $Snapshot.Revision -isnot [long]) -or
        $Snapshot.Revision -lt 0 -or $Snapshot.Revision -ge [int]::MaxValue -or
        $Snapshot.Devices -isnot [array] -or $Snapshot.Audit -isnot [array] -or
        $Snapshot.Bench -isnot [System.Collections.IDictionary] -or $Snapshot.Bench.Positions -isnot [array]) {
        throw 'Invalid shared snapshot envelope. No empty-state substitution is permitted.'
    }
    foreach ($device in $Snapshot.Devices) {
        if ($device -isnot [System.Collections.IDictionary] -or
            $device.RecordId -isnot [string] -or [string]::IsNullOrWhiteSpace($device.RecordId) -or
            $device.Serial -isnot [string] -or [string]::IsNullOrWhiteSpace($device.Serial)) {
            throw 'Shared snapshot devices require dictionary records with textual record IDs and serials.'
        }
        if ($device.Contains('Status') -and ($device.Status -isnot [string] -or
                $device.Status -notin @('new', 'in-progress', 'completed', 'removed'))) {
            throw 'Shared snapshot device status must be new, in-progress, completed or removed.'
        }
    }
    Assert-DeviceRecordIdentity -Records $Snapshot.Devices
    Assert-AttemptHistoryPreserved -Records $Snapshot.Devices
    Assert-BenchPositionIdentity -Positions $Snapshot.Bench.Positions
    foreach ($device in $Snapshot.Devices) {
        if ([string]::IsNullOrWhiteSpace([string]$device.RecordId)) { throw 'Shared snapshot devices require stable record IDs.' }
    }
    foreach ($position in $Snapshot.Bench.Positions) {
        if (-not $position.Serial) { continue }
        $benchMatches = @($Snapshot.Devices | Where-Object { $_.Serial -eq $position.Serial -and $_.Status -notin @('removed', 'completed') })
        if ($benchMatches.Count -ne 1 -or $benchMatches[0].ConfigItem -ne $position.ConfigItem) {
            throw 'Shared snapshot bench identity does not match one active device record.'
        }
    }
    foreach ($entry in $Snapshot.Audit) {
        if ($entry -isnot [System.Collections.IDictionary]) { throw 'Shared snapshot audit entries must be dictionaries.' }
    }
}

function Get-SharedStoreSnapshot {
    <#
    .SYNOPSIS
        Read one complete offline snapshot under the caller's reservation.
    .DESCRIPTION
        Missing initial storage returns revision zero. Malformed or interrupted
        saves fail closed. No migration, repair or tenant action is attempted.
    .PARAMETER Root
        Isolated snapshot directory, not selected by runtime storage settings.
    .PARAMETER Lock
        Reservation owned by the caller.
    .OUTPUTS
        Normalised snapshot dictionary; arrays remain arrays on both hosts.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Root,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][hashtable]$Lock
    )
    Assert-SharedStoreReservation -Root $Root -Lock $Lock
    $path = Join-Path $Root 'autopilot-shared.snapshot.json'
    Assert-FileWriteRecoveryState -Path $path
    if (-not (Test-Path -LiteralPath $path)) {
        return @{ SchemaVersion = 1; Revision = 0; Devices = @(); Bench = @{ Positions = @() }; Audit = @() }
    }
    $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace([string]$content)) { throw 'Shared snapshot file is empty; no revision-zero substitution is permitted.' }
    $raw = $content | ConvertFrom-Json -ErrorAction Stop
    $snapshot = ConvertTo-NormalisedValue -Value $raw
    Assert-SharedStoreSnapshot -Snapshot $snapshot
    return $snapshot
}

function Get-SharedStoreRecoveryInspection {
    <#
    .SYNOPSIS
        Inspect retained snapshot copies without repairing or approving recovery.
    .DESCRIPTION
        Requires the caller's reservation before and after inspection. Each copy
        is validated independently; invalid content is reported, never substituted.
        No files are changed, and no candidate is selected for promotion.
    .PARAMETER Root
        Isolated development root containing the snapshot and recovery artefacts.
    .PARAMETER Lock
        Current reservation owned by the caller.
    .OUTPUTS
        Read-only evidence report with copy summaries and validated snapshots.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Root,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][hashtable]$Lock
    )
    Assert-SharedStoreReservation -Root $Root -Lock $Lock
    $path = Join-Path $Root 'autopilot-shared.snapshot.json'
    $copies = @()
    foreach ($suffix in @('', '.pending', '.previous')) {
        $copyPath = '{0}{1}' -f $path, $suffix
        $copy = @{ Path = $copyPath; Exists = $false; State = 'Missing'; Revision = $null; DeviceCount = $null; PositionCount = $null; AuditCount = $null; Snapshot = $null }
        if (Test-Path -LiteralPath $copyPath) {
            $copy.Exists = $true
            $copy.State = 'Invalid'
            try {
                $content = Get-Content -LiteralPath $copyPath -Raw -Encoding UTF8 -ErrorAction Stop
                if (-not [string]::IsNullOrWhiteSpace([string]$content)) {
                    $snapshot = ConvertTo-NormalisedValue -Value ($content | ConvertFrom-Json -ErrorAction Stop)
                    Assert-SharedStoreSnapshot -Snapshot $snapshot
                    $copy.State = 'Valid'
                    $copy.Revision = $snapshot.Revision
                    $copy.DeviceCount = $snapshot.Devices.Count
                    $copy.PositionCount = $snapshot.Bench.Positions.Count
                    $copy.AuditCount = $snapshot.Audit.Count
                    $copy.Snapshot = $snapshot
                }
            }
            catch { $copy.State = 'Invalid' }
        }
        $copies += $copy
    }
    $markerPresent = Test-Path -LiteralPath ('{0}.write-in-progress' -f $path)
    $reviewRequired = $markerPresent -or $copies[1].Exists -or
    (-not $copies[0].Exists -and $copies[2].Exists) -or
    @($copies | Where-Object { $_.State -eq 'Invalid' }).Count -gt 0
    Assert-SharedStoreReservation -Root $Root -Lock $Lock
    return @{ Root = $Root; MarkerPresent = $markerPresent; ReviewRequired = [bool]$reviewRequired; RecoveryApproved = $false; Copies = $copies }
}

function Get-SharedStoreMigrationPreview {
    <#
    .SYNOPSIS
        Preview an initial snapshot import without changing either store.
    .DESCRIPTION
        Offline development only. Validates captured source evidence and requires
        a pristine destination under the caller's reservation. Does not merge,
        approve migration, capture local files or certify source consistency.
    .PARAMETER Root
        Isolated development destination, not the configured runtime store.
    .PARAMETER Lock
        Destination reservation owned by the caller throughout the preview.
    .PARAMETER SourceSnapshot
        Captured, normalised snapshot envelope for operator review. All record,
        history, bench and audit evidence is copied without rewriting identities.
    .OUTPUTS
        Detached proposal and counts; MigrationApproved is always false.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Root,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][hashtable]$Lock,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][System.Collections.IDictionary]$SourceSnapshot
    )
    $current = Get-SharedStoreSnapshot -Root $Root -Lock $Lock
    $proposal = ConvertTo-NormalisedValue -Value $SourceSnapshot
    Assert-SharedStoreSnapshot -Snapshot $proposal
    if ($current.Revision -ne 0 -or $current.Devices.Count -ne 0 -or
        $current.Bench.Positions.Count -ne 0 -or $current.Audit.Count -ne 0) {
        throw 'Shared migration preview requires a pristine destination; existing state cannot be merged or replaced.'
    }
    $sourceRevision = $proposal.Revision
    $proposal.Revision = $current.Revision
    Assert-SharedStoreReservation -Root $Root -Lock $Lock
    return @{
        ExpectedRevision = $current.Revision; SourceRevision = $sourceRevision
        DeviceCount = $proposal.Devices.Count; PositionCount = $proposal.Bench.Positions.Count
        AuditCount = $proposal.Audit.Count; ReviewRequired = $true
        MigrationApproved = $false; Snapshot = $proposal
    }
}

function Write-SharedStoreSnapshot {
    <#
    .SYNOPSIS
        Save devices, bench and append-only audit together with a revision check.
    .DESCRIPTION
        Offline development only. Requires the original reservation and current
        revision; preserves the audit prefix and retained workflow IDs and serials. Uses the
        recoverable single-file writer, not a claim of atomic network replacement.
    .PARAMETER Root
        Isolated snapshot directory.
    .PARAMETER Lock
        Reservation owned by the caller.
    .PARAMETER ExpectedRevision
        Revision read before the edit; stale callers are rejected without writing.
    .PARAMETER Snapshot
        Complete proposed envelope; caller revision must equal ExpectedRevision.
    .OUTPUTS
        Committed revision, returned only after save verification succeeds.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Root,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][hashtable]$Lock,
        [Parameter(Mandatory)][ValidateRange(0, 2147483645)][int]$ExpectedRevision,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][System.Collections.IDictionary]$Snapshot
    )
    $current = Get-SharedStoreSnapshot -Root $Root -Lock $Lock
    $proposed = ConvertTo-NormalisedValue -Value $Snapshot
    Assert-SharedStoreSnapshot -Snapshot $proposed
    if ($current.Revision -ne $ExpectedRevision -or $proposed.Revision -ne $ExpectedRevision) { throw 'Shared snapshot revision conflict. Reload before editing; nothing was written.' }
    if ($proposed.Audit.Count -lt $current.Audit.Count) { throw 'Shared snapshot audit history cannot be truncated.' }
    for ($index = 0; $index -lt $current.Audit.Count; $index++) {
        if (-not (Test-AttemptEvidenceEqual -Left $current.Audit[$index] -Right $proposed.Audit[$index])) {
            throw 'Shared snapshot audit history cannot be rewritten or reordered.'
        }
    }
    foreach ($device in $current.Devices) {
        $retained = @($proposed.Devices | Where-Object { $_.RecordId -eq $device.RecordId })
        if ($retained.Count -ne 1) { throw 'Shared snapshot workflow records must be retained, including removed records.' }
        if (([string]$retained[0].Serial).Trim() -ine ([string]$device.Serial).Trim()) {
            throw 'Shared snapshot workflow serial identity cannot be reassigned to another device.'
        }
    }
    Assert-AttemptHistoryPreserved -Records $proposed.Devices -ExistingRecords $current.Devices
    $proposed.Revision = $ExpectedRevision + 1
    $proposed.LastWriter = @{ User = $env:USERNAME; Computer = $env:COMPUTERNAME; ProcessId = $PID; SavedAt = (Get-Date -Format o) }
    Assert-SharedStoreReservation -Root $Root -Lock $Lock
    Write-Utf8File -Path (Join-Path $Root 'autopilot-shared.snapshot.json') -Content ($proposed | ConvertTo-Json -Depth 100)
    return $proposed.Revision
}

function Get-StorageBasePath {
    Initialize-StorageLocation
    return $Script:Storage.BasePath
}

function Get-DataFolderPath {
    param([string]$BasePath)

    $resolvedBasePath = if ($BasePath) { $BasePath } else { Get-StorageBasePath }
    $dataFolder = Join-Path $resolvedBasePath $Script:Config.DataFolderRelative
    if (-not (Test-Path $dataFolder)) {
        New-Item -ItemType Directory -Path $dataFolder -Force -ErrorAction Stop | Out-Null
    }
    return $dataFolder
}

function Get-ArchiveFolderPath {
    param([string]$BasePath)

    $archiveFolder = Join-Path (Get-DataFolderPath -BasePath $BasePath) $Script:Config.ArchiveFolderRelative
    if (-not (Test-Path $archiveFolder)) {
        New-Item -ItemType Directory -Path $archiveFolder -Force -ErrorAction Stop | Out-Null
    }
    return $archiveFolder
}

function Start-LocalSessionLock {
    <#
    .SYNOPSIS
        Exclusively reserve the resolved local store before session access.
    .DESCRIPTION
        Creates a mode-specific file without Force. File creation fails when another
        session or an unrecovered crash owns the store. The lock covers all users in
        this storage root because Live audit writes share one ledger. No lock expires
        automatically; a crashed session requires an operator-reviewed recovery.
    .OUTPUTS
        Hashtable containing the lock path and unique ownership token.
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Mandatory internal reservation cannot support WhatIf; PSCmdlet.ShouldProcess is blocked in ConstrainedLanguage. Exclusive file creation is the safety gate.')]
    [CmdletBinding()]
    [OutputType([hashtable])]
    param()
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    $path = Join-Path (Get-DataFolderPath) ('autopilot-express-{0}.session.lock' -f $modeName)
    $token = [guid]::NewGuid().Guid
    $payload = @{ Token = $token; User = $env:USERNAME; Computer = $env:COMPUTERNAME; ProcessId = $PID; StartedAt = (Get-Date -Format o) }
    try {
        New-Item -ItemType File -Path $path -Value ($payload | ConvertTo-Json -Compress) -ErrorAction Stop | Out-Null
    }
    catch {
        throw ('Cannot reserve local {0} storage. Another session or an unrecovered lock may exist at {1}. Close the owning session; after a crash, confirm all sessions using this store have stopped before recovering the lock. No session data or tenant actions were started. Detail: {2}' -f $modeName, $path, $_.Exception.Message)
    }
    return @{ Path = $path; Token = $token }
}

function Stop-LocalSessionLock {
    <#
    .SYNOPSIS
        Release only the local lock acquired by this invocation.
    .PARAMETER Lock
        Path and ownership token returned by Start-LocalSessionLock.
    .DESCRIPTION
        Missing, unreadable or changed locks are not removed. Errors propagate so
        the operator can review the reserved store instead of assuming cleanup worked.
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Mandatory finally cleanup is ownership-checked and cannot support WhatIf; PSCmdlet.ShouldProcess is blocked in ConstrainedLanguage.')]
    [CmdletBinding()]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][hashtable]$Lock)
    $owner = Get-Content -LiteralPath $Lock.Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($owner.Token -ne $Lock.Token) { throw 'Local session lock ownership changed. The lock was not removed; review this storage root before restarting.' }
    Remove-Item -LiteralPath $Lock.Path -ErrorAction Stop
}

function New-ParentDirectory {
    param([Parameter(Mandatory)][string]$Path)
    $parentPath = Split-Path -Parent $Path
    if (-not [string]::IsNullOrWhiteSpace($parentPath) -and -not (Test-Path $parentPath)) {
        New-Item -ItemType Directory -Path $parentPath -Force -ErrorAction Stop | Out-Null
    }
}

function Get-StorageFileEncoding {
    if ($PSVersionTable.PSVersion.Major -ge 6) { return 'utf8NoBOM' }
    return 'UTF8'
}

function Write-Utf8File {
    <#
    .SYNOPSIS
        Save verified staged content with recoverable previous-file evidence.
    .DESCRIPTION
        A marker reserves the save before touching the target. Staged and previous
        content are read back before promotion; the marker remains on any failure.
        Cmdlet replacement is not guaranteed atomic. Recovery artefacts block another
        write until reviewed; no failed tenant action is automatically replayed.
    .PARAMETER Path
        Target file; recovery artefacts are stored beside it on the same volume.
    .PARAMETER Content
        Complete text to save with the host-appropriate UTF-8 encoding.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Path,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Content
    )
    New-ParentDirectory -Path $Path
    $pendingPath = '{0}.pending' -f $Path
    $previousPath = '{0}.previous' -f $Path
    $markerPath = '{0}.write-in-progress' -f $Path
    Assert-FileWriteRecoveryState -Path $Path
    $hadOriginal = Test-Path -LiteralPath $Path
    $marker = @{ Target = $Path; HadOriginal = $hadOriginal; User = $env:USERNAME; Computer = $env:COMPUTERNAME; StartedAt = (Get-Date -Format o) }
    New-Item -ItemType File -Path $markerPath -Value ($marker | ConvertTo-Json -Compress) -ErrorAction Stop | Out-Null
    Set-Content -LiteralPath $pendingPath -Value $Content -Encoding (Get-StorageFileEncoding) -NoNewline -ErrorAction Stop
    [string]$stagedContent = Get-Content -LiteralPath $pendingPath -Raw -ErrorAction Stop
    if ([string]::IsNullOrEmpty($stagedContent)) { $stagedContent = '' }
    if ($stagedContent -cne $Content) { throw ('Staged save verification failed for {0}. Recovery artefacts were retained.' -f $Path) }
    if ($hadOriginal) {
        [string]$originalContent = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
        if ([string]::IsNullOrEmpty($originalContent)) { $originalContent = '' }
        Copy-Item -LiteralPath $Path -Destination $previousPath -Force -ErrorAction Stop
        [string]$previousContent = Get-Content -LiteralPath $previousPath -Raw -ErrorAction Stop
        if ([string]::IsNullOrEmpty($previousContent)) { $previousContent = '' }
        if ($previousContent -cne $originalContent) { throw ('Previous-file verification failed for {0}. The target was not promoted.' -f $Path) }
    }
    Move-Item -LiteralPath $pendingPath -Destination $Path -Force -ErrorAction Stop
    [string]$savedContent = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
    if ([string]::IsNullOrEmpty($savedContent)) { $savedContent = '' }
    if ($savedContent -cne $Content) { throw ('Promoted save verification failed for {0}. Recovery artefacts were retained.' -f $Path) }
    Remove-Item -LiteralPath $markerPath -ErrorAction Stop
}

function Assert-FileWriteRecoveryState {
    <#
    .SYNOPSIS
        Stop before consuming or migrating a file with unresolved save evidence.
    .PARAMETER Path
        Target path to check even when the target itself is absent.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Path)
    foreach ($suffix in @('.write-in-progress', '.pending')) {
        if (Test-Path -LiteralPath ('{0}{1}' -f $Path, $suffix)) {
            throw ('Interrupted save recovery is required for {0}. Preserve the target, .pending, .previous and .write-in-progress files and review tenant state before resuming.' -f $Path)
        }
    }
    if (-not (Test-Path -LiteralPath $Path) -and (Test-Path -LiteralPath ('{0}.previous' -f $Path))) {
        throw ('Interrupted save recovery is required for {0}: a previous-file backup exists but the target is missing. Preserve the backup instead of starting an empty session.' -f $Path)
    }
}

function Assert-LocalStorageWriteState {
    <#
    .SYNOPSIS
        Validate current-mode operational save boundaries before resume or archive.
    .DESCRIPTION
        Checks device, bench and recent-user files plus the common Live audit file.
        Completed .previous backups alone are valid; incomplete saves fail closed.
    #>
    Assert-LocalCheckpointState
    $archiveMarker = '{0}.archive-in-progress' -f (Get-UserDataFilePath)
    if (Test-Path -LiteralPath $archiveMarker) {
        throw ('Interrupted session archive detected; manual recovery is required before reuse. Preserve and review the active files, archives and marker: {0}' -f $archiveMarker)
    }
    $paths = @((Get-UserDataFilePath), (Get-BuildBenchStatePath), (Get-RecentUsersFilePath))
    if (-not $Script:Runtime.IsDemoMode) { $paths += Get-MasterAuditFilePath }
    foreach ($path in $paths) { Assert-FileWriteRecoveryState -Path $path }
}

function Copy-StateFileIfNeeded {
    <#
    .SYNOPSIS
        Migrate missing state without overwriting existing or interrupted copies.
    .DESCRIPTION
        Before authority is established, existing copies must have exactly the
        same decoded UTF-8 content. Timestamps are not evidence of ancestry.
    .PARAMETER SourcePath
        Repository state file, checked for recovery evidence even if absent.
    .PARAMETER DestinationPath
        Fallback state file; existing operational content is never overwritten.
    .PARAMETER CheckOnly
        Preflight all copies before beginning any multi-file migration.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SourcePath,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$DestinationPath,
        [switch]$CheckOnly
    )

    foreach ($path in @($SourcePath, $DestinationPath)) {
        $archiveMarker = '{0}.archive-in-progress' -f $path
        if (Test-Path -LiteralPath $archiveMarker) {
            throw ('Interrupted session archive detected; manual recovery is required before migration. Preserve the active files, archives and marker: {0}' -f $archiveMarker)
        }
    }
    Assert-FileWriteRecoveryState -Path $DestinationPath
    Assert-FileWriteRecoveryState -Path $SourcePath
    if (-not (Test-Path -LiteralPath $SourcePath)) { return }
    if (Test-Path -LiteralPath $DestinationPath) {
        $sourceContent = [string](Get-Content -LiteralPath $SourcePath -Raw -Encoding UTF8 -ErrorAction Stop)
        $destinationContent = [string](Get-Content -LiteralPath $DestinationPath -Raw -Encoding UTF8 -ErrorAction Stop)
        if ($sourceContent -cne $destinationContent) {
            throw ('Conflicting storage copies require operator review: {0} and {1}. Neither copy was changed.' -f $SourcePath, $DestinationPath)
        }
        return
    }
    if ($CheckOnly) { return }

    try {
        $content = [string](Get-Content -Raw -LiteralPath $SourcePath -Encoding UTF8 -ErrorAction Stop)
        Write-Utf8File -Path $DestinationPath -Content $content
        Write-AutopilotExpressLog -Message ('Migrated Autopilot Express state from {0} to {1}.' -f $SourcePath, $DestinationPath) -Level 'WARN'
    }
    catch {
        Write-AutopilotExpressLog -Message ('Failed to migrate Autopilot Express state file {0}: {1}' -f $SourcePath, $_.Exception.Message) -Level 'WARN'
        throw
    }
}

function Get-ModeUserDataFilePrefix {
    if ($Script:Runtime.IsDemoMode) { return $Script:Config.DemoUserDataFilePrefix }
    return $Script:Config.UserDataFilePrefix
}

function Get-ModeRecentUsersFilePrefix {
    if ($Script:Runtime.IsDemoMode) { return $Script:Config.DemoRecentUsersFilePrefix }
    return $Script:Config.RecentUsersFilePrefix
}

function Get-ModeBuildBenchFilePrefix {
    if ($Script:Runtime.IsDemoMode) { return $Script:Config.DemoBuildBenchFilePrefix }
    return $Script:Config.BuildBenchFilePrefix
}

function Get-UserDataFilePath {
    param([string]$BasePath)

    $user = $env:USERNAME
    return Join-Path (Get-DataFolderPath -BasePath $BasePath) ("{0}-{1}.json" -f (Get-ModeUserDataFilePrefix), $user)
}

function Get-BuildBenchStatePath {
    param([string]$BasePath)

    return Join-Path (Get-DataFolderPath -BasePath $BasePath) ("{0}-{1}.json" -f (Get-ModeBuildBenchFilePrefix), $env:USERNAME)
}

function Get-RecentUsersFilePath {
    param([string]$BasePath)

    return Join-Path (Get-DataFolderPath -BasePath $BasePath) ("{0}-{1}.json" -f (Get-ModeRecentUsersFilePrefix), $env:USERNAME)
}

function Get-AutopilotExpressDefinitionPath {
    param([Parameter(Mandatory)][string]$FileName)
    if ([string]::IsNullOrWhiteSpace($Script:AutopilotExpressScriptDirectory)) {
        throw 'The Autopilot Express script directory has not been resolved.'
    }
    return Join-Path $Script:AutopilotExpressScriptDirectory $FileName
}

function Get-RuntimeConfigFilePath {
    return Get-AutopilotExpressDefinitionPath -FileName $Script:Config.RuntimeConfigFileName
}

function Get-ManifestFilePath {
    return Get-AutopilotExpressDefinitionPath -FileName $Script:Config.ManifestFileName
}

function Get-MasterAuditFilePath {
    param([string]$BasePath)

    return Join-Path (Get-DataFolderPath -BasePath $BasePath) $Script:Config.MasterAuditFileName
}

function Sync-RepoStateFilesToActiveStorage {
    <#
    .SYNOPSIS
        Establish fallback authority only after a reserved, verified migration.
    .DESCRIPTION
        Preflights every relevant file before copying any state. Existing copies
        must agree exactly until authority exists. After authority, repository
        normal ancestors are ignored so legitimate fallback updates remain
        authoritative. Checkpoint proposals in either root always block migration;
        their embedded root metadata must never be copied to another root.
        Operational files are neither deleted nor overwritten by migration.
    #>
    if (-not $Script:Storage.UsingFallback) { return }

    $repoBasePath = Get-RepoStorageBasePath
    $activeBasePath = Get-StorageBasePath
    Assert-LocalCheckpointState -BasePath $repoBasePath
    Assert-LocalCheckpointState -BasePath $activeBasePath
    $activePaths = @(Get-OperationalStoragePath -BasePath $activeBasePath)
    foreach ($path in $activePaths) { Assert-FileWriteRecoveryState -Path $path }
    if (Test-FallbackStorageAuthority -BasePath $activeBasePath) { return }

    Assert-ActiveStorageReservation
    $sourcePaths = @(Get-OperationalStoragePath -BasePath $repoBasePath)
    $fileNames = @(@($sourcePaths) + @($activePaths) | ForEach-Object { Split-Path -Leaf $_ } | Sort-Object -Unique)
    $sourceDataPath = Join-Path $repoBasePath $Script:Config.DataFolderRelative
    $activeDataPath = Join-Path $activeBasePath $Script:Config.DataFolderRelative
    foreach ($fileName in $fileNames) {
        Copy-StateFileIfNeeded -SourcePath (Join-Path $sourceDataPath $fileName) -DestinationPath (Join-Path $activeDataPath $fileName) -CheckOnly
    }
    foreach ($fileName in $fileNames) {
        Assert-ActiveStorageReservation
        Copy-StateFileIfNeeded -SourcePath (Join-Path $sourceDataPath $fileName) -DestinationPath (Join-Path $activeDataPath $fileName)
    }
    Assert-ActiveStorageReservation
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    $marker = 'AutopilotExpressFallbackAuthority/1|{0}|{1}|{2}' -f $modeName, $env:USERNAME, $Script:Storage.DataPath
    Write-Utf8File -Path (Get-FallbackStorageAuthorityPath -BasePath $activeBasePath) -Content $marker
    if (-not (Test-FallbackStorageAuthority -BasePath $activeBasePath)) { throw 'Fallback storage authority was not saved.' }
}

function Get-SessionLastUpdated {
    $sessionPaths = @((Get-UserDataFilePath), (Get-BuildBenchStatePath)) | Where-Object { Test-Path $_ }
    if (-not $sessionPaths -or $sessionPaths.Count -eq 0) { return $null }
    $latestItem = $sessionPaths | ForEach-Object { Get-Item -Path $_ } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    return $latestItem.LastWriteTime
}

function Move-SessionFileToArchive {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) { return }
    $archiveFolder = Get-ArchiveFolderPath
    $timestamp = '{0}-{1}' -f (Get-Date -Format 'yyyyMMdd-HHmmss'), [guid]::NewGuid().Guid
    $modeSlug = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    $leafName = Split-Path -Leaf $Path
    $extension = if ($leafName -match '(\.[^.]+)$') { $Matches[1] } else { '' }
    $baseName = if ($extension) { $leafName.Substring(0, $leafName.Length - $extension.Length) } else { $leafName }
    $archiveName = ('{0}-{1}-{2}{3}' -f $baseName, $modeSlug, $timestamp, $extension)
    Assert-FileWriteRecoveryState -Path $Path
    Move-Item -LiteralPath $Path -Destination (Join-Path $archiveFolder $archiveName) -Force -ErrorAction Stop
    $previousPath = '{0}.previous' -f $Path
    if (Test-Path -LiteralPath $previousPath) {
        Move-Item -LiteralPath $previousPath -Destination (Join-Path $archiveFolder ('{0}.previous' -f $archiveName)) -Force -ErrorAction Stop
    }
}

function Reset-CurrentSessionState {
    Assert-LocalStorageWriteState
    $archiveMarker = '{0}.archive-in-progress' -f (Get-UserDataFilePath)
    $archivePlan = @{ Devices = Get-UserDataFilePath; Bench = Get-BuildBenchStatePath; Actor = $env:USERNAME; Mode = $Script:Runtime.Mode; StartedAt = (Get-Date).ToString('o') } | ConvertTo-Json
    New-Item -ItemType File -Path $archiveMarker -Value $archivePlan -ErrorAction Stop | Out-Null
    Move-SessionFileToArchive -Path (Get-UserDataFilePath)
    Move-SessionFileToArchive -Path (Get-BuildBenchStatePath)
    Remove-Item -LiteralPath $archiveMarker -ErrorAction Stop
    $Script:BuildBench = Get-DefaultBuildBenchState
    return , @()
}

function ConvertTo-RecordDate {
    param($Value)

    if ($null -eq $Value) { return [DateTime]::MinValue }
    $dateValue = $Value
    if ($Value -is [hashtable] -and $null -ne $Value['value']) {
        $dateValue = $Value['value']
    }
    elseif ($Value -is [System.Collections.IDictionary] -and $null -ne $Value['value']) {
        $dateValue = $Value['value']
    }
    elseif ($null -ne $Value.value) {
        $dateValue = $Value.value
    }

    if ($dateValue -is [DateTime]) { return $dateValue }
    try { return Get-Date -Date ([string]$dateValue) } catch { return [DateTime]::MinValue }
}

function ConvertTo-PersistedDate {
    param($Value)

    $dateValue = ConvertTo-RecordDate -Value $Value
    if ($dateValue -eq [DateTime]::MinValue) { return $null }
    return Get-Date -Date $dateValue -Format 'o'
}

function ConvertTo-PersistedDeviceRecord {
    param([Parameter(Mandatory)]$Record)

    $persistedRecord = ConvertTo-NormalisedValue -Value $Record
    foreach ($dateProperty in @('StartedAt', 'LastUpdatedAt', 'CompletedAt', 'RecoveryStartedAt')) {
        $persistedRecord[$dateProperty] = ConvertTo-PersistedDate -Value $Record[$dateProperty]
    }
    return $persistedRecord
}

function Assert-AttemptHistory {
    <#
    .SYNOPSIS
        Validate detached writer evidence without migrating or repairing history.
    .PARAMETER Record
        Normalised record or audit dictionary. Absent legacy history is permitted.
    .DESCRIPTION
        Legacy results use the typed step validator on a copy; unknown execution
        dates remain null. Record IDs are text, not necessarily factory GUIDs.
    #>
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Record)
    if (-not $Record.Contains('AttemptHistory')) { return }
    if ($Record.AttemptHistory -isnot [array]) { throw 'Saved attempt history must be an array; evidence cannot be discarded.' }
    $attemptIds = @{}
    $sequence = 0
    foreach ($attempt in $Record.AttemptHistory) {
        $sequence++
        if ($attempt -isnot [System.Collections.IDictionary]) { throw 'Saved attempt history entries must be dictionaries.' }
        if (($attempt.Sequence -isnot [int] -and $attempt.Sequence -isnot [long]) -or $attempt.Sequence -ne $sequence) { throw 'Saved attempt history sequences must be contiguous and ordered.' }
        foreach ($field in @('AttemptId', 'StepId', 'ActionName', 'Actor', 'Mode', 'TenantId', 'Serial', 'RecordId', 'EvidenceKind')) {
            if ($attempt[$field] -isnot [string]) { throw ('Saved attempt history requires text field {0}.' -f $field) }
        }
        if ($attempt.AttemptId -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' -or $attemptIds.ContainsKey($attempt.AttemptId)) { throw 'Saved attempt IDs must be unique GUID strings.' }
        $attemptIds[$attempt.AttemptId] = $true
        if ([string]::IsNullOrWhiteSpace($attempt.StepId) -or $attempt.EvidenceKind -cnotin @('HandlerOutcome', 'LegacyEvidence')) { throw 'Saved attempt history has an invalid step or evidence kind.' }
        if ([string]::IsNullOrWhiteSpace($attempt.RecordId) -or $attempt.RecordId -cne $Record.RecordId -or $attempt.Serial -cne $Record.Serial) { throw 'Saved attempt history has cross-record identity context.' }
        if ($attempt.TenantId -cne '' -and ($attempt.TenantId -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' -or $attempt.TenantId -cne $Record.TenantId)) { throw 'Saved attempt history has invalid tenant context.' }
        if (-not $attempt.Contains('Timestamp') -or ($attempt.EvidenceKind -ceq 'HandlerOutcome' -and $null -eq $attempt.Timestamp)) { throw 'Saved handler outcomes require a timestamp.' }
        if ($null -ne $attempt.Timestamp) {
            if ($attempt.Timestamp -isnot [string] -or $attempt.Timestamp -notmatch '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,7})?(Z|[+-]\d{2}:\d{2})?$') { throw 'Saved attempt timestamps must be ISO date strings.' }
            $null = Get-Date -Date $attempt.Timestamp -ErrorAction Stop
        }
        if ($attempt.Result -isnot [System.Collections.IDictionary]) { throw 'Saved attempt results must be dictionaries.' }
        if ($attempt.EvidenceKind -ceq 'LegacyEvidence') {
            $null = ConvertTo-StepHashtable -Value @{ $attempt.StepId = $attempt.Result }
            continue
        }
        if ($attempt.Mode -cnotin @('normal', 'demo', 'Live', 'Demo') -or [string]::IsNullOrWhiteSpace($attempt.Actor) -or [string]::IsNullOrWhiteSpace($attempt.ActionName)) { throw 'Saved handler outcome has invalid actor, mode or action context.' }
        foreach ($flag in @('Success', 'IsSimulated')) {
            if ($attempt.Result[$flag] -isnot [bool]) { throw ('Saved attempt result {0} must be a Boolean.' -f $flag) }
        }
        foreach ($field in @('ActionName', 'Summary', 'Notes', 'CompletionState')) {
            if ($attempt.Result[$field] -isnot [string]) { throw ('Saved attempt result {0} must be text.' -f $field) }
        }
        if ($attempt.Result.ActionName -cne $attempt.ActionName -or $attempt.Result.CompletionState -cnotin @('Verified', 'TechnicianConfirmed', 'Submitted', 'Blocked', 'Failed', 'AuditedException', 'Simulated', 'LegacyCompleted') -or $attempt.Result.Data -isnot [System.Collections.IDictionary]) { throw 'Saved attempt result has invalid completion evidence.' }
    }
}

function Test-AttemptEvidenceEqual {
    <#
    .SYNOPSIS
        Compare normalised evidence structurally, never by dictionary JSON order.
    .PARAMETER Left
        Existing evidence, with dates normalised by the record staging helpers.
    .PARAMETER Right
        Proposed evidence. Arrays retain order; text and keys are case-sensitive.
    .OUTPUTS
        Boolean equality; ISO dates compare as UTC instants on either host.
    #>
    param($Left, $Right)
    if ($null -eq $Left -or $null -eq $Right) { return ($null -eq $Left -and $null -eq $Right) }
    if ($Left -is [System.Collections.IDictionary] -or $Right -is [System.Collections.IDictionary]) {
        if ($Left -isnot [System.Collections.IDictionary] -or $Right -isnot [System.Collections.IDictionary] -or $Left.Count -ne $Right.Count) { return $false }
        foreach ($key in $Left.Keys) {
            if (@($Right.Keys) -cnotcontains $key -or -not (Test-AttemptEvidenceEqual -Left $Left[$key] -Right $Right[$key])) { return $false }
        }
        return $true
    }
    if ($Left -is [array] -or $Right -is [array]) {
        if ($Left -isnot [array] -or $Right -isnot [array] -or $Left.Count -ne $Right.Count) { return $false }
        for ($index = 0; $index -lt $Left.Count; $index++) {
            if (-not (Test-AttemptEvidenceEqual -Left $Left[$index] -Right $Right[$index])) { return $false }
        }
        return $true
    }
    if ($Left -is [string] -or $Right -is [string]) {
        if ($Left -isnot [string] -or $Right -isnot [string]) { return $false }
        if ($Left -match '^\d{4}-\d{2}-\d{2}T' -and $Right -match '^\d{4}-\d{2}-\d{2}T') {
            try { return ((Get-Date -Date $Left -ErrorAction Stop).ToUniversalTime() -eq (Get-Date -Date $Right -ErrorAction Stop).ToUniversalTime()) }
            catch { return ($Left -ceq $Right) }
        }
        return ($Left -ceq $Right)
    }
    if ($Left -is [bool] -or $Right -is [bool]) { return ($Left -is [bool] -and $Right -is [bool] -and $Left -eq $Right) }
    return ($Left -eq $Right)
}

function Assert-AttemptHistoryPreserved {
    <#
    .SYNOPSIS
        Refuse replacement, truncation or removal of previously saved attempts.
    .PARAMETER Records
        Complete staged proposal, not mutated by validation.
    .PARAMETER ExistingRecords
        Independently read persisted records; malformed evidence fails closed.
    .PARAMETER AllowUnmatchedRecords
        Audit-only historical records remain in the ledger, outside this session.
    #>
    param(
        [AllowEmptyCollection()][System.Collections.IEnumerable]$Records = @(),
        [AllowEmptyCollection()][System.Collections.IEnumerable]$ExistingRecords = @(),
        [switch]$AllowUnmatchedRecords
    )
    $recordMap = @{}
    $attemptIds = @{}
    foreach ($record in $Records) {
        Assert-AttemptHistory -Record $record
        if ($record.RecordId -isnot [string] -or [string]::IsNullOrWhiteSpace($record.RecordId) -or $recordMap.ContainsKey($record.RecordId)) { throw 'Saved attempt history requires unique non-empty record IDs.' }
        $recordMap[$record.RecordId] = $record
        foreach ($attempt in $record.AttemptHistory) {
            if ($attemptIds.ContainsKey($attempt.AttemptId)) { throw 'Saved attempt IDs must be unique GUID strings across records.' }
            $attemptIds[$attempt.AttemptId] = $true
        }
    }
    $existingIds = @{}
    $existingAttemptIds = @{}
    foreach ($existing in $ExistingRecords) {
        Assert-AttemptHistory -Record $existing
        if ($existing.RecordId -isnot [string] -or [string]::IsNullOrWhiteSpace($existing.RecordId) -or $existingIds.ContainsKey($existing.RecordId)) { throw 'Saved attempt history requires unique non-empty record IDs.' }
        $existingIds[$existing.RecordId] = $true
        foreach ($attempt in $existing.AttemptHistory) {
            if ($existingAttemptIds.ContainsKey($attempt.AttemptId)) { throw 'Saved attempt IDs must be unique GUID strings across records.' }
            $existingAttemptIds[$attempt.AttemptId] = $true
        }
        $proposed = $recordMap[$existing.RecordId]
        $existingHistoryCount = 0
        if ($existing.Contains('AttemptHistory')) { $existingHistoryCount = $existing.AttemptHistory.Count }
        if ($null -eq $proposed) {
            if ($AllowUnmatchedRecords -or $existingHistoryCount -eq 0) { continue }
            throw 'Persisted attempt history record removal is refused; retain a soft-removed record.'
        }
        if ($existingHistoryCount -eq 0) { continue }
        if ($proposed.RecordId -cne $existing.RecordId -or $proposed.Serial -cne $existing.Serial -or ($existing.TenantId -and $proposed.TenantId -cne $existing.TenantId)) { throw 'Persisted attempt history identity alteration is refused.' }
        if ($proposed.AttemptHistory -isnot [array] -or $proposed.AttemptHistory.Count -lt $existing.AttemptHistory.Count) { throw 'Persisted attempt history truncation is refused.' }
        for ($index = 0; $index -lt $existing.AttemptHistory.Count; $index++) {
            if (-not (Test-AttemptEvidenceEqual -Left $existing.AttemptHistory[$index] -Right $proposed.AttemptHistory[$index])) { throw 'Persisted attempt history prefix alteration is refused.' }
        }
    }
}

function Get-MasterAuditProposal {
    <#
    .SYNOPSIS
        Stage the complete existing ledger merge without writing operational data.
    .PARAMETER Records
        Persisted device records to merge; the caller's objects are not changed.
    .OUTPUTS
        Exact proposed ledger JSON, or null in Demo mode.
    #>
    param([Parameter(Mandatory)][System.Collections.IEnumerable]$Records)
    if ($Script:Runtime.IsDemoMode) { return }
    $auditPath = Get-MasterAuditFilePath
    $existingEntries = @()
    if (Test-Path $auditPath) {
        try {
            $auditContent = Get-Content -Raw -Path $auditPath -ErrorAction Stop
            if ([string]::IsNullOrWhiteSpace([string]$auditContent)) { throw 'Saved audit records must not be null or empty content.' }
            $rawEntries = $auditContent | ConvertFrom-Json -ErrorAction Stop
            if ($null -eq $rawEntries -and $auditContent -notmatch '^\s*\[\s*\]\s*$') { throw 'Saved audit records must not be null or empty content.' }
            if ($null -ne $rawEntries) { $existingEntries = ConvertTo-NormalisedValue -Value @($rawEntries) }
        }
        catch {
            Write-AutopilotExpressLog -Message ('Failed to load master audit ledger: {0}' -f $_.Exception.Message) -Level 'WARN'
            throw
        }
    }

    Assert-AttemptHistoryPreserved -Records $Records -ExistingRecords $existingEntries -AllowUnmatchedRecords
    $entryMap = @{}
    foreach ($entry in $existingEntries) {
        if ($entry.RecordId) { $entryMap[$entry.RecordId] = $entry }
    }

    foreach ($record in @($Records)) {
        if (-not $record.RecordId) { continue }
        $completedAt = ConvertTo-PersistedDate -Value $record.CompletedAt
        $entryMap[$record.RecordId] = [ordered]@{
            RecordId             = $record.RecordId
            TenantId             = $record.TenantId
            AutopilotDeviceId    = $record.AutopilotDeviceId
            ManagedDeviceId      = $record.ManagedDeviceId
            AzureAdDeviceId      = $record.AzureAdDeviceId
            Serial               = $record.Serial
            ConfigItem           = $record.ConfigItem
            SiteCode             = $record.SiteCode
            DeviceType           = $record.DeviceType
            GroupTag             = $record.GroupTag
            StartedAt            = ConvertTo-PersistedDate -Value $record.StartedAt
            CompletedAt          = $completedAt
            StartedBy            = $record.StartedBy
            LastUpdatedAt        = ConvertTo-PersistedDate -Value $record.LastUpdatedAt
            LastUpdatedBy        = $record.LastUpdatedBy
            Status               = $record.Status
            Result               = $record.Status
            IsCompletionVerified = $record.IsCompletionVerified
            IntuneDeviceName     = $record.IntuneDeviceName
            EntraDeviceId        = $record.EntraDeviceId
            TechnicianUser       = $record.TechnicianUserPrincipalName
            FinalPrimaryUserId   = $record.FinalPrimaryUserId
            FinalPrimaryUser     = $record.FinalPrimaryUserPrincipalName
            FinalPrimaryUserName = $record.FinalPrimaryUserDisplayName
            RecoveryActive       = $record.RecoveryActive
            RecoveryStartedAt    = ConvertTo-PersistedDate -Value $record.RecoveryStartedAt
            RecoveryReason       = $record.RecoveryReason
            RecoveryHistory      = ConvertTo-NormalisedValue -Value $record.RecoveryHistory
            AttemptHistory       = ConvertTo-NormalisedValue -Value $record.AttemptHistory
            Steps                = ConvertTo-NormalisedValue -Value $record.Steps
        }
    }

    $serialisedEntries = @($entryMap.Values | Sort-Object Serial, StartedAt)
    $auditJson = if ($serialisedEntries.Count -gt 0) { $serialisedEntries | ConvertTo-Json -Depth 100 } else { '[]' }
    return $auditJson
}

function Update-MasterAuditLedger {
    param([Parameter(Mandatory)][System.Collections.IEnumerable]$Records, [string]$ProposedContent)
    if ($Script:Runtime.IsDemoMode) { return }
    if (-not $PSBoundParameters.ContainsKey('ProposedContent')) { $ProposedContent = Get-MasterAuditProposal -Records $Records }
    Write-Utf8File -Path (Get-MasterAuditFilePath) -Content $ProposedContent
}

function Get-LocalCheckpointPath {
    <#
    .SYNOPSIS
        Locate a per-user, per-mode checkpoint proposal, not a migration candidate.
    .PARAMETER BasePath
        Explicit root for read-only preflight without root selection or directory
        creation. When omitted, use the active root for existing checkpoint saves.
    .OUTPUTS
        Checkpoint proposal path in the requested root and current mode.
    #>
    param([ValidateNotNullOrEmpty()][string]$BasePath)
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    $dataPath = if ($PSBoundParameters.ContainsKey('BasePath')) { Join-Path $BasePath $Script:Config.DataFolderRelative } else { Get-DataFolderPath }
    return Join-Path $dataPath ('autopilot-express-{0}-{1}.checkpoint.json' -f $modeName, $env:USERNAME)
}

function Assert-LocalCheckpointState {
    <#
    .SYNOPSIS
        Reject checkpoint proposals and orphan writer evidence without changes.
    .PARAMETER BasePath
        Explicit root to inspect before probes, reservation or migration. Fallback
        authority does not establish lineage for an unfinished source checkpoint.
        When omitted, inspect the active root as before.
    #>
    param([ValidateNotNullOrEmpty()][string]$BasePath)
    $path = if ($PSBoundParameters.ContainsKey('BasePath')) { Get-LocalCheckpointPath -BasePath $BasePath } else { Get-LocalCheckpointPath }
    Assert-FileWriteRecoveryState -Path $path
    if (Test-Path -LiteralPath $path) {
        throw ('Unresolved local checkpoint at {0}. Preserve all evidence and inspect local and tenant state before resuming; no automatic replay or rollback is permitted.' -f $path)
    }
}

function Get-LocalCheckpointInspection {
    <#
    .SYNOPSIS
        Return read-only checkpoint proposal and file evidence for operator review.
    .DESCRIPTION
        Never promotes, repairs or deletes evidence and never invokes tenant actions.
        Damaged markers throw and remain untouched. This is not reconciliation approval.
    .OUTPUTS
        Checkpoint envelope and the presence of each target and recovery artefact.
    #>
    $path = Get-LocalCheckpointPath
    $proposal = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
    if ($proposal.SchemaVersion -ne 1 -or $proposal.Root -cne (Get-DataFolderPath) -or
        $proposal.User -cne $env:USERNAME -or $proposal.Mode -cne $modeName -or
        [string]::IsNullOrWhiteSpace([string]$proposal.Token) -or $proposal.RecordsJson -isnot [string] -or
        ($null -ne $proposal.AuditJson -and $proposal.AuditJson -isnot [string]) -or
        ($null -ne $proposal.BenchJson -and $proposal.BenchJson -isnot [string])) { throw 'Invalid local checkpoint metadata or proposal. Evidence was not changed.' }
    foreach ($content in @($proposal.RecordsJson, $proposal.AuditJson, $proposal.BenchJson)) {
        if ($null -ne $content) { $null = $content | ConvertFrom-Json -ErrorAction Stop }
    }
    $evidence = @()
    $paths = @($path, (Get-UserDataFilePath), (Get-BuildBenchStatePath))
    if (-not $Script:Runtime.IsDemoMode) { $paths += Get-MasterAuditFilePath }
    foreach ($target in $paths) {
        foreach ($suffix in @('', '.pending', '.previous', '.write-in-progress')) {
            $evidence += @{ Path = ('{0}{1}' -f $target, $suffix); Exists = (Test-Path -LiteralPath ('{0}{1}' -f $target, $suffix)) }
        }
    }
    return @{ Proposal = $proposal; Evidence = $evidence }
}

function Get-UserDeviceRecords {
    $path = Get-UserDataFilePath
    $records = @()
    if (-not (Test-Path $path)) {
        return , $records
    }
    try {
        $json = Get-Content -Raw -Path $path -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace([string]$json)) { throw 'Saved device records must not be null or empty content.' }
        $data = $json | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $data -and $json -notmatch '^\s*\[\s*\]\s*$') { throw 'Saved device records must not be null or empty content.' }
        $items = @($data)
        if ($null -eq $data) { $items = @() }
        foreach ($r in $items) {
            $r = ConvertTo-NormalisedValue -Value $r
            if ($r -isnot [System.Collections.IDictionary]) { throw 'Every saved device record must be a dictionary.' }
            if ($r.Contains('TenantId') -and ($r.TenantId -isnot [string] -or
                    ($r.TenantId -cne '' -and $r.TenantId -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'))) {
                throw 'Saved device TenantId must be empty legacy text or a GUID string.'
            }
            foreach ($flag in @('IsCompletionVerified', 'RecoveryActive')) {
                if ($r.Contains($flag) -and $r[$flag] -isnot [bool]) { throw ('Saved device flag {0} must be a Boolean.' -f $flag) }
            }
            foreach ($textField in @('RecordId', 'Serial', 'ConfigItem', 'AutopilotDeviceId', 'ManagedDeviceId', 'AzureAdDeviceId', 'EntraDeviceId', 'IntuneDeviceName', 'SiteCode', 'DeviceType', 'GroupTag', 'Status', 'StartedBy', 'LastUpdatedBy', 'CompletedBy', 'RecoveryReason', 'TechnicianUserPrincipalName', 'TechnicianUser', 'FinalPrimaryUserId', 'FinalPrimaryUserPrincipalName', 'FinalPrimaryUser', 'FinalPrimaryUserDisplayName', 'FinalPrimaryUserName')) {
                if ($null -ne $r[$textField] -and $r[$textField] -isnot [string]) { throw ('Saved device field {0} must be text.' -f $textField) }
            }
            foreach ($dateField in @('StartedAt', 'LastUpdatedAt', 'CompletedAt', 'RecoveryStartedAt')) {
                if ($null -ne $r[$dateField]) {
                    $dateInput = $r[$dateField]
                    if ($dateInput -is [System.Collections.IDictionary] -and $dateInput.Contains('value')) { $dateInput = $dateInput.value }
                    if ($dateInput -isnot [string] -and $dateInput -isnot [DateTime]) { throw ('Saved device date {0} has an invalid type.' -f $dateField) }
                    $null = Get-Date -Date $dateInput -ErrorAction Stop
                }
            }
            if ($r.Contains('Steps') -and $null -eq $r.Steps) { throw 'Saved Steps cannot be null.' }
            Assert-AttemptHistory -Record $r
            if ($r.Contains('RecoveryHistory')) {
                if ($null -eq $r.RecoveryHistory) { $r.RecoveryHistory = @() }
                if ($r.RecoveryHistory -isnot [array]) { throw 'Saved recovery history must be an array.' }
                foreach ($entry in $r.RecoveryHistory) {
                    if ($entry -isnot [System.Collections.IDictionary]) { throw 'Saved recovery history entries must be dictionaries.' }
                    foreach ($field in @('Stage', 'Actor', 'Timestamp')) {
                        if ($entry[$field] -isnot [string] -or [string]::IsNullOrWhiteSpace($entry[$field])) { throw ('Saved recovery history requires text field {0}.' -f $field) }
                    }
                    $null = Get-Date -Date $entry.Timestamp -ErrorAction Stop
                    if ($entry.Contains('Steps')) { $entry.Steps = ConvertTo-StepHashtable -Value $entry.Steps }
                }
            }
            $obj = New-EmptyDeviceRecord
            $obj.TenantId = if ($r.Contains('TenantId')) { $r.TenantId } else { '' }
            $obj.RecordId = if ($r.RecordId) { $r.RecordId } else { [guid]::NewGuid().Guid }
            $obj.AutopilotDeviceId = if ($null -ne $r.AutopilotDeviceId) { [string]$r.AutopilotDeviceId } else { '' }
            $obj.ManagedDeviceId = if ($null -ne $r.ManagedDeviceId) { [string]$r.ManagedDeviceId } else { '' }
            $obj.AzureAdDeviceId = if ($null -ne $r.AzureAdDeviceId) { [string]$r.AzureAdDeviceId } else { '' }
            $obj.IntuneDeviceName = if ($null -ne $r.IntuneDeviceName) { [string]$r.IntuneDeviceName } else { '' }
            $obj.Serial = $r.Serial
            $obj.EntraDeviceId = if ($null -ne $r.EntraDeviceId) { [string]$r.EntraDeviceId } else { '' }
            $obj.ConfigItem = $r.ConfigItem
            $obj.SiteCode = $r.SiteCode
            $obj.DeviceType = $r.DeviceType
            $obj.GroupTag = $r.GroupTag
            $obj.Status = if ($r.Status) { $r.Status } else { 'new' }
            $obj.Steps = ConvertTo-StepHashtable -Value $r.Steps
            $obj.StartedAt = ConvertTo-RecordDate -Value $r.StartedAt
            $obj.StartedBy = if ($r.StartedBy) { $r.StartedBy } else { '' }
            $obj.LastUpdatedAt = if ($r.LastUpdatedAt) { ConvertTo-RecordDate -Value $r.LastUpdatedAt } else { $obj.StartedAt }
            $obj.LastUpdatedBy = if ($r.LastUpdatedBy) { $r.LastUpdatedBy } else { $obj.StartedBy }
            $obj.CompletedAt = ConvertTo-RecordDate -Value $r.CompletedAt
            $obj.CompletedBy = if ($r.CompletedBy) { $r.CompletedBy } else { '' }
            $obj.IsCompletionVerified = [bool]$r.IsCompletionVerified
            $obj.TechnicianUserPrincipalName = if ($r.TechnicianUserPrincipalName) { [string]$r.TechnicianUserPrincipalName } elseif ($r.TechnicianUser) { [string]$r.TechnicianUser } else { '' }
            $obj.FinalPrimaryUserId = if ($r.FinalPrimaryUserId) { [string]$r.FinalPrimaryUserId } else { '' }
            $obj.FinalPrimaryUserPrincipalName = if ($r.FinalPrimaryUserPrincipalName) { [string]$r.FinalPrimaryUserPrincipalName } elseif ($r.FinalPrimaryUser) { [string]$r.FinalPrimaryUser } else { '' }
            $obj.FinalPrimaryUserDisplayName = if ($r.FinalPrimaryUserDisplayName) { [string]$r.FinalPrimaryUserDisplayName } elseif ($r.FinalPrimaryUserName) { [string]$r.FinalPrimaryUserName } else { '' }
            $obj.RecoveryActive = [bool]$r.RecoveryActive
            $obj.RecoveryStartedAt = ConvertTo-RecordDate -Value $r.RecoveryStartedAt
            $obj.RecoveryReason = if ($r.RecoveryReason) { [string]$r.RecoveryReason } else { '' }
            $obj.RecoveryHistory = if ($r.RecoveryHistory) { @(ConvertTo-NormalisedValue -Value $r.RecoveryHistory) } else { @() }
            if ($r.Contains('AttemptHistory')) { $obj.AttemptHistory = ConvertTo-NormalisedValue -Value $r.AttemptHistory }
            $records += , $obj
        }
        Assert-DeviceRecordIdentity -Records $records
        Assert-AttemptHistoryPreserved -Records $records
        return , $records
    }
    catch {
        Write-AutopilotExpressLog -Message ('Failed to load user data file: {0}' -f $_.Exception.Message) -Level 'ERROR'
        throw
    }
}

function Write-UserDeviceRecords {
    <#
    .SYNOPSIS
        Persist staged records, audit and initialised bench under one checkpoint.
    .DESCRIPTION
        The recoverable writer verifies the checkpoint before any operational save.
        Every error propagates and retains checkpoint evidence until operator review.
        This detects interrupted local saves; it is not an atomic transaction, fsync,
        tenant-action replay mechanism or remote rollback.
    .PARAMETER Records
        Complete proposed record collection; staging never mutates caller objects.
    #>
    param([Parameter(Mandatory)][System.Collections.IEnumerable]$Records)
    $path = Get-UserDataFilePath
    $checkpointToken = $null
    try {
        Assert-LocalCheckpointState
        $serialisableRecords = @($Records | ForEach-Object { ConvertTo-PersistedDeviceRecord -Record $_ })
        Assert-AttemptHistoryPreserved -Records $serialisableRecords -ExistingRecords (Get-UserDeviceRecords)
        $json = if ($serialisableRecords.Count -gt 0) { $serialisableRecords | ConvertTo-Json -Depth 100 } else { '[]' }
        $auditJson = $null
        if (-not $Script:Runtime.IsDemoMode) { $auditJson = Get-MasterAuditProposal -Records $serialisableRecords }
        $benchVariable = Get-Variable -Name BuildBench -Scope Script -ErrorAction SilentlyContinue
        $benchJson = if ($null -ne $benchVariable -and $null -ne $benchVariable.Value) { $benchVariable.Value | ConvertTo-Json -Depth 6 } else { $null }
        $checkpointPath = Get-LocalCheckpointPath
        $checkpointToken = [guid]::NewGuid().Guid
        $modeName = if ($Script:Runtime.IsDemoMode) { 'demo' } else { 'live' }
        $checkpoint = @{ SchemaVersion = 1; Token = $checkpointToken; Root = (Get-DataFolderPath); User = $env:USERNAME; Mode = $modeName; StartedAt = (Get-Date -Format o); RecordsJson = $json; AuditJson = $auditJson; BenchJson = $benchJson }
        Write-Utf8File -Path $checkpointPath -Content ($checkpoint | ConvertTo-Json -Depth 8)
        $Script:LocalCheckpointToken = $checkpointToken
        Write-Utf8File -Path $path -Content $json
        Write-AutopilotExpressLog -Message ('Saved {0} device record(s) to {1}' -f $serialisableRecords.Count, $path) -Level 'INFO'
        Update-MasterAuditLedger -Records $serialisableRecords -ProposedContent $auditJson
        if ($null -ne $benchJson) { Save-BuildBenchState -CheckpointToken $checkpointToken -ProposedContent $benchJson }
        Remove-Item -LiteralPath $checkpointPath -ErrorAction Stop
    }
    catch {
        Write-AutopilotExpressLog -Message ('Failed to save user device records: {0}' -f $_.Exception.Message) -Level 'ERROR'
        throw
    }
    finally {
        if ($null -ne $checkpointToken) { $Script:LocalCheckpointToken = $null }
    }
}

# INPUT VALIDATION UTILITIES
function Read-ValidatedInput {
    param(
        [Parameter(Mandatory)][string]$Prompt,
        [string]$Default,
        [ValidateSet('String', 'Int', 'Choice')][string]$Type = 'String',
        [string[]]$Choices,
        [switch]$AllowEmpty
    )
    :inputValidation while ($true) {
        # Do not append colon here; Read-Host will add ':' automatically
        $renderPrompt = if ($Default) { ('{0} (default: {1})' -f $Prompt, $Default) } else { ('{0}' -f $Prompt) }
        $response = Read-Host -Prompt $renderPrompt
        if ([string]::IsNullOrWhiteSpace($response)) { $response = $Default }
        if (-not $response -and -not $AllowEmpty) { Write-Host 'Input cannot be empty.'; continue }
        switch ($Type) {
            'Int' {
                if ($response -notmatch '^-?[0-9]+$') { Write-Host 'Please enter a valid number.'; continue inputValidation }
            }
            'Choice' {
                if ($Choices -and -not ($Choices | ForEach-Object { $_.ToLower() } | Where-Object { $_ -eq $response.ToLower() })) { Write-Host ('Please choose one of: {0}' -f ($Choices -join ', ')); continue inputValidation }
            }
        }
        return $response
    }
}

function ConvertTo-OptionalInteger {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value) -or $Value -notmatch '^-?[0-9]+$') { return $null }
    try { return [int]$Value } catch { return $null }
}

function Get-ConfiguredSerialPattern {
    $pattern = [string]$Script:RuntimeConfig.scannerSerialNormalisation.serialPattern
    if ([string]::IsNullOrWhiteSpace($pattern)) { return '^[A-Za-z0-9-]{4,64}$' }
    return $pattern
}

function Get-ConfiguredScannerSerialRules {
    return @($Script:RuntimeConfig.scannerSerialNormalisation.rules | Where-Object { $null -ne $_ })
}

function Get-UriQueryParameterValues {
    param(
        [Parameter(Mandatory)][string]$Query,
        [Parameter(Mandatory)][string]$Name
    )

    $values = @()
    foreach ($pair in @($Query.TrimStart('?') -split '&')) {
        if ([string]::IsNullOrWhiteSpace($pair)) { continue }
        $parts = $pair -split '=', 2
        $key = $parts[0].Replace('+', ' ')
        if ($key -ine $Name) { continue }
        $value = if ($parts.Count -gt 1) { $parts[1].Replace('+', ' ') } else { '' }
        $values += $value
    }
    return @($values)
}

function ConvertTo-NormalisedSerialInput {
    param([Parameter(Mandatory)][string]$InputValue)

    $rawValue = $InputValue.Trim()
    $serialPattern = Get-ConfiguredSerialPattern
    if ([string]::IsNullOrWhiteSpace($rawValue)) {
        return [ordered]@{ Success = $false; Serial = $null; WasTransformed = $false; RuleName = $null; Message = 'Serial input cannot be empty.' }
    }
    if ($rawValue -match $serialPattern) {
        return [ordered]@{ Success = $true; Serial = $rawValue.ToUpperInvariant(); WasTransformed = $false; RuleName = $null; Message = '' }
    }

    if ($rawValue -notmatch '^(?<scheme>https?)://(?<host>[^/?#:]+)(?::[0-9]+)?(?<path>/[^?#]*)?(?:\?(?<query>[^#]*))?/?$') {
        return [ordered]@{ Success = $false; Serial = $null; WasTransformed = $false; RuleName = $null; Message = 'Input is neither a valid serial nor a supported scanner URL.' }
    }
    $urlHost = $Matches['host']
    $urlPath = if ($Matches['path']) { $Matches['path'] } else { '/' }
    $urlQuery = $Matches['query']

    foreach ($rule in Get-ConfiguredScannerSerialRules) {
        $hostPattern = [string]$rule.hostPattern
        $pathPattern = [string]$rule.pathPattern
        $queryParameter = [string]$rule.queryParameter
        if ([string]::IsNullOrWhiteSpace($hostPattern) -or [string]::IsNullOrWhiteSpace($pathPattern) -or [string]::IsNullOrWhiteSpace($queryParameter)) { continue }
        if ($urlHost -notmatch $hostPattern -or $urlPath -notmatch $pathPattern) { continue }

        $values = @(Get-UriQueryParameterValues -Query $urlQuery -Name $queryParameter)
        if ($values.Count -ne 1 -or [string]::IsNullOrWhiteSpace([string]$values[0])) {
            return [ordered]@{ Success = $false; Serial = $null; WasTransformed = $true; RuleName = [string]$rule.name; Message = ('Scanner URL matched {0}, but query parameter {1} was missing or ambiguous.' -f $rule.name, $queryParameter) }
        }

        $candidateSerial = ([string]$values[0]).Trim().ToUpperInvariant()
        $valuePattern = if ($rule.valuePattern) { [string]$rule.valuePattern } else { $serialPattern }
        if ($candidateSerial -notmatch $valuePattern -or $candidateSerial -notmatch $serialPattern) {
            return [ordered]@{ Success = $false; Serial = $null; WasTransformed = $true; RuleName = [string]$rule.name; Message = ('Scanner URL matched {0}, but the extracted value is not a valid serial.' -f $rule.name) }
        }
        return [ordered]@{ Success = $true; Serial = $candidateSerial; WasTransformed = $true; RuleName = [string]$rule.name; Message = '' }
    }

    return [ordered]@{ Success = $false; Serial = $null; WasTransformed = $false; RuleName = $null; Message = 'Scanner URL does not match a configured serial-extraction rule.' }
}

function Read-NormalisedSerialInput {
    param([Parameter(Mandatory)][string]$Prompt, [string]$Default, [switch]$AllowCancel)

    while ($true) {
        $rawValue = Read-ValidatedInput -Prompt $Prompt -Default $Default
        if ($AllowCancel -and $rawValue -eq '0') { return $null }
        $result = ConvertTo-NormalisedSerialInput -InputValue $rawValue
        if (-not $result.Success) {
            Write-Host ('Unable to determine a valid serial: {0}' -f $result.Message)
            continue
        }
        if ($result.WasTransformed) {
            Write-Host ('Scanner rule "{0}" extracted serial: {1}' -f $result.RuleName, $result.Serial)
            $confirmed = Read-ValidatedInput -Prompt 'Use this extracted serial? (Y/N)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
            if ($confirmed.ToUpper() -ne 'Y') { continue }
        }
        return $result.Serial
    }
}

function Select-Site {
    param([string]$CurrentSiteCode)
    Show-ScriptScreen -Title 'Select Site'
    Write-Host 'Select site:'
    $defaultSiteIndex = 0
    for ($i = 0; $i -lt $Script:Sites.Count; $i++) {
        $s = $Script:Sites[$i]
        if ($s.Code -eq $CurrentSiteCode) { $defaultSiteIndex = $i }
        $marker = if ($s.Code -eq $CurrentSiteCode) { '*' } else { ' ' }
        Write-Host ('{0} [{1}] {2} {3}' -f ($i + 1), $s.Code, $s.Name, $marker)
    }
    Write-Host ''
    Write-Host '0. Return without changing site'
    while ($true) {
        $choice = Read-ValidatedInput -Prompt 'Enter number of site (0 returns)' -Type 'Int' -Default ($defaultSiteIndex + 1)
        if ($choice -eq '0') { return $CurrentSiteCode }
        $index = (ConvertTo-OptionalInteger -Value $choice) - 1
        if ($index -lt 0 -or $index -ge $Script:Sites.Count) { Write-Host ''; Write-Host 'Invalid site selection. Choose a displayed number or 0.'; continue }
        return $Script:Sites[$index].Code
    }
}

function Add-ScreenFeedback {
    <#
    .SYNOPSIS
        Retain the last five readable output lines in transient screen state.
    .PARAMETER State
        Screen-owned dictionary, never persisted as workflow evidence.
    .PARAMETER Text
        Result or refusal text. Long lines wrap to the available console width.
    #>
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$State,
        [AllowEmptyCollection()][string[]]$Text = @()
    )
    $width = 118
    try { if ($Host.UI.RawUI.WindowSize.Width -gt 2) { $width = $Host.UI.RawUI.WindowSize.Width - 2 } }
    catch { $width = 118 }
    foreach ($message in $Text) {
        foreach ($rawLine in @($message -split '\r?\n')) {
            $line = $rawLine.Trim()
            while ($line.Length -gt $width) {
                $length = $line.LastIndexOf(' ', $width)
                if ($length -le 0) { $length = $width }
                $State.Lines = @(@($State.Lines) + $line.Substring(0, $length) | Select-Object -Last 5)
                $line = $line.Substring($length).TrimStart()
            }
            if ($line) { $State.Lines = @(@($State.Lines) + $line | Select-Object -Last 5) }
        }
    }
}

function Get-MainMenuDefinition {
    <# .SYNOPSIS Return ordered labels and stable routes; numbers are derived from order. #>
    @(
        @{ Action = 'Bench'; Label = 'Build bench - manage active builds' }
        @{ Action = 'NewDevice'; Label = 'Start work on a new device' }
        @{ Action = 'TrackedDevice'; Label = 'Work on a tracked device' }
        @{ Action = 'Outstanding'; Label = "What's outstanding for a device" }
        @{ Action = 'Maintain'; Label = 'Maintain my device list' }
        @{ Action = 'Statistics'; Label = 'My stats and progress' }
        @{ Action = 'Site'; Label = 'Change current site' }
        @{ Action = 'About'; Label = 'About this script' }
        @{ Action = 'Enhancements'; Label = 'Enhancements & questions' }
        @{ Action = 'ArchiveSession'; Label = 'Archive saved session and start fresh' }
    )
}

function Show-MainMenu {
    param([string]$CurrentSiteCode)
    Show-ScriptScreen -Title 'Main Menu'
    $siteObj = $Script:Sites | Where-Object { $_.Code -eq $CurrentSiteCode }
    $siteDisplay = if ($siteObj) { ('{0} - {1}' -f $siteObj.Code, $siteObj.Name) } else { 'Not Set' }
    $graphSessionDisplay = if ($Script:GraphSession.Connected) { $Script:GraphSession.Account } else { 'Not Connected' }
    Write-Host ('Current Site: {0} | Graph Session: {1}' -f $siteDisplay, $graphSessionDisplay)
    Write-Host ''
    $menu = @(Get-MainMenuDefinition)
    for ($index = 0; $index -lt $menu.Count; $index++) {
        Write-Host ('{0}. {1}' -f ($index + 1), $menu[$index].Label)
    }
    Write-Host '0. Exit'
    Write-Host ''
    $choice = Read-ValidatedInput -Prompt 'Choose an option' -Default '0' -Type Choice -Choices (@('0') + @(1..$menu.Count | ForEach-Object { [string]$_ }))
    if ($choice -eq '0') { return 'Exit' }
    return $menu[([int]$choice - 1)].Action
}

# DEVICE WORKFLOW & STATUS MENUS
function Read-NewDeviceIdentityField {
    <#
    .SYNOPSIS
        Validate one new-device identifier before confirmation, retaining correction defaults.
    .PARAMETER Field
        Serial uses configured scanner rules; CI remains a textual identifier, not an invented numeric schema.
    .OUTPUTS
        Valid trimmed identifier, or null on explicit cancellation. Existing records are never modified.
    #>
    param(
        [Parameter(Mandatory)][ValidateSet('Serial', 'ConfigItem')][string]$Field,
        [Parameter(Mandatory)][hashtable]$Records,
        [string]$Default
    )
    while ($true) {
        $prompt = 'Enter {0} (0 cancels)' -f $Script:Config.Nomenclature[$Field]
        $value = if ($Field -eq 'Serial') { Read-NormalisedSerialInput -Prompt $prompt -Default $Default -AllowCancel } else { Read-ValidatedInput -Prompt $prompt -Default $Default }
        if ($null -eq $value -or $value -eq '0') { return $null }
        $value = $value.Trim()
        if (-not $value -or $value -match '[\x00-\x1F\x7F]') { Write-Host 'Enter a non-empty identifier without control characters.'; continue }
        $conflict = $null
        foreach ($record in @($Records.Value)) {
            $existingSerial = ([string]$record.Serial).Trim()
            $existingCI = ([string]$record.ConfigItem).Trim()
            if ($Field -eq 'Serial' -and ($value -eq $existingSerial -or ($record.Status -ne 'removed' -and $value -eq $existingCI))) {
                $conflict = 'Serial {0} already identifies an existing workflow. Correct it or cancel to resume that device.' -f $value
                break
            }
            if ($Field -eq 'ConfigItem' -and ($value -eq $existingSerial -or ($record.Status -ne 'removed' -and $value -eq $existingCI))) {
                $conflict = 'Configuration Item {0} conflicts with an existing workflow. Enter the correct CI or 0 to cancel.' -f $value
                break
            }
        }
        if ($conflict) { Write-Host ''; Write-Host $conflict; $Default = $value; continue }
        return $value
    }
}

function Start-NewDeviceWorkflow {
    <#
    .SYNOPSIS
        Capture a new local workflow after field validation and explicit confirmation.
    .DESCRIPTION
        Declining retains site, serial, CI and type as editable defaults. Identifiers
        are checked during entry and again before insertion. Cancellation creates
        nothing; Graph operations run separately through the tracked manifest actions.
    .PARAMETER Records
        Current record container, updated only after confirmed identity validation.
    .OUTPUTS
        Selected site code; existing device evidence is not reset or reassigned.
    #>
    param([string]$CurrentSiteCode, [hashtable]$Records)
    Show-ScriptScreen -Title 'Start Work on a New Device'
    $siteCode = $CurrentSiteCode
    $serial = ''
    $configItem = ''
    $deviceType = $Script:DeviceTypes[0]
    while ($true) {
        $confirm = Read-ValidatedInput -Prompt ('Working at site {0}. Change? (Y/N; 0 cancels)' -f $siteCode) -Default 'N' -Type 'Choice' -Choices @('Y', 'N', '0')
        if ($confirm -eq '0') { return $siteCode }
        if ($confirm.ToUpper() -eq 'Y') { $siteCode = Select-Site -CurrentSiteCode $siteCode; Show-ScriptScreen -Title 'Start Work on a New Device' }
        $serial = Read-NewDeviceIdentityField -Field Serial -Records $Records -Default $serial
        if (-not $serial) { return $siteCode }
        $configItem = Read-NewDeviceIdentityField -Field ConfigItem -Records $Records -Default $configItem
        if (-not $configItem) { return $siteCode }
        $deviceType = Select-DeviceType -Default $deviceType
        # Enforce Group Tag pattern (SITECODE-Devicetype, preserve case); no override permitted
        $expectedTag = ('{0}-{1}' -f $siteCode, ($deviceType -replace '\s', ''))
        Write-Host ''
        Write-Host 'Please confirm the details:'
        Write-Host ('  {0}: {1}' -f $Script:Config.Nomenclature.Serial, $serial)
        Write-Host ('  {0}: {1}' -f $Script:Config.Nomenclature.ConfigItem, $configItem)
        Write-Host ('  {0}: {1}' -f $Script:Config.Nomenclature.Site, $siteCode)
        Write-Host ('  {0}: {1}' -f $Script:Config.Nomenclature.DeviceType, $deviceType)
        Write-Host ('  {0}: {1}' -f $Script:Config.Nomenclature.GroupTag, $expectedTag)
        $proceed = Read-ValidatedInput -Prompt 'Proceed with these details? (Y/N; 0 cancels)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N', '0')
        if ($proceed -eq '0') { return $siteCode }
        if ($proceed.ToUpper() -eq 'Y') {
            try {
                Assert-DeviceRecordIdentity -Records (@($Records.Value) + , @{ Serial = $serial; ConfigItem = $configItem; Status = 'new' })
            }
            catch {
                Write-Host $_.Exception.Message
                Write-Host 'Correct the identifiers below, or enter 0 to cancel and maintain the existing list.'
                continue
            }
            $record = New-DeviceRecordObject -Serial $serial -ConfigItem $configItem -SiteCode $siteCode -DeviceType $deviceType -GroupTag $expectedTag
            Add-DeviceRecord -Records $Records -Record $record
            Write-UserDeviceRecords -Records $Records.Value
            Write-AutopilotExpressLog -Message ('Added new device Serial={0} CI={1} Site={2} DeviceType={3}' -f $serial, $configItem, $siteCode, $deviceType) -Level 'INFO'
            Show-ReturnToMainMenu
            break
        }
        else {
            Write-Host "Let's correct the details. You will be re-prompted."
        }
    }
    return $siteCode
}

function Show-WorkflowOutcome {
    <#
    .SYNOPSIS
        Separate the current device's last outcome with text and optional colour.
    .PARAMETER Result
        Returned evidence, shown only after successful persistence; submission is not completion.
    .OUTPUTS
        Host output only; no record or evidence changes.
    #>
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Device,
        [Parameter(Mandatory)][System.Collections.IDictionary]$Step,
        [Parameter(Mandatory)][System.Collections.IDictionary]$Result
    )
    $state = [string]$Result.CompletionState
    $background = 'DarkYellow'
    $label = 'PENDING'
    if (-not $Result.Success -or $state -in @('Failed', 'Blocked')) { $label = 'FAILED / NOT COMPLETED' }
    elseif ($state -eq 'Simulated' -or ($Result.IsSimulated -and $state -in @('Verified', 'TechnicianConfirmed'))) { $label = 'SIMULATED' }
    elseif ($Result.Success -and $state -in @('Verified', 'TechnicianConfirmed')) { $label = 'SUCCESS' }
    if ($label -in @('SUCCESS', 'SIMULATED')) { $background = 'DarkGreen' }
    elseif ($label -eq 'FAILED / NOT COMPLETED') { $background = 'DarkRed' }
    Write-Host ''
    Write-Host '---------------- LAST STEP RESULT ----------------'
    Write-Host ('{0}: Serial={1} | CI={2}' -f $label, $Device.Serial, $Device.ConfigItem) -BackgroundColor $background -ForegroundColor White
    Write-Host ('{0}. {1} [{2}]' -f $Step.Id, $Step.DisplayName, $state) -BackgroundColor $background -ForegroundColor White
    Write-Host ([string]$Result.Summary)
    if ($Result.Notes) { Write-Host ([string]$Result.Notes) }
    Write-Host '--------------------------------------------------'
}

function Invoke-AutopilotSequence {
    <#
    .SYNOPSIS
        Perform guarded manifest steps while retaining the selected device workflow.
    .PARAMETER Device
        Optional existing record supplied by Outstanding Work to avoid reselection.
    .NOTES
        Evidence-labelled outcomes appear only after persistence succeeds. Live
        actions remain subject to configured scopes, tenant gates and confirmations.
    #>
    param([hashtable]$Records, [System.Collections.IDictionary]$Device)
    if ($Device -and (@($Records.Value) -notcontains $Device -or $Device.Status -eq 'removed')) {
        Write-Host 'This device is no longer available in the current device list.'
        return
    }
    if (-not $Device) {
        Show-ScriptScreen -Title 'Select a Tracked Device'
        $Device = Select-DeviceFromRecords -Records $Records -Purpose 'work on'
    }
    if (-not $device) { return }
    $nextCommand = '8'
    $deviceCommand = '9'
    $commandIds = @(Get-EnabledManifestSteps | ForEach-Object { $_.Id })
    while ($commandIds -contains $nextCommand) { $nextCommand = 'NEXT-{0}' -f $nextCommand }
    while ($commandIds -contains $deviceCommand) { $deviceCommand = 'SELECT-{0}' -f $deviceCommand }
    $feedback = @()
    $lastOutcome = $null
    while ($true) {
        Show-ScriptScreen -Title 'Work on a Tracked Device'
        Write-Host ('Serial: {0}   CI: {1}   Status: {2}' -f $device.Serial, $device.ConfigItem, $device.Status)
        Write-Host 'Device workflow (manifest-driven)'
        Write-Host ''
        foreach ($step in (Get-EnabledManifestSteps)) {
            if (Test-ManifestStepCompleted -Device $device -StepId $step.Id) {
                $stepState = '[Done]'
            }
            elseif (Test-ManifestStepAttempted -Device $device -StepId $step.Id) {
                $stepState = '[Retry]'
            }
            else {
                $eligibility = Test-ManifestStepEligibility -Device $device -StepDefinition $step
                if ($eligibility.Eligible) {
                    $stepState = '[Todo]'
                }
                elseif ($eligibility.MissingStepIds.Count -gt 0) {
                    $stepState = ('[Blocked: {0}]' -f ($eligibility.MissingStepIds -join ', '))
                }
                else {
                    $stepState = ('[Blocked: {0} required]' -f $eligibility.ActivationRequirement)
                }
            }
            Write-Host ("{0}. {1} {2}" -f $step.Id, $step.DisplayName, $stepState)
        }
        Write-Host 'X. Record Autopilot failure and enter recovery mode'
        Write-Host ''
        Write-Host ('{0}. Run next eligible step' -f $nextCommand)
        Write-Host ('{0}. Select another device' -f $deviceCommand)
        Write-Host '0. Return to main menu'
        if ($lastOutcome) { Show-WorkflowOutcome -Device $device -Step $lastOutcome.Step -Result $lastOutcome.Result }
        if ($feedback.Count -gt 0) {
            Write-Host ''
            Write-Host 'Last action:'
            foreach ($line in $feedback) { Write-Host $line }
        }
        Write-Host ''
        $opt = Read-ValidatedInput -Prompt 'Choose option' -Default '0'
        if ($opt -eq '0' -or ($opt -eq 'R' -and $commandIds -notcontains 'R')) { return }
        if ($opt -eq $deviceCommand) {
            Show-ScriptScreen -Title 'Select a Tracked Device'
            $selected = Select-DeviceFromRecords -Records $Records -Purpose 'work on'
            if ($selected) { $device = $selected; $feedback = @(); $lastOutcome = $null }
            continue
        }
        if ($opt -eq 'X') {
            $lastOutcome = $null
            Enter-DeviceRecoveryMode -Device $device
            Write-UserDeviceRecords -Records $Records.Value
            $feedback = @('Recovery decision recorded. Consult the current action eligibility.')
            continue
        }
        if ($opt -eq $nextCommand) {
            $lastOutcome = $null
            $opt = Get-NextStepId -Device $device
            if (-not $opt) {
                $readiness = Test-DeviceReadyForDispatch -Device $device
                $feedback = if ($readiness.Ready) { @('All required steps are complete.') } else { @('No next action is eligible. Required steps remain: {0}.' -f ($readiness.BlockingStepIds -join ', ')) }
                continue
            }
        }
        if ($opt) {
            $sel = Get-ManifestStepDefinition -StepId $opt
            if ($sel) {
                $result = Invoke-AutopilotManifestStep -Device $device -StepDefinition $sel
                Write-ManifestStepResult -Device $device -StepDefinition $sel -Result $result
                $lastOutcome = @{ Step = $sel; Result = $result }
                $feedback = @()
                Write-AutopilotExpressLog -Message ('Recorded step {0} ({1}) for Serial={2} Success={3}' -f $opt, $sel.DisplayName, $device.Serial, $result.Success) -Level 'INFO'
            }
            else { $feedback = @('Invalid step selection. Choose a displayed step, {0}, {1} or 0.' -f $nextCommand, $deviceCommand); continue }
        }
        Write-UserDeviceRecords -Records $Records.Value  # Save updated records after step selection
    }
}

function Show-DeviceWorkflowStatus {
    <#
    .SYNOPSIS
        Display one action per line with truthful completion and eligibility.
    .PARAMETER Device
        Tracked record; this view does not mutate progress or evidence.
    #>
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Device)
    Write-Host ('Device Serial={0} CI={1} Status={2}' -f $Device.Serial, $Device.ConfigItem, $Device.Status)
    foreach ($section in @('Completed', 'Retry', 'Outstanding', 'Conditional recovery')) {
        $lines = @()
        foreach ($step in (Get-EnabledManifestSteps)) {
            $completed = Test-ManifestStepCompleted -Device $Device -StepId $step.Id
            $attempted = Test-ManifestStepAttempted -Device $Device -StepId $step.Id
            $kind = if ($completed) { 'Completed' } elseif ($attempted) { 'Retry' } elseif ($step.IsConditional) { 'Conditional recovery' } else { 'Outstanding' }
            if ($kind -ne $section) { continue }
            $state = if ($completed -or $attempted) { [string]$Device.Steps[$step.Id].CompletionState } else { '' }
            if (-not $state) {
                $eligibility = Test-ManifestStepEligibility -Device $Device -StepDefinition $step
                $state = if ($eligibility.Eligible) { 'Eligible' } elseif ($eligibility.MissingStepIds.Count) { 'Requires: {0}' -f ($eligibility.MissingStepIds -join ', ') } else { '{0} required' -f $eligibility.ActivationRequirement }
            }
            $lines += '  {0}. {1} [{2}]' -f $step.Id, $step.DisplayName, $state
        }
        Write-Host ''
        Write-Host ('{0} Steps:' -f $section)
        if ($lines.Count -eq 0) { Write-Host '  None' }
        foreach ($line in $lines) { Write-Host $line }
    }
}

function Get-DeviceOutstanding {
    <# .SYNOPSIS Display outstanding steps for a device. #>
    param([hashtable]$Records)
    while ($true) {
        Show-ScriptScreen -Title 'Outstanding Work - Select Device'
        $device = Select-DeviceFromRecords -Records $Records -Purpose 'inspect outstanding work'
        if (-not $device) { return }
        while ($true) {
            Show-ScriptScreen -Title 'Outstanding Work'
            Show-DeviceWorkflowStatus -Device $device
            Write-Host ''
            Write-Host '1. Work on this device'
            Write-Host '2. Select another device'
            Write-Host '0. Return to main menu'
            $choice = Read-ValidatedInput -Prompt 'Choose option' -Default '0' -Type 'Choice' -Choices @('0', '1', '2')
            if ($choice -eq '0') { return }
            if ($choice -eq '2') { break }
            Invoke-AutopilotSequence -Records $Records -Device $device
        }
    }
}

function Update-DeviceStatus {
    <# .SYNOPSIS Update device status (new|in-progress|completed|removed). #>
    param([hashtable]$Records)
    while ($true) {
        Show-ScriptScreen -Title 'Maintain My Device List'
        $device = Select-DeviceFromRecords -Records $Records -Purpose 'update status'
        if (-not $device) { return }
        Write-Host ''
        $status = Read-ValidatedInput -Prompt 'Enter status (new,in-progress,completed,removed)' -Type 'Choice' -Choices @('new', 'in-progress', 'completed', 'removed') -Default $device.Status
        if ($status -eq 'completed') {
            $readiness = Test-DeviceReadyForDispatch -Device $device
            if (-not $readiness.Ready) {
                Write-Host ''
                Write-Host ('Cannot mark this device completed. Required steps remain: {0}.' -f ($readiness.BlockingStepIds -join ', '))
                Write-Host 'Choose another status or 0 to return to device selection.'
                $status = Read-ValidatedInput -Prompt 'Status' -Default $device.Status -Type Choice -Choices @('0', 'new', 'in-progress', 'removed')
                if ($status -eq '0') { continue }
            }
        }
        if ($status -ne $device.Status) {
            $device.Status = $status
            if ($status -eq 'completed') { $device.CompletedAt = Get-Date; $device.CompletedBy = $env:USERNAME }
            $device.LastUpdatedAt = Get-Date; $device.LastUpdatedBy = $env:USERNAME
            Write-UserDeviceRecords -Records $Records.Value
            Write-AutopilotExpressLog -Message ('Updated status {0} for Serial={1}' -f $status, $device.Serial) -Level 'INFO'
        }
        Write-Host ''
        Write-Host ('Updated Serial={0} | CI={1} | Status={2}' -f $device.Serial, $device.ConfigItem, $device.Status)
        $choice = Read-ValidatedInput -Prompt '1. Maintain another device; 0. Return to main menu' -Default '0' -Type Choice -Choices @('0', '1')
        if ($choice -eq '0') { return }
    }
}

function Get-UserStats {
    <# .SYNOPSIS Show per-user stats as tables (overall and by site), newest date first. #>
    param([hashtable]$Records)
    Show-ScriptScreen -Title 'My Stats and Progress'
    $recordsLocal = @()
    foreach ($record in @($Records['Value'])) {
        if ($record -is [System.Collections.IDictionary] -and $record['RecordId']) {
            $recordsLocal += , $record
        }
        elseif ($record -is [System.Collections.IEnumerable] -and $record -isnot [string]) {
            foreach ($nestedRecord in $record) {
                if ($nestedRecord -is [System.Collections.IDictionary] -and $nestedRecord['RecordId']) {
                    $recordsLocal += , $nestedRecord
                }
            }
        }
    }
    if (-not $recordsLocal -or $recordsLocal.Count -eq 0) { Write-Host ''; Write-Host 'No records to display.'; return }

    function Show-StatsTable {
        param($Rows, [string]$Title)
        Write-Host ('--- {0} ---' -f $Title)
        $header = ('| {0,-10} | {1,-7} | {2,-7} | {3,-7} | {4,-7} | {5,-7} |' -f 'Date', 'Desktop', 'Laptop', 'WOW', 'NUC', 'Total')
        $rule = '-' * $header.Length
        Write-Host $header
        Write-Host $rule
        $totDesktop = 0
        $totLaptop = 0
        $totWOW = 0
        $totNUC = 0
        $totAll = 0
        foreach ($r in $Rows) {
            Write-Host ('| {0,-10} | {1,-7} | {2,-7} | {3,-7} | {4,-7} | {5,-7} |' -f $r['Date'], $r['Desktop'], $r['Laptop'], $r['WOW'], $r['NUC'], $r['Total'])
            $totDesktop += $r['Desktop']
            $totLaptop += $r['Laptop']
            $totWOW += $r['WOW']
            $totNUC += $r['NUC']
            $totAll += $r['Total']
        }
        Write-Host $rule
        Write-Host ('| {0,-10} | {1,-7} | {2,-7} | {3,-7} | {4,-7} | {5,-7} |' -f 'Total', $totDesktop, $totLaptop, $totWOW, $totNUC, $totAll)
        Write-Host ''
    }

    function Get-StatsRows {
        param($InputRecords)
        $dailyRows = @{}
        foreach ($record in @($InputRecords)) {
            $startedAt = ConvertTo-RecordDate -Value $record['StartedAt']
            if ($startedAt -eq [DateTime]::MinValue) { continue }
            $dateKey = Get-Date -Date $startedAt -Format 'd/M/yyyy'
            if ($null -eq $dailyRows[$dateKey]) {
                $dailyRows[$dateKey] = [ordered]@{ Date = $dateKey; SortDate = $startedAt; Desktop = 0; Laptop = 0; WOW = 0; NUC = 0; Total = 0 }
            }
            $deviceType = [string]$record['DeviceType']
            if ($null -ne $dailyRows[$dateKey][$deviceType]) { $dailyRows[$dateKey][$deviceType]++ }
            $dailyRows[$dateKey]['Total']++
        }
        return @($dailyRows.Values | Sort-Object { $_['SortDate'] } -Descending)
    }

    Show-StatsTable -Rows (Get-StatsRows -InputRecords $recordsLocal) -Title 'Overall'
    $siteCodes = @($recordsLocal | ForEach-Object { $_['SiteCode'] } | Where-Object { $_ } | Sort-Object -Unique)
    foreach ($siteCode in $siteCodes) {
        $siteRecords = @($recordsLocal | Where-Object { $_['SiteCode'] -eq $siteCode })
        Show-StatsTable -Rows (Get-StatsRows -InputRecords $siteRecords) -Title ('By site: {0}' -f $siteCode)
    }
}

function Show-AboutScript {
    <#
    .SYNOPSIS
        Display editable script information without accessing tenant services.
    .DESCRIPTION
        Edit this function's text to customise the About screen. Zero returns
        immediately; Enter uses the same safe navigation default.
    #>
    Show-ScriptScreen -Title 'About This Script'
    Write-Host 'Autopilot Express'
    Write-Host 'Version: 0.1.0 - development; not production-approved'
    Write-Host 'Author: Michael Harris (developed collaboratively)'
    Write-Host ''
    Write-Host 'Technician workflow for Autopilot Checklist - New Device v1.4.'
    Write-Host 'Tracks builds and selected Intune/Microsoft Entra actions; physical work remains with the technician.'
    Write-Host 'Supports PowerShell 7 and Windows PowerShell 5.1. Demo performs no tenant actions.'
    Write-Host 'Live requires approved permissions and a real-device pilot. Shared storage is disabled.'
    Write-Host ''
    Write-Host 'Documentation: README.md   Testing: TESTING.md   Licence: repository LICENSE (MIT)'
    Write-Host ''
    [void](Read-ValidatedInput -Prompt '0 to return to the main menu' -Default '0' -Type 'Choice' -Choices @('0'))
}

function Show-EnhancementsQuestions {
    <# .SYNOPSIS Display potential enhancements & ask clarifying questions. #>
    Show-ScriptScreen -Title 'Enhancements and Questions'
    Write-Host '--- Potential Enhancements ---'
    foreach ($e in $Script:EnhancementManifest) {
        Write-Host ("{0}. {1} [{2}]" -f $e.Id, $e.Title, $e.Status)
        if ($e.Description) { Write-Host ('    - {0}' -f $e.Description) }
    }
    Write-Host ''
    Write-Host '--- Clarifying Questions ---'
    Write-Host 'A. Required retention period for device build history?'
    Write-Host 'B. Need encryption at rest for JSON data files?'
    Write-Host 'C. External CMDB column mapping examples?'
    Write-Host 'D. Preferred approach for roll-up (central share vs Graph storage)?'
}

# ===== Build Bench =====
$Script:BuildBench = Get-DefaultBuildBenchState

function Save-BuildBenchState {
    <#
    .SYNOPSIS
        Save current bench state unless an unresolved checkpoint blocks it.
    .PARAMETER CheckpointToken
        Internal token accepted only within the owning record writer's save scope.
    .PARAMETER ProposedContent
        Exact staged bench JSON; requires the active token and matching marker.
    .DESCRIPTION
        Standalone saves use the current bench. All guard and writer errors propagate.
    #>
    param([string]$CheckpointToken, [string]$ProposedContent)
    try {
        $activeToken = Get-Variable -Name LocalCheckpointToken -Scope Script -ErrorAction SilentlyContinue
        if ($CheckpointToken -and $null -ne $activeToken -and $activeToken.Value -ceq $CheckpointToken) {
            $marker = Get-Content -LiteralPath (Get-LocalCheckpointPath) -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if ($marker.Token -cne $CheckpointToken -or $marker.BenchJson -cne $ProposedContent) { throw 'Local checkpoint ownership or bench proposal changed.' }
        }
        else {
            if ($PSBoundParameters.ContainsKey('CheckpointToken') -or $PSBoundParameters.ContainsKey('ProposedContent')) {
                throw 'Staged bench saves require the active local checkpoint token.'
            }
            Assert-LocalCheckpointState
        }
        $json = if ($PSBoundParameters.ContainsKey('ProposedContent')) { $ProposedContent } else { $Script:BuildBench | ConvertTo-Json -Depth 6 }
        Write-Utf8File -Path (Get-BuildBenchStatePath) -Content $json
    }
    catch {
        Write-AutopilotExpressLog -Message ('Failed to save build bench: {0}' -f $_.Exception.Message) -Level 'ERROR'
        throw
    }
}

function Get-BuildBenchState {
    $path = Get-BuildBenchStatePath
    if (Test-Path $path) {
        try {
            $state = Get-Content -Raw -Path $path -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $normalisedState = Get-DefaultBuildBenchState
            $normalisedState.Active = [bool]$state.Active
            $normalisedState.SiteCode = $state.SiteCode
            $normalisedState.DeviceType = $state.DeviceType
            $normalisedState.Faults = @()
            foreach ($fault in @($state.Faults)) {
                if ($null -ne $fault) { $normalisedState.Faults += [string]$fault }
            }
            $normalisedState.Positions = @()
            foreach ($position in @($state.Positions)) {
                if ($null -eq $position) { continue }
                $normalisedState.Positions += [ordered]@{
                    Index      = [int]$position.Index
                    Serial     = $position.Serial
                    ConfigItem = $position.ConfigItem
                }
            }
            Assert-BenchPositionIdentity -Positions $normalisedState.Positions
            return $normalisedState
        }
        catch {
            Write-AutopilotExpressLog -Message ('Failed to load build bench state: {0}' -f $_.Exception.Message) -Level 'ERROR'
            throw
        }
    }
    return Get-DefaultBuildBenchState
}

function Show-SessionArchive {
    <#
    .SYNOPSIS
        Select and archive this user's current-mode resumable session without deleting history.
    .DESCRIPTION
        The current storage schema has one device/bench pair per user and mode.
        No defaults select a session; No and CANCEL preserve it. CLEAR confirms
        removal from active use. Audit, receipts, other modes/users and archives remain.
    .OUTPUTS
        True only after the selected session was archived successfully. Errors propagate.
    #>
    param([Parameter(Mandatory)][hashtable]$Records)
    Show-ScriptScreen -Title 'Archive Saved Sessions'
    $paths = @((Get-UserDataFilePath), (Get-BuildBenchStatePath))
    $hasSavedFiles = @($paths | Where-Object { Test-Path -LiteralPath $_ }).Count -gt 0
    if (-not $hasSavedFiles -and -not @($Records.Value).Count -and -not $Script:BuildBench.Active) {
        Write-Host 'No current-mode session is available to archive. Already archived history is not listed.'
        Show-ReturnToMainMenu
        return $false
    }
    Write-Host ('1. {0} session | User: {1} | Devices: {2} | Bench active: {3}' -f $Script:Runtime.Mode, $env:USERNAME, @($Records.Value).Count, $Script:BuildBench.Active)
    foreach ($path in $paths) { Write-Host ('   Active file: {0}' -f $path) }
    Write-Host '0. Cancel without changes'
    $selection = Read-ValidatedInput -Prompt 'Select session number (0 cancels)' -Default '0' -Type Choice -Choices @('0', '1')
    if ($selection -eq '0') { return $false }
    Write-Host 'WARNING: This ends the active session and clears its device list and bench from this view. A new session will be set up next.'
    Write-Host 'Files are archived, not permanently deleted. Audit history, sync receipts, other users/modes and existing archives are not removed. No tenant/device change is made.'
    $confirm = Read-ValidatedInput -Prompt 'Archive this session? (Y/N)' -Default 'N' -Type Choice -Choices @('Y', 'N')
    if ($confirm -ne 'Y') { return $false }
    $clear = Read-ValidatedInput -Prompt 'Type CLEAR to archive, or CANCEL to keep the session' -Default 'CANCEL' -Type Choice -Choices @('CLEAR', 'CANCEL')
    if ($clear -ne 'CLEAR') { return $false }
    Assert-LocalStorageWriteState
    Write-UserDeviceRecords -Records $Records.Value
    $Records.Value = Reset-CurrentSessionState
    Write-AutopilotExpressLog -Message 'Current-mode device and bench session archived; starting new session setup. Audit and receipt evidence retained.' -Level INFO
    return $true
}

function Initialize-SessionState {
    Sync-RepoStateFilesToActiveStorage
    $hasUserData = Test-Path (Get-UserDataFilePath)
    $hasBenchData = Test-Path (Get-BuildBenchStatePath)
    if (-not $hasUserData -and -not $hasBenchData) {
        $Script:BuildBench = Get-DefaultBuildBenchState
        return , @()
    }
    $lastUpdated = Get-SessionLastUpdated
    $resumePrompt = ('Resume existing {0} session last updated {1}? (Y/N)' -f $Script:Runtime.ModeDisplayName, $lastUpdated.ToString('yyyy-MM-dd HH:mm:ss'))
    $resumeExisting = Read-ValidatedInput -Prompt $resumePrompt -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
    if ($resumeExisting.ToUpper() -ne 'Y') {
        Write-AutopilotExpressLog -Message ('Archiving existing {0} session and starting a clean session.' -f $Script:Runtime.ModeDisplayName) -Level 'INFO'
        return , (Reset-CurrentSessionState)
    }
    $Script:BuildBench = Get-BuildBenchState
    return , (Get-UserDeviceRecords)
}

function Get-SessionDefaultSiteCode {
    param([System.Collections.IEnumerable]$Records)
    if ($Script:BuildBench.Active -and $Script:BuildBench.SiteCode) { return $Script:BuildBench.SiteCode }
    $recordArray = @($Records)
    if ($recordArray.Count -gt 0) {
        $latestRecord = $recordArray | Sort-Object LastUpdatedAt -Descending | Select-Object -First 1
        if ($latestRecord -and $latestRecord.SiteCode) { return $latestRecord.SiteCode }
    }
    return $Script:Sites[0].Code
}

function Get-ConfiguredSearchLimit {
    if ($Script:RuntimeConfig.autopilot.directorySearchLimit) { return [int]$Script:RuntimeConfig.autopilot.directorySearchLimit }
    return 15
}

function Get-ConfiguredDirectorySearchPageLimit {
    <#
    .SYNOPSIS
        Returns the bounded number of Graph pages permitted per user search.
    .DESCRIPTION
        The optional autopilot.directorySearchPageLimit defaults to ten pages.
        Rejects invalid values rather than allowing an unbounded directory scan.
    .OUTPUTS
        Integer from 1 to 100. Throws when a configured value is invalid.
    #>
    $configuredValue = $Script:RuntimeConfig.autopilot.directorySearchPageLimit
    if ($null -eq $configuredValue) { return 10 }
    if ([string]$configuredValue -notmatch '^[1-9][0-9]{0,2}$' -or [int]$configuredValue -gt 100) {
        throw 'autopilot.directorySearchPageLimit must be an integer from 1 to 100.'
    }
    return [int]$configuredValue
}

function Get-ConfiguredRecentUserLimit {
    if ($Script:RuntimeConfig.autopilot.recentUsersLimit) { return [int]$Script:RuntimeConfig.autopilot.recentUsersLimit }
    return 8
}

function Get-ConfiguredDeploymentProfileDisplayName {
    if ($Script:RuntimeConfig.autopilot.deploymentProfileDisplayName) { return [string]$Script:RuntimeConfig.autopilot.deploymentProfileDisplayName }
    return ''
}

function Get-ConfiguredPreProvisioningGroupDisplayName {
    if ($Script:RuntimeConfig.autopilot.preProvisioningGroupDisplayName) { return [string]$Script:RuntimeConfig.autopilot.preProvisioningGroupDisplayName }
    return ''
}

function Get-ConfiguredMissingSerialHandoffNote {
    if ($Script:RuntimeConfig.autopilot.missingSerialHandoffNote) { return [string]$Script:RuntimeConfig.autopilot.missingSerialHandoffNote }
    return 'Use the external Autopilot upload guide when the serial is not yet present in Autopilot.'
}

function Get-ConfiguredTechnicianPrefixes {
    $prefixes = @($Script:RuntimeConfig.autopilot.technicianUpnPrefixes)
    if ($prefixes.Count -gt 0) { return $prefixes }
    return @('C', 'E')
}

function Get-ConfiguredGraphScopes {
    $scopes = @($Script:RuntimeConfig.graph.requiredScopes)
    if ($scopes.Count -gt 0) { return $scopes }
    return @(
        'DeviceManagementServiceConfig.ReadWrite.All',
        'DeviceManagementManagedDevices.ReadWrite.All',
        'Group.ReadWrite.All',
        'GroupMember.ReadWrite.All',
        'User.Read.All',
        'Directory.Read.All'
    )
}

function Get-ConfiguredGraphModules {
    $modules = @($Script:RuntimeConfig.graph.requiredModules)
    if ($modules.Count -gt 0) { return $modules }
    return @('Microsoft.Graph.Authentication', 'Microsoft.Graph.DeviceManagement.Enrollment')
}

function Get-EmptyGraphSession {
    return [ordered]@{
        Connected         = $false
        IsSimulated       = $Script:Runtime.IsDemoMode
        Account           = ''
        DisplayName       = ''
        UserId            = ''
        TenantId          = ''
        Scopes            = @()
        CapabilityResults = @()
    }
}

function Get-EnabledManifestSteps {
    return @($Script:StepManifest | Where-Object { $_.Enabled })
}

function Get-ManifestStepDefinition {
    param([Parameter(Mandatory)][string]$StepId)
    return $Script:StepManifest | Where-Object { $_.Id -eq $StepId } | Select-Object -First 1
}

function Get-ManifestActionStepId {
    <#
    .SYNOPSIS
        Resolve a safety-critical action to its current enabled manifest step ID.
    .PARAMETER ActionName
        Semantic action role, independent of technician-facing step labels.
    .OUTPUTS
        Unique step ID. Missing or ambiguous roles throw before state changes.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ActionName)
    $definitions = @(Get-EnabledManifestSteps | Where-Object { $_.ActionName -eq $ActionName })
    if ($definitions.Count -ne 1 -or [string]::IsNullOrWhiteSpace([string]$definitions[0].Id)) {
        throw ('An enabled unique manifest step is required for action {0}.' -f $ActionName)
    }
    return [string]$definitions[0].Id
}

function Read-JsonDefinitionFile {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Description
    )
    if (-not (Test-Path $Path)) { throw ('{0} file not found: {1}' -f $Description, $Path) }
    $rawContent = Get-Content -Raw -Path $Path
    if ([string]::IsNullOrWhiteSpace($rawContent)) { throw ('{0} file is empty: {1}' -f $Description, $Path) }
    $parsedContent = $rawContent | ConvertFrom-Json
    return ConvertTo-NormalisedValue -Value $parsedContent
}

function Test-ManifestDependencyGraph {
    param([Parameter(Mandatory)][object[]]$Steps)

    $issues = @()
    $stepsById = @{}
    foreach ($step in $Steps) {
        $stepId = [string]$step.Id
        if ([string]::IsNullOrWhiteSpace($stepId)) {
            $issues += 'Each manifest step must have an ID.'
            continue
        }
        if ($null -ne $stepsById[$stepId]) {
            $issues += ('Manifest step ID {0} is duplicated.' -f $stepId)
            continue
        }
        $stepsById[$stepId] = $step
    }

    foreach ($stepId in $stepsById.Keys) {
        $activationRequirement = [string]$stepsById[$stepId].ActivationRequirement
        if ($activationRequirement -notin @('None', 'RecoveryMode')) {
            $issues += ('Manifest step {0} has unsupported activation requirement {1}.' -f $stepId, $activationRequirement)
        }
        $prerequisiteIds = @($stepsById[$stepId].PrerequisiteStepIds)
        $duplicatePrerequisites = @($prerequisiteIds | Group-Object | Where-Object { $_.Count -gt 1 } | Select-Object -ExpandProperty Name)
        if ($duplicatePrerequisites.Count -gt 0) {
            $issues += ('Manifest step {0} repeats prerequisite(s): {1}.' -f $stepId, ($duplicatePrerequisites -join ', '))
        }
        foreach ($prerequisiteId in $prerequisiteIds) {
            if ($prerequisiteId -eq $stepId) {
                $issues += ('Manifest step {0} cannot depend on itself.' -f $stepId)
            }
            elseif ($null -eq $stepsById[$prerequisiteId]) {
                $issues += ('Manifest step {0} references undefined prerequisite {1}.' -f $stepId, $prerequisiteId)
            }
        }
    }
    if ($issues.Count -gt 0) { throw ('Manifest dependency graph is invalid: {0}' -f ($issues -join ' ')) }

    $visitState = @{}
    foreach ($stepId in $stepsById.Keys) { $visitState[$stepId] = 'Unvisited' }
    function Invoke-ManifestStepDependency {
        param([Parameter(Mandatory)][string]$StepId)

        if ($visitState[$StepId] -eq 'Visiting') { throw ('Manifest dependency graph contains a cycle involving step {0}.' -f $StepId) }
        if ($visitState[$StepId] -eq 'Visited') { return }
        $visitState[$StepId] = 'Visiting'
        foreach ($prerequisiteId in @($stepsById[$StepId].PrerequisiteStepIds)) {
            Invoke-ManifestStepDependency -StepId $prerequisiteId
        }
        $visitState[$StepId] = 'Visited'
    }
    foreach ($stepId in $stepsById.Keys) { Invoke-ManifestStepDependency -StepId $stepId }
}

function Assert-ManifestDefinition {
    <#
    .SYNOPSIS
        Reject invalid raw workflow definitions before coercion or startup access.
    .DESCRIPTION
        Supports the current 1.6 schema and its non-breaking patch revisions.
        Optional defaults remain compatible; explicitly supplied fields must have
        their declared types. Phase ordering and step-label semantics are separate.
    .PARAMETER Manifest
        Normalised JSON dictionary, without any runtime state changes.
    .OUTPUTS
        No output. Throws an actionable error for an unsupported definition.
    #>
    param([Parameter(Mandatory)][AllowNull()][AllowEmptyCollection()]$Manifest)
    if ($Manifest -isnot [System.Collections.IDictionary]) { throw 'Manifest must be a JSON object.' }
    if ($Manifest.manifestVersion -isnot [string] -or $Manifest.manifestVersion -notmatch '^1\.6\.(0|[1-9][0-9]*)$') {
        throw 'Unsupported manifestVersion. This entry point supports schema 1.6.x only.'
    }
    foreach ($collectionName in @('steps', 'workflowPhases')) {
        if ($Manifest[$collectionName] -isnot [array] -or $Manifest[$collectionName].Count -eq 0) {
            throw ('Manifest {0} must be a non-empty JSON array.' -f $collectionName)
        }
    }
    $supportedActions = @(
        'ResolveAutopilotDevice', 'RemoveAssociatedManagedDevice', 'ApplyGroupTag',
        'ValidateDeploymentProfile', 'AddToPreProvisioningGroup', 'ClearUserlessEnrollmentStatus',
        'AssignTechnicianPrimaryUser', 'RetryFailedApplications', 'RemoveFromPreProvisioningGroup',
        'AssignFinalPrimaryUser', 'ConfirmImagingAndOobe', 'ConfirmReseal', 'ConfirmBootToSignIn',
        'ConfirmFirstSignIn', 'ConfirmApplicationBaseline', 'ConfirmUpdatesAndShutdown', 'ConfirmRecoveryReadiness'
    )
    $stepsById = @{}
    $actions = @{}
    $enabledCount = 0
    foreach ($entry in @($Manifest.steps) + @($Manifest.workflowPhases)) {
        if ($entry -isnot [System.Collections.IDictionary]) { throw 'Each manifest step and phase must be a JSON object.' }
        foreach ($field in @('id', 'displayName')) {
            if ($entry[$field] -isnot [string] -or [string]::IsNullOrWhiteSpace($entry[$field]) -or $entry[$field] -cne $entry[$field].Trim()) {
                throw ('Each manifest step and phase needs a non-blank {0} without surrounding whitespace.' -f $field)
            }
        }
        foreach ($field in @('enabled', 'isConditional')) {
            if ($entry.Contains($field) -and $entry[$field] -isnot [bool]) { throw ('Manifest {0} field {1} must be a JSON Boolean.' -f $entry.id, $field) }
        }
        foreach ($field in @('summary', 'notes', 'description')) {
            if ($entry.Contains($field) -and $entry[$field] -isnot [string]) { throw ('Manifest {0} field {1} must be text.' -f $entry.id, $field) }
        }
        foreach ($field in @('prerequisiteStepIds', 'requiredPermissions', 'graphEndpoints', 'actionNames', 'plannedGuidedActions')) {
            if (-not $entry.Contains($field)) { continue }
            if ($entry[$field] -isnot [array]) { throw ('Manifest {0} field {1} must be a JSON array.' -f $entry.id, $field) }
            foreach ($value in $entry[$field]) {
                if ($value -isnot [string] -or [string]::IsNullOrWhiteSpace($value) -or $value -cne $value.Trim()) {
                    throw ('Manifest {0} field {1} must contain non-blank text without surrounding whitespace.' -f $entry.id, $field)
                }
            }
        }
    }
    foreach ($step in $Manifest.steps) {
        if ($stepsById.ContainsKey($step.id)) { throw ('Manifest step ID {0} is duplicated.' -f $step.id) }
        if ($step.actionName -isnot [string] -or $step.actionName -notin $supportedActions) { throw ('Manifest step {0} has an unsupported actionName.' -f $step.id) }
        if ($actions.ContainsKey($step.actionName)) { throw ('Manifest action {0} is duplicated.' -f $step.actionName) }
        if ($step.prerequisiteStepIds -isnot [array]) { throw ('Manifest step {0} needs a prerequisiteStepIds array, including [] when empty.' -f $step.id) }
        if ($step.Contains('executionType') -and ($step.executionType -isnot [string] -or $step.executionType -notin @('graph', 'guided', 'hybrid', 'hybrid-selection'))) { throw ('Manifest step {0} has an unsupported executionType.' -f $step.id) }
        if ($step.Contains('activationRequirement') -and ($step.activationRequirement -isnot [string] -or $step.activationRequirement -notin @('None', 'RecoveryMode'))) { throw ('Manifest step {0} has an unsupported activationRequirement.' -f $step.id) }
        $stepsById[$step.id] = $step
        $actions[$step.actionName] = $true
        if (-not $step.Contains('enabled') -or $step.enabled) { $enabledCount++ }
    }
    if ($enabledCount -eq 0) { throw 'Manifest must contain at least one enabled step.' }
    foreach ($step in $Manifest.steps) {
        if ($step.Contains('enabled') -and -not $step.enabled) { continue }
        foreach ($prerequisiteId in $step.prerequisiteStepIds) {
            $prerequisite = $stepsById[$prerequisiteId]
            if ($null -ne $prerequisite -and $prerequisite.Contains('enabled') -and -not $prerequisite.enabled) {
                throw ('Enabled step {0} depends on disabled prerequisite {1}.' -f $step.id, $prerequisiteId)
            }
        }
    }
    $phaseIds = @{}
    foreach ($phase in $Manifest.workflowPhases) {
        if ($phaseIds.ContainsKey($phase.id)) { throw ('Manifest phase ID {0} is duplicated.' -f $phase.id) }
        $phaseIds[$phase.id] = $true
        if ($phase.actionNames -isnot [array] -or $phase.actionNames.Count -eq 0) { throw ('Manifest phase {0} needs a non-empty actionNames array.' -f $phase.id) }
        $phaseActions = @{}
        foreach ($actionName in $phase.actionNames) {
            if (-not $actions.ContainsKey($actionName)) { throw ('Workflow phase {0} references undefined action {1}.' -f $phase.id, $actionName) }
            if ($phaseActions.ContainsKey($actionName)) { throw ('Workflow phase {0} repeats action {1}.' -f $phase.id, $actionName) }
            $phaseActions[$actionName] = $true
        }
    }
    if ($Manifest.Contains('menuTitle') -and ($Manifest.menuTitle -isnot [string] -or [string]::IsNullOrWhiteSpace($Manifest.menuTitle))) { throw 'Manifest menuTitle must be non-blank text.' }
}

function Initialize-AutopilotExpressDefinitions {
    try {
        $runtimeConfig = Read-JsonDefinitionFile -Path (Get-RuntimeConfigFilePath) -Description 'Runtime configuration'
        $manifestConfig = Read-JsonDefinitionFile -Path (Get-ManifestFilePath) -Description 'Manifest'
    }
    catch {
        Write-AutopilotExpressLog -Message ('Failed to load Autopilot Express definitions: {0}' -f $_.Exception.Message) -Level 'ERROR'
        throw
    }

    Assert-ManifestDefinition -Manifest $manifestConfig

    $loadedSteps = @()
    foreach ($step in @($manifestConfig.steps)) {
        $loadedSteps += , ([ordered]@{
                Id                    = [string]$step.id
                DisplayName           = [string]$step.displayName
                Enabled               = if ($null -ne $step.enabled) { [bool]$step.enabled } else { $true }
                ActionName            = [string]$step.actionName
                PrerequisiteStepIds   = @($step.prerequisiteStepIds | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { [string]$_ })
                ActivationRequirement = if ($step.activationRequirement) { [string]$step.activationRequirement } else { 'None' }
                ExecutionType         = if ($step.executionType) { [string]$step.executionType } else { 'graph' }
                RequiredPermissions   = @($step.requiredPermissions)
                GraphEndpoints        = @($step.graphEndpoints)
                Summary               = if ($step.summary) { [string]$step.summary } else { '' }
                Notes                 = if ($step.notes) { [string]$step.notes } else { '' }
            })
    }

    Test-ManifestDependencyGraph -Steps @($loadedSteps)

    $loadedPhases = @()
    foreach ($phase in @($manifestConfig.workflowPhases)) {
        $phaseActionNames = @($phase.actionNames | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        $loadedPhases += , ([ordered]@{
                Id                   = [string]$phase.id
                DisplayName          = [string]$phase.displayName
                Description          = if ($phase.description) { [string]$phase.description } else { '' }
                ActionNames          = $phaseActionNames
                PlannedGuidedActions = @($phase.plannedGuidedActions)
                IsConditional        = if ($null -ne $phase.isConditional) { [bool]$phase.isConditional } else { $false }
            })
    }
    $Script:RuntimeConfig = $runtimeConfig
    if ($runtimeConfig.organisationName) { $Script:Config.OrganisationName = [string]$runtimeConfig.organisationName }
    $Script:StepManifest = @($loadedSteps)
    $Script:WorkflowPhases = @($loadedPhases)

    Write-AutopilotExpressLog -Message ('Loaded {0} manifest step(s), {1} workflow phase(s), and runtime settings from JSON definitions.' -f $Script:StepManifest.Count, $Script:WorkflowPhases.Count) -Level 'INFO'
}

function Test-IsPlaceholderConfigurationValue {
    param([AllowEmptyString()][string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) { return $true }
    return $Value -match '(?i)(example|placeholder|replace[-_ ]?me|^\s*<.+>\s*$)'
}

function Test-LiveRuntimeConfiguration {
    $issues = @()

    if (-not $Script:RuntimeConfig.graph) { $issues += 'Runtime configuration is missing the graph block.' }
    if (-not $Script:RuntimeConfig.autopilot) { $issues += 'Runtime configuration is missing the autopilot block.' }

    $configVersion = [string]$Script:RuntimeConfig.configVersion
    if ($configVersion -notmatch '^\d+\.\d+\.\d+$') {
        $issues += 'configVersion must use semantic version format, for example 1.0.0.'
    }
    $authMode = [string]$Script:RuntimeConfig.graph.authMode
    if ($authMode -ne 'Browser') {
        $issues += ('Only Browser auth mode is supported. Current value: {0}' -f $authMode)
    }
    $contextScope = [string]$Script:RuntimeConfig.graph.contextScope
    if ($contextScope -notin @('Process', 'CurrentUser')) {
        $issues += ('graph.contextScope must be Process or CurrentUser. Current value: {0}' -f $contextScope)
    }
    $configuredScopes = @($Script:RuntimeConfig.graph.requiredScopes | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    if ($configuredScopes.Count -eq 0) {
        $issues += 'At least one Microsoft Graph scope is required in graph settings.'
    }
    $configuredModules = @($Script:RuntimeConfig.graph.requiredModules | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    if ($configuredModules.Count -eq 0) {
        $issues += 'At least one Microsoft Graph module is required in graph settings.'
    }

    $configuredPrefixes = @($Script:RuntimeConfig.autopilot.technicianUpnPrefixes | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    if ($configuredPrefixes.Count -eq 0) {
        $issues += 'At least one technician UPN prefix is required in autopilot settings.'
    }
    foreach ($limitName in @('directorySearchLimit', 'recentUsersLimit')) {
        $rawLimitValue = [string]$Script:RuntimeConfig.autopilot[$limitName]
        if ($rawLimitValue -notmatch '^[1-9][0-9]*$') {
            $issues += ('autopilot.{0} must be a positive integer.' -f $limitName)
        }
    }

    return @($issues)
}

function Install-RequiredGraphModules {
    param([Parameter(Mandatory)][string[]]$RequiredModules)

    $missingModules = @($RequiredModules | Where-Object { -not (Get-Module -ListAvailable -Name $_) })
    if ($missingModules.Count -eq 0) { return $true }

    Write-Host ('Missing Microsoft Graph modules: {0}' -f ($missingModules -join ', '))
    $consent = Read-ValidatedInput -Prompt 'Install these modules for the current Windows user from PSGallery? (Y/N)' -Default 'N' -Type 'Choice' -Choices @('Y', 'N')
    if ($consent.ToUpper() -ne 'Y') {
        Write-AutopilotExpressLog -Message 'Required Microsoft Graph modules are not installed because installation was declined.' -Level 'WARN'
        return $false
    }

    foreach ($moduleName in $missingModules) {
        try {
            Write-AutopilotExpressLog -Message ('Installing Microsoft Graph module {0} for the current Windows user.' -f $moduleName) -Level 'INFO'
            Install-Module -Name $moduleName -Repository 'PSGallery' -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
        }
        catch {
            Write-AutopilotExpressLog -Message ('Failed to install Microsoft Graph module {0}: {1}' -f $moduleName, $_.Exception.Message) -Level 'ERROR'
            return $false
        }
    }
    return $true
}

function Get-GraphModuleImportPlan {
    <#
    .SYNOPSIS
        Select the newest installed common SDK version without changing modules.
    .PARAMETER RequiredModules
        Configured SDK module names; Authentication is always included first.
    .OUTPUTS
        Installed module metadata in import order. Conflicting loaded SDKs throw.
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification = 'Internal planner accepts the configured module collection.')]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string[]]$RequiredModules)
    $names = @('Microsoft.Graph.Authentication') + @($RequiredModules | Where-Object { $_ -ne 'Microsoft.Graph.Authentication' } | Sort-Object -Unique)
    $available = @(Get-Module -ListAvailable -Name $names)
    $versions = @($available | Where-Object { $_.Name -eq 'Microsoft.Graph.Authentication' } | ForEach-Object { $_.Version } | Sort-Object -Unique -Descending)
    $plan = @()
    foreach ($version in $versions) {
        $candidate = @()
        foreach ($name in $names) {
            $module = $available | Where-Object { $_.Name -eq $name -and $_.Version -eq $version } | Sort-Object Path | Select-Object -First 1
            if ($null -eq $module) { break }
            $candidate += $module
        }
        if ($candidate.Count -eq $names.Count) { $plan = $candidate; break }
    }
    if ($plan.Count -ne $names.Count) { throw 'No common installed Graph SDK version is available for the configured modules. Review module versions; nothing was imported.' }
    foreach ($loaded in @(Get-Module -Name 'Microsoft.Graph.*')) {
        if ($loaded.Version -ne $plan[0].Version) { throw 'A conflicting Graph SDK version is already loaded. Start a fresh PowerShell process before using Live mode.' }
        $selected = $plan | Where-Object { $_.Name -eq $loaded.Name } | Select-Object -First 1
        if ($null -ne $selected -and $loaded.ModuleBase -ine $selected.ModuleBase) { throw 'A configured Graph module is loaded from a different installation. Start a fresh PowerShell process.' }
    }
    return , $plan
}

function Import-RequiredGraphModules {
    $requiredModules = Get-ConfiguredGraphModules
    if (-not (Install-RequiredGraphModules -RequiredModules $requiredModules)) { return $false }

    try { $plan = Get-GraphModuleImportPlan -RequiredModules $requiredModules }
    catch {
        Write-AutopilotExpressLog -Message $_.Exception.Message -Level 'ERROR'
        return $false
    }
    foreach ($module in $plan) {
        try {
            Import-Module -Name $module.Path -ErrorAction Stop | Out-Null
        }
        catch {
            Write-AutopilotExpressLog -Message ('Failed to import Microsoft Graph module {0}: {1}' -f $module.Name, $_.Exception.Message) -Level 'ERROR'
            return $false
        }
    }
    try { [void](Get-GraphModuleImportPlan -RequiredModules $requiredModules) }
    catch {
        Write-AutopilotExpressLog -Message $_.Exception.Message -Level 'ERROR'
        return $false
    }
    return $true
}

function Get-GraphTransportPolicy {
    <#
    .SYNOPSIS
        Validates the bounded HTTP policy independently of state-verification polling.
    .OUTPUTS
        Dictionary containing attempt, backoff, maximum-wait and per-request timeout limits.
    #>
    $policy = @{}
    foreach ($setting in @(
            @{ Name = 'TransportMaxAttempts'; Default = 3; Minimum = 1; Maximum = 5 }
            @{ Name = 'TransportBackoffSeconds'; Default = 3; Minimum = 0; Maximum = 60 }
            @{ Name = 'TransportMaxDelaySeconds'; Default = 60; Minimum = 1; Maximum = 300 }
            @{ Name = 'TransportTimeoutSeconds'; Default = 60; Minimum = 1; Maximum = 300 }
        )) {
        $value = $Script:Config[$setting.Name]
        if ($null -eq $value) { $value = $setting.Default }
        if ([string]$value -notmatch '^[0-9]+$' -or [double]$value -lt $setting.Minimum -or [double]$value -gt $setting.Maximum) {
            throw ('{0} must be an integer from {1} to {2}.' -f $setting.Name, $setting.Minimum, $setting.Maximum)
        }
        $policy[$setting.Name] = [int]$value
    }
    if ($policy.TransportBackoffSeconds -gt $policy.TransportMaxDelaySeconds) {
        throw 'TransportBackoffSeconds must not exceed TransportMaxDelaySeconds.'
    }
    return $policy
}

function Initialize-GraphTransport {
    <#
    .SYNOPSIS
        Disables hidden SDK retries and applies the HTTP timeout before any Graph operation.
    .DESCRIPTION
        Uses the installed SDK request context, including generated mutation commands.
        Unsupported SDK versions fail closed instead of using uncontrolled replay behaviour.
    #>
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Policy)

    $contextCommand = Get-Command -Name Set-MgRequestContext -ErrorAction Stop
    if ($contextCommand.Parameters.Keys -notcontains 'MaxRetry' -or $contextCommand.Parameters.Keys -notcontains 'ClientTimeout') {
        throw 'The Graph SDK must support Set-MgRequestContext -MaxRetry and -ClientTimeout.'
    }
    Set-MgRequestContext -MaxRetry 0 -ClientTimeout $Policy.TransportTimeoutSeconds -ErrorAction Stop | Out-Null
}

function Get-GraphTransportFailure {
    <#
    .SYNOPSIS
        Reads structured status and safe retry/correlation headers without inspecting error text.
    .PARAMETER RequestError
        The terminating SDK ErrorRecord from a failed request.
    .OUTPUTS
        Dictionary of HTTP status, Retry-After text and validated request identifier.
    #>
    param([Parameter(Mandatory)]$RequestError)

    $exception = $RequestError.Exception
    $status = $exception.ResponseStatusCode
    if ($null -eq $status) { $status = $exception.Response.StatusCode }
    $statusText = [string]$status
    if ($statusText -eq 'TooManyRequests') { $statusText = '429' }
    if ($statusText -eq 'ServiceUnavailable') { $statusText = '503' }
    if ($statusText -eq 'GatewayTimeout') { $statusText = '504' }
    $headers = $exception.ResponseHeaders
    if ($null -eq $headers) { $headers = $exception.Response.Headers }
    $retryAfter = $null
    $requestId = ''
    if ($headers -is [System.Collections.IDictionary]) {
        foreach ($key in $headers.Keys) {
            if ([string]$key -ieq 'Retry-After') { $retryAfter = [string]@($headers[$key])[0] }
            if ([string]$key -ieq 'request-id') { $requestId = [string]@($headers[$key])[0] }
        }
    }
    else {
        foreach ($header in $headers) {
            if ([string]$header.Key -ieq 'Retry-After') { $retryAfter = [string]@($header.Value)[0] }
            if ([string]$header.Key -ieq 'request-id') { $requestId = [string]@($header.Value)[0] }
        }
    }
    if ($requestId -notmatch '^[A-Za-z0-9-]{1,80}$') { $requestId = 'unavailable' }
    return @{ Status = $statusText; RetryAfter = $retryAfter; RequestId = $requestId }
}

function Invoke-GraphApiRequest {
    <#
    .SYNOPSIS
        Sends a Graph request with bounded transient GET retries and no mutation replay.
    .DESCRIPTION
        Retries GET only on structured 429/503/504 status. Retry-After takes precedence
        over exponential backoff. Excessive or malformed server waits fail closed.
        Authentication, permissions, unknown transport errors and all writes fail immediately.
    .OUTPUTS
        The original SDK response, or the original terminating request error.
    #>
    param(
        [Parameter(Mandatory)][ValidateSet('GET', 'POST', 'DELETE')][string]$Method,
        [Parameter(Mandatory)][string]$Uri,
        $Body,
        [hashtable]$Headers
    )

    if (-not $Script:GraphSession.Connected) { throw 'Microsoft Graph session is not connected.' }
    if ($Script:GraphSession.IsSimulated) { throw 'Demo mode must not issue Microsoft Graph requests.' }
    $graphUri = $null
    if (-not [uri]::TryCreate($Uri, [UriKind]::Absolute, [ref]$graphUri) -or
        $graphUri.Scheme -ne 'https' -or $graphUri.Host -ne 'graph.microsoft.com' -or
        $graphUri.Port -ne 443 -or $graphUri.UserInfo -or $graphUri.Fragment -or
        $graphUri.AbsolutePath.StartsWith('//')) {
        throw 'Requests require an absolute HTTPS public Graph URI without user information, fragments or alternate ports.'
    }
    $policy = Get-GraphTransportPolicy
    Initialize-GraphTransport -Policy $policy

    $invokeParameters = @{ Method = $Method; Uri = $graphUri.PathAndQuery; ErrorAction = 'Stop' }
    if ($Headers -and $Headers.Count -gt 0) { $invokeParameters.Headers = $Headers }
    if ($null -ne $Body) {
        $invokeParameters.Body = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 8 }
        $invokeParameters.ContentType = 'application/json'
    }

    for ($attempt = 1; $attempt -le $policy.TransportMaxAttempts; $attempt++) {
        try { return Invoke-MgGraphRequest @invokeParameters }
        catch {
            $failure = Get-GraphTransportFailure -RequestError $_
            if ($Method -ne 'GET' -or $failure.Status -notin @('429', '503', '504') -or $attempt -eq $policy.TransportMaxAttempts) {
                $reportedStatus = if ($failure.Status) { [string]$failure.Status } else { 'unavailable' }
                Write-AutopilotExpressLog -Message ('Graph {0} failed: HTTP={1}; attempt={2}; request-id={3}. No automatic replay. Exception={4}.' -f $Method, $reportedStatus, $attempt, $failure.RequestId, $_.Exception.GetType().FullName) -Level 'WARN'
                throw
            }
            $delay = $policy.TransportBackoffSeconds
            for ($backoffIndex = 1; $backoffIndex -lt $attempt; $backoffIndex++) { $delay *= 2 }
            if ($delay -gt $policy.TransportMaxDelaySeconds) { $delay = $policy.TransportMaxDelaySeconds }
            if ($null -ne $failure.RetryAfter) {
                if ($failure.RetryAfter -match '^[0-9]+$') { $delay = [double]$failure.RetryAfter }
                elseif ($failure.RetryAfter -match '^[A-Za-z]{3}, [0-9]{2} [A-Za-z]{3} [0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2} GMT$') {
                    try { $retryDate = Get-Date -Date $failure.RetryAfter -ErrorAction Stop }
                    catch { throw 'Graph returned an invalid HTTP-date Retry-After header; no retry was issued.' }
                    $delay = ($retryDate - (Get-Date)).TotalSeconds
                    if ($delay -lt 0) { $delay = 0 }
                    $wholeSeconds = [int]$delay
                    if ($wholeSeconds -lt $delay) { $wholeSeconds++ }
                    $delay = $wholeSeconds
                }
                else { throw 'Graph returned an invalid Retry-After header; no retry was issued.' }
            }
            if ($delay -gt $policy.TransportMaxDelaySeconds) {
                Write-AutopilotExpressLog -Message ('Graph GET retry deferred: requested wait exceeds {0}s; request-id={1}. Return later.' -f $policy.TransportMaxDelaySeconds, $failure.RequestId) -Level 'WARN'
                throw
            }
            Write-AutopilotExpressLog -Message ('Graph GET retry: HTTP={0}; attempt={1}/{2}; wait={3}s; request-id={4}.' -f $failure.Status, $attempt, $policy.TransportMaxAttempts, $delay, $failure.RequestId) -Level 'WARN'
            if ($delay -gt 0) { Start-Sleep -Seconds ([int]$delay) }
        }
    }
}

function Get-GraphDiscoveryCollection {
    <#
    .SYNOPSIS
        Read complete, bounded Graph discovery pages without returning partial data.
    .PARAMETER Uri
        Initial Microsoft Graph collection URI. Continuations must retain its path.
    .PARAMETER RequiredTextProperty
        Required identity field: displayName for discovery, serialNumber for
        Autopilot, or id for limited-information direct membership responses.
    .OUTPUTS
        Complete array of validated identities; no partial results on failure.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Uri,
        [ValidateSet('displayName', 'serialNumber', 'id')][string]$RequiredTextProperty = 'displayName'
    )
    $initialUri = [uri]$Uri
    $currentUri = $Uri
    $visited = @()
    $items = @()
    $seenIds = @{}
    while ($currentUri) {
        $pageUri = [uri]$currentUri
        if ($pageUri.Scheme -ne 'https' -or $pageUri.Host -ne 'graph.microsoft.com' -or $pageUri.Port -ne 443 -or
            $pageUri.UserInfo -or $pageUri.Fragment -or $pageUri.AbsolutePath -cne $initialUri.AbsolutePath) { throw 'Unsafe Graph discovery continuation URI.' }
        if ($currentUri -in $visited -or $visited.Count -ge 20) { throw 'Graph discovery is incomplete: repeated page or 20-page limit reached.' }
        $visited += $currentUri
        $response = Invoke-GraphApiRequest -Method GET -Uri $currentUri
        if ($null -eq $response -or $response.value -isnot [array]) { throw 'Graph discovery returned a malformed collection.' }
        foreach ($item in $response.value) {
            if ($item.id -isnot [string] -or [string]::IsNullOrWhiteSpace($item.id) -or $item.$RequiredTextProperty -isnot [string] -or [string]::IsNullOrWhiteSpace($item.$RequiredTextProperty)) { throw 'Graph discovery returned an invalid identity (missing or unexpected identity fields).' }
            if ($seenIds.ContainsKey($item.id)) { throw 'Graph discovery returned a repeated identity.' }
            $seenIds[$item.id] = $true
            $items += , $item
        }
        $nextLink = $response.'@odata.nextLink'
        if ($null -ne $nextLink -and ($nextLink -isnot [string] -or [string]::IsNullOrWhiteSpace($nextLink))) { throw 'Graph discovery returned an invalid continuation.' }
        $currentUri = $nextLink
    }
    return , $items
}

function Initialize-LiveTenantContext {
    $tenantId = Get-LiveTenantBinding
    $organisations = Get-GraphDiscoveryCollection -Uri 'https://graph.microsoft.com/v1.0/organization?$select=id,displayName'
    if ($organisations.Count -ne 1 -or $organisations[0].id -ine $tenantId) { throw 'Organisation discovery must return exactly one identity matching the authenticated TenantId.' }
    $Script:RuntimeConfig.organisationName = [string]$organisations[0].displayName
    $Script:Config.OrganisationName = [string]$organisations[0].displayName
    Write-AutopilotExpressLog -Message ('Resolved tenant organisation: {0}.' -f $Script:Config.OrganisationName) -Level 'INFO'

    $configuredProfileName = [string]$Script:RuntimeConfig.autopilot.deploymentProfileDisplayName
    if (Test-IsPlaceholderConfigurationValue -Value $configuredProfileName) {
        $profileItems = Get-GraphDiscoveryCollection -Uri 'https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeploymentProfiles?$select=id,displayName'
        $profiles = @($profileItems | Sort-Object displayName)
        if ($profiles.Count -eq 0) { throw 'No Windows Autopilot deployment profiles were returned by the tenant.' }

        Write-Host 'Select Autopilot deployment profile:'
        for ($index = 0; $index -lt $profiles.Count; $index++) {
            Write-Host ('{0}. {1}' -f ($index + 1), $profiles[$index].displayName)
        }
        $profileChoice = Read-ValidatedInput -Prompt 'Choose deployment profile number' -Default '1' -Type 'Int'
        $profileIndex = (ConvertTo-OptionalInteger -Value $profileChoice) - 1
        if ($profileIndex -lt 0 -or $profileIndex -ge $profiles.Count) { throw 'The selected deployment profile number is invalid.' }
        $Script:RuntimeConfig.autopilot.deploymentProfileDisplayName = [string]$profiles[$profileIndex].displayName
        Write-AutopilotExpressLog -Message ('Selected tenant Autopilot deployment profile: {0}.' -f $Script:RuntimeConfig.autopilot.deploymentProfileDisplayName) -Level 'INFO'
    }

    $configuredGroupName = [string]$Script:RuntimeConfig.autopilot.preProvisioningGroupDisplayName
    while (Test-IsPlaceholderConfigurationValue -Value $configuredGroupName) {
        $configuredGroupName = Read-ValidatedInput -Prompt 'Enter the pre-provisioning group display name'
        $Script:RuntimeConfig.autopilot.preProvisioningGroupDisplayName = $configuredGroupName
        try {
            $group = Get-LivePreProvisioningGroup
            Write-AutopilotExpressLog -Message ('Resolved pre-provisioning group: {0} ({1}).' -f $group.displayName, $group.id) -Level 'INFO'
        }
        catch {
            Write-Host ('The specified pre-provisioning group could not be uniquely resolved: {0}' -f $_.Exception.Message)
            $configuredGroupName = ''
            $Script:RuntimeConfig.autopilot.preProvisioningGroupDisplayName = ''
        }
    }
}

function Test-GraphCapabilities {
    $results = @()
    $readChecks = @(
        @{ Name = 'Autopilot identity read'; Uri = 'https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities?$top=1' },
        @{ Name = 'Managed-device read'; Uri = 'https://graph.microsoft.com/v1.0/deviceManagement/managedDevices?$top=1&$select=id' },
        @{ Name = 'Entra device read'; Uri = 'https://graph.microsoft.com/v1.0/devices?$top=1&$select=id' },
        @{ Name = 'Directory user read'; Uri = 'https://graph.microsoft.com/v1.0/users?$top=1&$select=id' }
    )

    foreach ($check in $readChecks) {
        try {
            Invoke-GraphApiRequest -Method 'GET' -Uri $check.Uri | Out-Null
            $results += [ordered]@{ Name = $check.Name; Success = $true; Detail = 'Read access confirmed.' }
        }
        catch {
            $results += [ordered]@{ Name = $check.Name; Success = $false; Detail = $_.Exception.Message }
        }
    }

    try {
        $group = Get-LivePreProvisioningGroup
        $results += [ordered]@{ Name = 'Pre-provisioning group read'; Success = $true; Detail = ('Resolved group {0} ({1}).' -f $group.displayName, $group.id) }
    }
    catch {
        $results += [ordered]@{ Name = 'Pre-provisioning group read'; Success = $false; Detail = $_.Exception.Message }
    }

    return @($results)
}

function Initialize-GraphSession {
    if ($Script:Runtime.IsDemoMode) {
        $demoUpn = if ($Script:RuntimeConfig.demo.technicianUserPrincipalName) { [string]$Script:RuntimeConfig.demo.technicianUserPrincipalName } else { 'c.demo.tech@examplehealth.network' }
        $demoDisplayName = if ($Script:RuntimeConfig.demo.technicianDisplayName) { [string]$Script:RuntimeConfig.demo.technicianDisplayName } else { 'Demo Technician' }
        $Script:GraphSession = [ordered]@{
            Connected         = $true
            IsSimulated       = $true
            Account           = $demoUpn
            DisplayName       = $demoDisplayName
            UserId            = [guid]::NewGuid().Guid
            TenantId          = ''
            Scopes            = @()
            CapabilityResults = @([ordered]@{ Name = 'Demo simulation'; Success = $true; Detail = 'Graph capability preflight is simulated in Demo mode.' })
        }
        Write-AutopilotExpressLog -Message ('Demo mode: simulated browser login completed for {0}.' -f $demoUpn) -Level 'INFO'
        return $true
    }

    $Script:GraphSession = Get-EmptyGraphSession
    $configIssues = Test-LiveRuntimeConfiguration
    if ($configIssues.Count -gt 0) {
        foreach ($issue in $configIssues) {
            Write-AutopilotExpressLog -Message $issue -Level 'ERROR'
        }
        return $false
    }

    if (-not (Import-RequiredGraphModules)) { return $false }

    $startupStage = 'Transport configuration'
    try {
        Initialize-GraphTransport -Policy (Get-GraphTransportPolicy)
        $expectedTenantId = $Script:RuntimeConfig.graph.expectedTenantId
        if ($null -ne $expectedTenantId -and ($expectedTenantId -isnot [string] -or
                ($expectedTenantId -cne '' -and $expectedTenantId -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'))) {
            throw 'Configured expectedTenantId must be empty or a tenant GUID string.'
        }
        $connectParameters = @{ Scopes = (Get-ConfiguredGraphScopes); ContextScope = ([string]$Script:RuntimeConfig.graph.contextScope); NoWelcome = $true; ErrorAction = 'Stop' }
        if ($expectedTenantId) { $connectParameters.TenantId = $expectedTenantId }
        $startupStage = 'Browser sign-in'
        Write-AutopilotExpressLog -Message 'Opening browser-based Microsoft Graph sign-in...' -Level 'INFO'
        Connect-MgGraph @connectParameters | Out-Null
        $startupStage = 'Authenticated context validation'
        $context = Get-MgContext -ErrorAction Stop
        if ($context.TenantId -isnot [string] -or $context.TenantId -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') { throw 'Authenticated Graph context TenantId must be a GUID string.' }
        if ($expectedTenantId -and $context.TenantId -ine $expectedTenantId) { throw 'Authenticated tenant does not match configured expectedTenantId. No tenant reads were issued.' }
        # The guarded request helper depends on GraphSession.Connected, which is only set after this identity probe succeeds.
        $startupStage = 'Signed-in identity read (GET /v1.0/me)'
        Write-AutopilotExpressLog -Message 'Browser sign-in returned a valid tenant context; checking signed-in identity.' -Level 'INFO'
        $me = Invoke-MgGraphRequest -Method 'GET' -Uri '/v1.0/me?$select=id,displayName,userPrincipalName,mail' -ErrorAction Stop
        $graphAccount = if ($me.userPrincipalName) { [string]$me.userPrincipalName } else { [string]$context.Account }
        $Script:GraphSession = [ordered]@{
            Connected         = $true
            IsSimulated       = $false
            Account           = $graphAccount
            DisplayName       = if ($me.displayName) { [string]$me.displayName } else { $graphAccount }
            UserId            = if ($me.id) { [string]$me.id } else { '' }
            TenantId          = $context.TenantId
            Scopes            = @()
            CapabilityResults = @()
        }
        $startupStage = 'Organisation discovery and tenant binding'
        Initialize-LiveTenantContext
        $startupStage = 'Graph read capability preflight'
        $capabilityResults = @(Test-GraphCapabilities)
        $Script:GraphSession.CapabilityResults = $capabilityResults
        $failedCapabilities = @($capabilityResults | Where-Object { -not $_.Success })
        if ($failedCapabilities.Count -gt 0) {
            foreach ($failure in $failedCapabilities) {
                Write-AutopilotExpressLog -Message ('Microsoft Graph capability check failed for {0}: {1}' -f $failure.Name, $failure.Detail) -Level 'ERROR'
            }
            Close-GraphSession
            return $false
        }
        Write-AutopilotExpressLog -Message ('Authenticated to Microsoft Graph as {0}.' -f $Script:GraphSession.Account) -Level 'INFO'
        Write-AutopilotExpressLog -Message 'Microsoft Graph read capability preflight completed successfully.' -Level 'INFO'
        return $true
    }
    catch {
        $startupError = $_
        $errorType = $startupError.Exception.GetType().FullName
        $httpStatus = 'unavailable'
        $requestId = 'unavailable'
        if (Get-Command Get-GraphTransportFailure -ErrorAction SilentlyContinue) {
            $transportFailure = Get-GraphTransportFailure -RequestError $startupError
            if ($transportFailure.Status) { $httpStatus = [string]$transportFailure.Status }
            if ($transportFailure.RequestId) { $requestId = [string]$transportFailure.RequestId }
        }
        Write-AutopilotExpressLog -Message ('Live startup failed at stage: {0}. Exception={1}; HTTP={2}; request-id={3}.' -f $startupStage, $errorType, $httpStatus, $requestId) -Level 'ERROR'
        $sdkVersions = @(Get-Module Microsoft.Graph* | ForEach-Object { '{0}={1}' -f $_.Name, $_.Version }) -join '; '
        Write-AutopilotExpressLog -Message ('Host={0}; edition={1}; language={2}; loaded Graph modules: {3}' -f $PSVersionTable.PSVersion, $PSVersionTable.PSEdition, $ExecutionContext.SessionState.LanguageMode, $sdkVersions) -Level 'ERROR'
        $innerError = $startupError.Exception
        $uriFailure = $false
        for ($depth = 0; $depth -lt 5 -and $innerError; $depth++) {
            if ($innerError -is [System.UriFormatException] -or $innerError.Message -like '*Invalid URI*') { $uriFailure = $true }
            Write-Verbose ('Startup exception[{0}]: {1}' -f $depth, $innerError.GetType().FullName)
            $innerError = $innerError.InnerException
        }
        if ($uriFailure) {
            Write-Host ('URI construction failed in the client/request path. Reported HTTP status: {0}; this is not evidence of missing Intune licences or insufficient permissions.' -f $httpStatus)
            Write-Host 'Close this PowerShell process and retry the current script in a fresh non-elevated PowerShell 7 session. Do not broaden permissions or reinstall modules solely because of this error.'
            Write-Host 'If it repeats, provide the stage, host and loaded module versions above, plus the script revision. Use -Verbose for exception type-chain diagnostics; never include tokens or SDK response bodies.'
        }
        elseif ($httpStatus -eq '401') { Write-Host 'Graph reported HTTP 401. Check the signed-in tenant/account and reconnect in a fresh session; ask your administrator to review sign-in policy if it repeats.' }
        elseif ($httpStatus -eq '403') { Write-Host 'Graph reported HTTP 403. Ask the tenant administrator to check consent, delegated scopes and operator roles for the failing read. Successful browser sign-in does not grant API access.' }
        else { Write-Host 'Inspect the failing stage and HTTP/request ID above. Browser sign-in, identity lookup, organisation discovery and Intune read access are separate checks; do not assume all failures are authentication failures.' }
        if (-not $Script:GraphSession.Connected) {
            try { Disconnect-MgGraph -ErrorAction Stop | Out-Null } catch { Write-Verbose 'Graph disconnect failed after unsuccessful authentication.' }
        }
        Close-GraphSession
        Write-AutopilotExpressLog -Message 'Live startup stopped; no workflow action was run. See README.md, Troubleshooting / Live Startup Failures.' -Level 'ERROR'
        return $false
    }
}

function Close-GraphSession {
    if (-not $Script:Runtime.IsDemoMode -and $Script:GraphSession.Connected) {
        try { Disconnect-MgGraph -ErrorAction Stop | Out-Null } catch { Write-Verbose 'Graph disconnect failed; local session state will still be cleared. No SDK error body is logged.' }
    }
    $Script:GraphSession = Get-EmptyGraphSession
}

function New-OperationResult {
    <#
    .SYNOPSIS
        Build an honest outcome; Live request acceptance alone is Submitted.
    .DESCRIPTION
        Explicit Verified claims require successful action-specific observations.
        The persistence boundary repeats this check before storing completion.
        Guided technician observations and Demo simulation remain distinct states.
    .PARAMETER ActionName
        Manifest semantic action used to select the required evidence contract.
    .PARAMETER Data
        Target identities, expected/observed values and completed read attempts.
    .OUTPUTS
        Operation dictionary; inconsistent verification becomes non-completing Submitted.
    #>
    param(
        [Parameter(Mandatory)][string]$ActionName,
        [Parameter(Mandatory)][bool]$Success,
        [string]$Summary,
        [string]$Notes,
        [hashtable]$Data,
        [ValidateSet('Verified', 'TechnicianConfirmed', 'Submitted', 'Blocked', 'Failed', 'AuditedException', 'Simulated', 'LegacyCompleted')][string]$CompletionState
    )
    if ([string]::IsNullOrWhiteSpace($CompletionState)) {
        $CompletionState = if (-not $Success) { 'Failed' } elseif ($Script:Runtime.IsDemoMode) { 'Simulated' } else { 'Submitted' }
    }
    if (-not $Script:Runtime.IsDemoMode -and $CompletionState -eq 'Verified') {
        $hasEvidence = $false
        if ($Success -and $Data) {
            switch ($ActionName) {
                'ResolveAutopilotDevice' { $hasEvidence = $Data.VerificationAttempts -gt 0 -and $Data.AutopilotDeviceId -is [string] -and -not [string]::IsNullOrWhiteSpace($Data.AutopilotDeviceId) -and $Data.Serial -is [string] -and -not [string]::IsNullOrWhiteSpace($Data.Serial) -and $Data.ObservedSerial -is [string] -and $Data.ObservedSerial -ieq $Data.Serial }
                'RemoveAssociatedManagedDevice' { $hasEvidence = $Data.VerificationAttempts -gt 0 -and $Data.ContainsKey('ObservedManagedDeviceId') -and $Data.ObservedManagedDeviceId -ceq '' }
                'ApplyGroupTag' { $hasEvidence = $Data.VerificationAttempts -gt 0 -and $Data.AutopilotDeviceId -is [string] -and -not [string]::IsNullOrWhiteSpace($Data.AutopilotDeviceId) -and $Data.GroupTag -is [string] -and -not [string]::IsNullOrWhiteSpace($Data.GroupTag) -and $Data.ObservedGroupTag -ceq $Data.GroupTag }
                'AddToPreProvisioningGroup' { $hasEvidence = $Data.VerificationAttempts -gt 0 -and $Data.ExpectedMember -is [bool] -and $Data.ExpectedMember -and $Data.ObservedMember -is [bool] -and $Data.ObservedMember -and -not [string]::IsNullOrWhiteSpace($Data.GroupId) -and -not [string]::IsNullOrWhiteSpace($Data.DirectoryObjectId) }
                'RemoveFromPreProvisioningGroup' { $hasEvidence = $Data.VerificationAttempts -gt 0 -and $Data.ExpectedMember -is [bool] -and -not $Data.ExpectedMember -and $Data.ObservedMember -is [bool] -and -not $Data.ObservedMember -and -not [string]::IsNullOrWhiteSpace($Data.GroupId) -and -not [string]::IsNullOrWhiteSpace($Data.DirectoryObjectId) }
                { $_ -in @('AssignTechnicianPrimaryUser', 'AssignFinalPrimaryUser') } { $hasEvidence = $Data.AutopilotAssigned -is [bool] -and $Data.AutopilotAssigned -and $Data.ManagedDeviceConfirmed -is [bool] -and $Data.ManagedDeviceConfirmed }
            }
        }
        if (-not $hasEvidence) {
            $CompletionState = 'Submitted'
            $Success = $false
            $Notes = ('{0} Explicit Graph verification evidence is missing or inconsistent; completion refused.' -f $Notes).Trim()
        }
    }
    return [ordered]@{
        ActionName      = $ActionName
        Success         = $Success
        CompletionState = $CompletionState
        Summary         = if ($Summary) { $Summary } else { '' }
        Notes           = if ($Notes) { $Notes } else { '' }
        Data            = if ($Data) { $Data } else { @{} }
        IsSimulated     = $Script:Runtime.IsDemoMode
    }
}

function Get-UserLocalPart {
    param([string]$UserPrincipalName)
    if ([string]::IsNullOrWhiteSpace($UserPrincipalName)) { return '' }
    $normalisedUserPrincipalName = $UserPrincipalName.Trim().ToLower()
    if ($normalisedUserPrincipalName.Contains('@')) { return $normalisedUserPrincipalName.Split('@')[0] }
    return $normalisedUserPrincipalName
}

function Test-DirectoryUserMatchesConfiguredPrefixes {
    param([string]$UserPrincipalName)
    $localPart = Get-UserLocalPart -UserPrincipalName $UserPrincipalName
    if ([string]::IsNullOrWhiteSpace($localPart)) { return $false }
    foreach ($configuredPrefix in (Get-ConfiguredTechnicianPrefixes)) {
        if ($localPart.StartsWith($configuredPrefix.ToLower())) { return $true }
    }
    return $false
}

function Get-DirectoryUserEligibilityMessage {
    param($User)
    if ($null -eq $User) { return 'No directory user was supplied.' }
    if ([string]::IsNullOrWhiteSpace([string]$User.UserPrincipalName)) { return 'The selected user does not have a user principal name.' }

    if ($null -ne $User.AccountEnabled -and -not [bool]$User.AccountEnabled) {
        return ('{0} is not an active account.' -f $User.UserPrincipalName)
    }

    if (-not (Test-DirectoryUserMatchesConfiguredPrefixes -UserPrincipalName $User.UserPrincipalName)) {
        return ('{0} does not begin with one of the permitted prefixes: {1}.' -f $User.UserPrincipalName, ((Get-ConfiguredTechnicianPrefixes) -join ', '))
    }

    return ''
}

function Test-EligibleDirectoryUser {
    param($User)
    return [string]::IsNullOrWhiteSpace((Get-DirectoryUserEligibilityMessage -User $User))
}

function Get-EligibleDirectoryUsers {
    param([AllowEmptyCollection()][System.Collections.IEnumerable]$Users)
    return @($Users | Where-Object { $null -ne $_ -and (Test-EligibleDirectoryUser -User $_) } | Sort-Object { $_.DisplayName }, { $_.UserPrincipalName })
}

function Resolve-LiveDirectoryUserRecord {
    param($User)
    if ($null -eq $User) { return $null }

    try {
        if ($User.Id) {
            $resolvedUser = Invoke-GraphApiRequest -Method 'GET' -Uri ('https://graph.microsoft.com/v1.0/users/{0}?$select=id,displayName,userPrincipalName,accountEnabled' -f $User.Id)
            return ConvertTo-DirectoryUserRecord -User $resolvedUser
        }

        if ($User.UserPrincipalName) {
            $escapedUserPrincipalName = ([string]$User.UserPrincipalName).Replace("'", "''")
            $response = Invoke-GraphApiRequest -Method 'GET' -Uri ('https://graph.microsoft.com/v1.0/users?$filter=userPrincipalName eq ''{0}''&$select=id,displayName,userPrincipalName,accountEnabled&$top=1' -f $escapedUserPrincipalName)
            return @($response.value | ForEach-Object { ConvertTo-DirectoryUserRecord -User $_ }) | Where-Object { $null -ne $_ } | Select-Object -First 1
        }
    }
    catch {
        $userIdentity = if ($User.UserPrincipalName) { [string]$User.UserPrincipalName } elseif ($User.Id) { [string]$User.Id } else { 'unknown user' }
        Write-AutopilotExpressLog -Message ('Failed to revalidate directory user {0}: {1}' -f $userIdentity, $_.Exception.Message) -Level 'WARN'
    }

    return $null
}

function Resolve-EligibleDirectoryUser {
    param($User)
    if ($null -eq $User) { return $null }

    $candidateUser = if ($Script:Runtime.IsDemoMode) { $User } else { Resolve-LiveDirectoryUserRecord -User $User }
    if ($null -eq $candidateUser) {
        Write-Host 'The selected directory user could not be revalidated.'
        return $null
    }

    $eligibilityMessage = Get-DirectoryUserEligibilityMessage -User $candidateUser
    if (-not [string]::IsNullOrWhiteSpace($eligibilityMessage)) {
        Write-Host $eligibilityMessage
        return $null
    }

    return $candidateUser
}

function Get-RecentUsers {
    $recentUsersPath = Get-RecentUsersFilePath
    $recentUsers = @()

    if (Test-Path $recentUsersPath) {
        try {
            $storedUsers = Get-Content -Raw -Path $recentUsersPath | ConvertFrom-Json
            foreach ($storedUser in @($storedUsers)) {
                if ($null -eq $storedUser) { continue }
                $recentUsers += [ordered]@{
                    Id                = if ($storedUser.id) { [string]$storedUser.id } elseif ($storedUser.Id) { [string]$storedUser.Id } else { '' }
                    DisplayName       = if ($storedUser.displayName) { [string]$storedUser.displayName } elseif ($storedUser.DisplayName) { [string]$storedUser.DisplayName } else { '' }
                    UserPrincipalName = if ($storedUser.userPrincipalName) { [string]$storedUser.userPrincipalName } elseif ($storedUser.UserPrincipalName) { [string]$storedUser.UserPrincipalName } else { '' }
                    AccountEnabled    = if ($null -ne $storedUser.accountEnabled) { [bool]$storedUser.accountEnabled } elseif ($null -ne $storedUser.AccountEnabled) { [bool]$storedUser.AccountEnabled } else { $true }
                }
            }
        }
        catch {
            Write-AutopilotExpressLog -Message ('Failed to load recent users file: {0}' -f $_.Exception.Message) -Level 'WARN'
        }
    }

    if ($recentUsers.Count -eq 0 -and $Script:Runtime.IsDemoMode) {
        foreach ($demoUser in @($Script:RuntimeConfig.demo.defaultUsers)) {
            if ($null -eq $demoUser) { continue }
            $userRecord = ConvertTo-DirectoryUserRecord -User $demoUser
            if ($null -ne $userRecord) { $recentUsers += $userRecord }
        }
    }

    $eligibleRecentUsers = @(Get-EligibleDirectoryUsers -Users (@($recentUsers | Where-Object { $_.UserPrincipalName } | Select-Object -First (Get-ConfiguredRecentUserLimit))))
    return , $eligibleRecentUsers
}

function Save-RecentUsers {
    param([AllowEmptyCollection()][System.Collections.IEnumerable]$Users)
    $recentUsersPath = Get-RecentUsersFilePath
    $serialisableUsers = @($Users | ForEach-Object { ConvertTo-DirectoryUserRecord -User $_ } | Where-Object { $null -ne $_ })
    $json = if ($serialisableUsers.Count -gt 0) { ConvertTo-Json -InputObject $serialisableUsers -Depth 5 } else { '[]' }
    Write-Utf8File -Path $recentUsersPath -Content $json
}

function Add-RecentUser {
    param([Parameter(Mandatory)]$User)
    $allUsers = @()
    $allUsers += [ordered]@{
        Id                = [string]$User.Id
        DisplayName       = [string]$User.DisplayName
        UserPrincipalName = [string]$User.UserPrincipalName
        AccountEnabled    = if ($null -ne $User.AccountEnabled) { [bool]$User.AccountEnabled } else { $true }
    }

    foreach ($existingUser in (Get-RecentUsers)) {
        $sameId = $existingUser.Id -and $User.Id -and $existingUser.Id -eq $User.Id
        $sameUpn = $existingUser.UserPrincipalName -and $User.UserPrincipalName -and $existingUser.UserPrincipalName.ToLower() -eq $User.UserPrincipalName.ToLower()
        if ($sameId -or $sameUpn) { continue }
        $allUsers += $existingUser
    }

    Save-RecentUsers -Users (@($allUsers | Select-Object -First (Get-ConfiguredRecentUserLimit)))
}

function ConvertTo-DirectoryUserRecord {
    param($User)
    if ($null -eq $User) { return $null }
    $id = if ($null -ne $User.id) { [string]$User.id } elseif ($null -ne $User.Id) { [string]$User.Id } else { '' }
    $displayName = if ($null -ne $User.displayName) { [string]$User.displayName } elseif ($null -ne $User.DisplayName) { [string]$User.DisplayName } else { '' }
    $upn = if ($null -ne $User.userPrincipalName) { [string]$User.userPrincipalName } elseif ($null -ne $User.UserPrincipalName) { [string]$User.UserPrincipalName } else { '' }
    $accountEnabled = if ($null -ne $User.accountEnabled) { [bool]$User.accountEnabled } elseif ($null -ne $User.AccountEnabled) { [bool]$User.AccountEnabled } else { $true }
    if ([string]::IsNullOrWhiteSpace($upn)) { return $null }
    return [ordered]@{ Id = $id; DisplayName = $displayName; UserPrincipalName = $upn; AccountEnabled = $accountEnabled }
}

function Test-NameWordApproximation {
    <#
    .SYNOPSIS
        Checks one insertion, deletion or substitution in a complete name word.
    .DESCRIPTION
        Uses bounded string comparisons compatible with both supported hosts.
        Short fragments remain literal; transpositions and account identities
        are not corrected. This helper never selects or assigns an owner.
    .PARAMETER Fragment
        Lower-case query fragment of at least four characters.
    .PARAMETER Word
        Lower-case complete display-name word.
    .OUTPUTS
        Boolean indicating a maximum of one character edit.
    #>
    param([string]$Fragment, [string]$Word)
    if ($Fragment.Length -lt 4 -or [Math]::Abs($Fragment.Length - $Word.Length) -gt 1) { return $false }
    $fragmentIndex = 0
    $wordIndex = 0
    $edits = 0
    while ($fragmentIndex -lt $Fragment.Length -and $wordIndex -lt $Word.Length) {
        if ($Fragment[$fragmentIndex] -eq $Word[$wordIndex]) {
            $fragmentIndex++; $wordIndex++; continue
        }
        $edits++
        if ($edits -gt 1) { return $false }
        if ($Fragment.Length -ge $Word.Length) { $fragmentIndex++ }
        if ($Word.Length -ge $Fragment.Length) { $wordIndex++ }
    }
    if ($fragmentIndex -lt $Fragment.Length -or $wordIndex -lt $Word.Length) { $edits++ }
    return $edits -le 1
}

function Test-DirectoryUserSearchMatch {
    <#
    .SYNOPSIS
        Matches an exact account identity or every supplied name fragment.
    .DESCRIPTION
        Name fragments may appear in any order in the display name or UPN.
        This check narrows candidates only; account eligibility and explicit
        technician selection remain separate requirements.
    .PARAMETER User
        Dictionary-backed or object-backed directory user candidate.
    .PARAMETER SearchMode
        ExactUpn matches the full UPN or complete username, never a prefix.
    .PARAMETER Query
        Technician-supplied account identity or whitespace-separated fragments.
    .OUTPUTS
        Boolean indicating whether the candidate matches the query.
    #>
    param(
        $User,
        [Parameter(Mandatory)][ValidateSet('ExactUpn', 'DisplayName')][string]$SearchMode,
        [AllowEmptyString()][string]$Query,
        [switch]$Approximate
    )
    if ($null -eq $User -or [string]::IsNullOrWhiteSpace($Query)) { return $false }
    $normalisedQuery = $Query.Trim().ToLowerInvariant()
    $upn = ([string]$User.UserPrincipalName).ToLowerInvariant()
    if ($SearchMode -eq 'ExactUpn') {
        return $upn -eq $normalisedQuery -or (Get-UserLocalPart -UserPrincipalName $upn) -eq $normalisedQuery
    }
    $searchText = ('{0} {1}' -f $User.DisplayName, $upn).ToLowerInvariant()
    foreach ($fragment in ($normalisedQuery -split '\s+')) {
        if ($searchText.Contains($fragment)) { continue }
        if (-not $Approximate) { return $false }
        $wordMatches = @(([string]$User.DisplayName).ToLowerInvariant() -split '\s+' | Where-Object {
                Test-NameWordApproximation -Fragment $fragment -Word $_
            })
        if ($wordMatches.Count -eq 0) { return $false }
    }
    return $true
}

function Get-DirectoryUserSearchRank {
    <#
    .SYNOPSIS
        Ranks a matching candidate by literal name or identity relevance.
    .DESCRIPTION
        Lower ranks favour exact identities/names, leading phrases, word prefixes,
        contained phrases, then name fragments over UPN-only fragment matches.
        Ranking does not infer account roles or make an ownership decision.
    .PARAMETER User
        Eligible directory candidate already matched against the query.
    .PARAMETER Query
        Technician-supplied literal identity or name fragments.
    .OUTPUTS
        Integer relevance tier from zero (strongest) to five (weakest).
    #>
    param(
        [Parameter(Mandatory)]$User,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Query
    )
    $normalisedQuery = ($Query.Trim().ToLowerInvariant() -split '\s+') -join ' '
    $name = (([string]$User.DisplayName).Trim().ToLowerInvariant() -split '\s+') -join ' '
    $upn = ([string]$User.UserPrincipalName).ToLowerInvariant()
    if (-not (Test-DirectoryUserSearchMatch -User $User -SearchMode DisplayName -Query $Query)) { return 6 }
    if ($name -eq $normalisedQuery -or $upn -eq $normalisedQuery -or
        (Get-UserLocalPart -UserPrincipalName $upn) -eq $normalisedQuery) { return 0 }
    if ($name.StartsWith($normalisedQuery)) { return 1 }
    $allWordPrefixes = $true
    $allNameFragments = $true
    foreach ($fragment in ($normalisedQuery -split '\s+')) {
        $wordPrefix = $false
        foreach ($word in ($name -split '\s+')) {
            if ($word.StartsWith($fragment)) { $wordPrefix = $true; break }
        }
        if (-not $wordPrefix) { $allWordPrefixes = $false }
        if (-not $name.Contains($fragment)) { $allNameFragments = $false }
    }
    if ($allWordPrefixes) { return 2 }
    if ($name.Contains($normalisedQuery)) { return 3 }
    if ($allNameFragments) { return 4 }
    return 5
}

function Get-DirectoryUserSearchResult {
    <#
    .SYNOPSIS
        Returns eligible literal matches in deterministic relevance order.
    .DESCRIPTION
        Shares matching and ranking between Demo and Live searches. Equal ranks
        sort by display name and UPN. Does not mutate user or persistence records.
    .PARAMETER Users
        Candidate collection; null and empty collections return no results.
    .PARAMETER SearchMode
        Exact identity or display-name fragment search.
    .PARAMETER Query
        Literal technician query. Empty queries return no results.
    .OUTPUTS
        Directory candidates ordered by relevance, display name, then UPN.
    #>
    param(
        [AllowNull()][AllowEmptyCollection()][object[]]$Users,
        [Parameter(Mandatory)][ValidateSet('ExactUpn', 'DisplayName')][string]$SearchMode,
        [AllowEmptyString()][string]$Query,
        [switch]$Approximate
    )
    if ([string]::IsNullOrWhiteSpace($Query)) { return }
    $Users | Where-Object {
        (Test-EligibleDirectoryUser -User $_) -and
        (Test-DirectoryUserSearchMatch -User $_ -SearchMode $SearchMode -Query $Query -Approximate:$Approximate)
    } | Sort-Object { Get-DirectoryUserSearchRank -User $_ -Query $Query }, { $_.DisplayName }, { $_.UserPrincipalName }
}

function Search-DemoDirectoryUsers {
    param(
        [Parameter(Mandatory)][ValidateSet('ExactUpn', 'DisplayName')][string]$SearchMode,
        [Parameter(Mandatory)][string]$Query,
        [switch]$Approximate
    )
    $allUsers = @()
    foreach ($demoUser in (Get-RecentUsers)) { $allUsers += $demoUser }
    foreach ($demoUser in @($Script:RuntimeConfig.demo.defaultUsers)) {
        $userRecord = ConvertTo-DirectoryUserRecord -User $demoUser
        if ($null -eq $userRecord) { continue }
        $isDuplicate = @($allUsers | Where-Object { $_.UserPrincipalName.ToLower() -eq $userRecord.UserPrincipalName.ToLower() }).Count -gt 0
        if (-not $isDuplicate) { $allUsers += $userRecord }
    }

    $matchedUsers = @(Get-DirectoryUserSearchResult -Users $allUsers -SearchMode $SearchMode -Query $Query -Approximate:$Approximate)
    if ($matchedUsers.Count -eq 0 -and $SearchMode -eq 'DisplayName' -and -not $Approximate -and
        @($Query.Trim() -split '\s+' | Where-Object { $_.Length -ge 4 }).Count -gt 0) {
        Write-Host 'No literal matches. Approximate name suggestions follow; verify the full name and account before selecting.'
        return , (Search-DemoDirectoryUsers -SearchMode $SearchMode -Query $Query -Approximate)
    }
    return , $matchedUsers
}

function Search-LiveDirectoryUsers {
    <#
    .SYNOPSIS
        Retrieves bounded Graph candidate pages for technician-directed search.
    .DESCRIPTION
        Follows complete users continuation URLs, rejects repeated or unexpected
        links, and warns when the page bound leaves candidate discovery incomplete.
        Name searches retrieve prefixes for every distinct supplied fragment,
        then require all fragments to match locally. An exhaustive empty literal
        search may run one bounded approximate pass; truncated searches may not.
        Eligibility and query matching apply before returning unique identities.
    .PARAMETER SearchMode
        Exact account identity or order-independent name-fragment matching.
    .PARAMETER Query
        Technician-supplied search text; no ownership-role inference is performed.
    .OUTPUTS
        Array of eligible user dictionaries, bounded by directorySearchLimit.
        Graph failures propagate rather than returning misleading partial success.
    #>
    param(
        [Parameter(Mandatory)][ValidateSet('ExactUpn', 'DisplayName')][string]$SearchMode,
        [Parameter(Mandatory)][string]$Query,
        [switch]$Approximate
    )

    $searchLimit = Get-ConfiguredSearchLimit
    $escapedQuery = $Query.Trim().Replace("'", "''")

    if ([string]::IsNullOrWhiteSpace($escapedQuery)) { return @() }

    switch ($SearchMode) {
        'ExactUpn' {
            $uri = ('https://graph.microsoft.com/v1.0/users?$filter=startswith(userPrincipalName,''{0}'')&$select=id,displayName,userPrincipalName,accountEnabled&$top={1}' -f $escapedQuery, $searchLimit)
        }
        'DisplayName' {
            $fragmentFilters = @($Query.Trim() -split '\s+' | Select-Object -Unique | ForEach-Object {
                    $prefix = $_
                    if ($Approximate -and $prefix.Length -ge 4) { $prefix = $prefix.Substring(0, 2) }
                    "startswith(displayName,'{0}') or startswith(givenName,'{0}') or startswith(surname,'{0}') or startswith(userPrincipalName,'{0}')" -f $prefix.Replace("'", "''")
                })
            $uri = ('https://graph.microsoft.com/v1.0/users?$filter={0}&$select=id,displayName,userPrincipalName,accountEnabled&$top={1}' -f ($fragmentFilters -join ' or '), $searchLimit)
        }
    }

    $pageLimit = Get-ConfiguredDirectorySearchPageLimit
    $visitedLinks = @()
    $candidates = @()
    $seenUpns = @()
    while ($uri) {
        if ($uri -cnotmatch '^https://graph\.microsoft\.com/v1\.0/users\?' -or $uri -match '[\r\n#]') {
            throw 'Directory search returned an unexpected continuation URL.'
        }
        if ($uri -in $visitedLinks) { throw 'Directory search returned a repeated continuation URL.' }
        $visitedLinks += $uri
        $response = Invoke-GraphApiRequest -Method 'GET' -Uri $uri
        if ($null -eq $response -or $null -eq $response.value) {
            throw 'Directory search returned an invalid users page.'
        }
        foreach ($rawUser in @($response.value)) {
            $user = ConvertTo-DirectoryUserRecord -User $rawUser
            if ($null -eq $user -or -not (Test-EligibleDirectoryUser -User $user)) { continue }
            if (-not (Test-DirectoryUserSearchMatch -User $user -SearchMode $SearchMode -Query $Query -Approximate:$Approximate)) { continue }
            if ($user.UserPrincipalName -in $seenUpns) { continue }
            $seenUpns += $user.UserPrincipalName
            $candidates += $user
        }
        $uri = [string]$response.'@odata.nextLink'
        if ($uri -and $visitedLinks.Count -ge $pageLimit) {
            Write-Warning ('Directory search stopped after {0} pages; results may be incomplete. Refine the search or use the full UPN.' -f $pageLimit)
            break
        }
    }
    $matchedUsers = @(Get-DirectoryUserSearchResult -Users $candidates -SearchMode $SearchMode -Query $Query -Approximate:$Approximate)
    if ($matchedUsers.Count -eq 0 -and $SearchMode -eq 'DisplayName' -and -not $Approximate -and
        -not $uri -and @($Query.Trim() -split '\s+' | Where-Object { $_.Length -ge 4 }).Count -gt 0) {
        Write-Host 'No literal matches. Approximate name suggestions follow; verify the full name and account before selecting.'
        return , (Search-LiveDirectoryUsers -SearchMode $SearchMode -Query $Query -Approximate)
    }
    return , @($matchedUsers | Select-Object -First $searchLimit)
}

function Select-UserFromResults {
    param(
        [AllowNull()]
        [AllowEmptyCollection()]
        [object[]]$Users,
        [Parameter(Mandatory)][string]$Heading,
        [switch]$PreserveOrder
    )
    $sortedUsers = @($Users | Where-Object { $null -ne $_ })
    if (-not $PreserveOrder) {
        $sortedUsers = @($sortedUsers | Sort-Object { $_.DisplayName }, { $_.UserPrincipalName })
    }
    if ($sortedUsers.Count -eq 0) {
        Write-Host 'No active C/E user accounts matched that selection.'
        return $null
    }

    Write-Host ''
    Write-Host $Heading
    for ($index = 0; $index -lt $sortedUsers.Count; $index++) {
        Write-Host ('{0}. {1} <{2}>' -f ($index + 1), $sortedUsers[$index].DisplayName, $sortedUsers[$index].UserPrincipalName)
    }

    $selection = Read-ValidatedInput -Prompt 'Choose user number (0 to cancel)' -Default '0' -Type 'Int'
    if ([int]$selection -eq 0) { return $null }
    $selectedIndex = [int]$selection - 1
    if ($selectedIndex -lt 0 -or $selectedIndex -ge $sortedUsers.Count) {
        Write-Host 'Invalid user selection.'
        return $null
    }
    return $sortedUsers[$selectedIndex]
}

function Select-DirectoryUser {
    while ($true) {
        Write-Host ''
        Write-Host 'Final primary user search (active C/E accounts only):'
        Write-Host '1. Recent users'
        Write-Host '2. Exact username search'
        Write-Host '3. Display name search'
        Write-Host '0. Cancel'

        $selectionMode = Read-ValidatedInput -Prompt 'Choose a search mode' -Default '0' -Type 'Choice' -Choices @('1', '2', '3', '0')
        switch ($selectionMode) {
            '0' { return $null }
            '1' {
                $selectedRecentUser = Resolve-EligibleDirectoryUser -User (Select-UserFromResults -Users (Get-RecentUsers) -Heading 'Recent active C/E users')
                if ($selectedRecentUser) { return $selectedRecentUser }
            }
            '2' {
                $usernameQuery = Read-ValidatedInput -Prompt 'Enter username or full UPN'
                $results = if ($Script:Runtime.IsDemoMode) { Search-DemoDirectoryUsers -SearchMode 'ExactUpn' -Query $usernameQuery } else { Search-LiveDirectoryUsers -SearchMode 'ExactUpn' -Query $usernameQuery }
                $selectedUser = Resolve-EligibleDirectoryUser -User (Select-UserFromResults -Users $results -Heading 'Exact username results' -PreserveOrder)
                if ($selectedUser) { return $selectedUser }
            }
            '3' {
                $nameQuery = Read-ValidatedInput -Prompt 'Enter part of the display name'
                $results = if ($Script:Runtime.IsDemoMode) { Search-DemoDirectoryUsers -SearchMode 'DisplayName' -Query $nameQuery } else { Search-LiveDirectoryUsers -SearchMode 'DisplayName' -Query $nameQuery }
                $selectedUser = Resolve-EligibleDirectoryUser -User (Select-UserFromResults -Users $results -Heading 'Display name results' -PreserveOrder)
                if ($selectedUser) { return $selectedUser }
            }
        }
    }
}

function Resolve-LiveAutopilotDeviceBySerial {
    <#
    .SYNOPSIS
        Resolve one complete Autopilot serial match without choosing duplicates.
    .PARAMETER Serial
        Canonical serial; a valid empty collection means absent, not an error.
    .OUTPUTS
        Unique local serial match or null after complete bounded discovery.
        Malformed, incomplete or ambiguous results throw.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Serial)
    $collection = Get-GraphDiscoveryCollection -Uri 'https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities' -RequiredTextProperty serialNumber
    $identities = @($collection | Where-Object { $_.serialNumber -ieq $Serial })
    if ($identities.Count -gt 1) { throw 'Multiple Autopilot identities matched the serial; resolve duplicate records before continuing.' }
    if ($identities.Count -eq 0) { return $null }
    return $identities[0]
}

function Resolve-LiveManagedDeviceBySerial {
    <#
    .SYNOPSIS
        Resolves a unique managed device or confirms an empty serial search.
    .DESCRIPTION
        Missing bodies, incomplete pages, duplicates and inconsistent identities
        fail closed rather than becoming evidence that a device is absent.
    .PARAMETER Serial
        Canonical serial number used for the exact Graph filter.
    .OUTPUTS
        One managed-device record, or null for a valid empty response.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Serial)
    $escapedSerial = $Serial.Replace("'", "''")
    $uri = ('https://graph.microsoft.com/v1.0/deviceManagement/managedDevices?$filter=serialNumber eq ''{0}''&$select=id,deviceName,serialNumber,userPrincipalName,azureADDeviceId' -f $escapedSerial)
    $response = Invoke-GraphApiRequest -Method 'GET' -Uri $uri
    if ($null -eq $response -or $response.value -isnot [array] -or $response.'@odata.nextLink') {
        throw 'Managed-device serial lookup returned an incomplete or malformed response.'
    }
    $managedDevices = @($response.value)
    if ($managedDevices.Count -gt 1) { throw 'Multiple managed devices matched the serial; resolve the duplicate records before continuing.' }
    if ($managedDevices.Count -eq 0) { return $null }
    if ($managedDevices[0].id -isnot [string] -or [string]::IsNullOrWhiteSpace($managedDevices[0].id) -or $managedDevices[0].serialNumber -isnot [string] -or $managedDevices[0].serialNumber -ne $Serial) {
        throw 'Managed-device serial lookup returned a missing or unexpected identity.'
    }
    return $managedDevices[0]
}

function Resolve-LiveEntraDeviceObject {
    <#
    .SYNOPSIS
        Resolve one Entra object for the exact device registration identifier.
    .PARAMETER AzureAdDeviceId
        Device registration ID, distinct from the returned Entra object ID.
    .OUTPUTS
        Matching object or null. Malformed, paged or ambiguous results throw.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$AzureAdDeviceId)
    $escapedDeviceId = $AzureAdDeviceId.Replace("'", "''")
    $uri = ('https://graph.microsoft.com/v1.0/devices?$filter=deviceId eq ''{0}''&$select=id,displayName,deviceId' -f $escapedDeviceId)
    $response = Invoke-GraphApiRequest -Method 'GET' -Uri $uri
    if ($null -eq $response -or $response.value -isnot [array] -or $response.'@odata.nextLink') {
        throw 'Entra device lookup returned an incomplete or malformed response.'
    }
    $identities = $response.value
    if ($identities.Count -gt 1) { throw 'Multiple Entra objects matched the device ID; resolve duplicate records before continuing.' }
    if ($identities.Count -eq 0) { return $null }
    $identity = $identities[0]
    if ($identity.id -isnot [string] -or [string]::IsNullOrWhiteSpace($identity.id) -or
        $identity.deviceId -isnot [string] -or $identity.deviceId -ne $AzureAdDeviceId) {
        throw 'Entra device lookup returned a missing or unexpected identity.'
    }
    return $identity
}

function Get-LiveManagedDevicePrimaryUsers {
    param([Parameter(Mandatory)][string]$ManagedDeviceId)
    $response = Invoke-GraphApiRequest -Method 'GET' -Uri ('https://graph.microsoft.com/v1.0/deviceManagement/managedDevices/{0}/users?$select=id,displayName,userPrincipalName' -f $ManagedDeviceId)
    if ($null -eq $response -or $response.value -isnot [array]) {
        throw 'Managed-device primary-user read-back returned an invalid users collection.'
    }
    if ($response.'@odata.nextLink') {
        throw 'Managed-device primary-user read-back was incomplete; additional users pages were returned.'
    }
    $users = @()
    foreach ($rawUser in @($response.value)) {
        if ($rawUser.id -isnot [string] -or [string]::IsNullOrWhiteSpace($rawUser.id) -or $rawUser.userPrincipalName -isnot [string] -or [string]::IsNullOrWhiteSpace($rawUser.userPrincipalName)) { throw 'Managed-device primary-user read-back contained an invalid identity.' }
        $user = ConvertTo-DirectoryUserRecord -User $rawUser
        if ($null -eq $user) { throw 'Managed-device primary-user read-back contained an invalid identity.' }
        $users += $user
    }
    return $users
}

function Test-ManagedDevicePrimaryUserMatch {
    <#
    .SYNOPSIS
        Verifies that one observed primary-user relationship matches the target.
    .DESCRIPTION
        Object IDs are authoritative when available on both records. UPN matching
        is a fallback only when an ID is absent. Multiple, missing or unrelated
        relationships cannot establish exclusive primary-user assignment.
    .PARAMETER Users
        Complete read-back collection; empty collections do not match.
    .PARAMETER User
        Selected target identity, not an inferred account role.
    .OUTPUTS
        Boolean indicating an exclusive matching primary-user relationship.
    #>
    param(
        [AllowNull()][AllowEmptyCollection()][object[]]$Users,
        [Parameter(Mandatory)]$User
    )
    if ($null -eq $Users -or $Users.Count -ne 1 -or $null -eq $Users[0]) { return $false }
    $observedUser = $Users[0]
    if ($observedUser.Id -and $User.Id) { return [string]$observedUser.Id -ieq [string]$User.Id }
    if ([string]::IsNullOrWhiteSpace([string]$observedUser.UserPrincipalName) -or
        [string]::IsNullOrWhiteSpace([string]$User.UserPrincipalName)) { return $false }
    return [string]$observedUser.UserPrincipalName -ieq [string]$User.UserPrincipalName
}

function Get-LiveTenantBinding {
    <#
    .SYNOPSIS
        Validate actual SDK tenant and optional record ownership without changing state.
    .PARAMETER Device
        Optional device dictionary whose persisted tenant must match the session.
    .PARAMETER AllowUnbound
        Permit only clean new records; resolution stages binding after all reads.
    .OUTPUTS
        Authenticated tenant GUID text, or an actionable terminating refusal.
    #>
    param($Device, [switch]$AllowUnbound)
    if ($Script:Runtime.IsDemoMode) { return '' }
    if (-not $Script:GraphSession.Connected -or $Script:GraphSession.IsSimulated) { throw 'A connected non-simulated Graph session is required for tenant binding.' }
    $tenantId = $Script:GraphSession.TenantId
    $context = Get-MgContext -ErrorAction Stop
    $guidPattern = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    if ($tenantId -isnot [string] -or $tenantId -notmatch $guidPattern -or
        $context.TenantId -isnot [string] -or $context.TenantId -notmatch $guidPattern) { throw 'Graph session and actual context TenantId must be GUID strings.' }
    if ($context.TenantId -ine $tenantId) { throw 'Actual Graph context TenantId changed; reconnect before reusing records or groups.' }
    $expectedTenantId = $Script:RuntimeConfig.graph.expectedTenantId
    if ($null -ne $expectedTenantId -and ($expectedTenantId -isnot [string] -or
            ($expectedTenantId -cne '' -and $expectedTenantId -notmatch $guidPattern))) { throw 'Configured expectedTenantId must be empty or a tenant GUID string.' }
    if ($expectedTenantId -and $tenantId -ine $expectedTenantId) { throw 'Graph tenant does not match configured expectedTenantId; no device activity is permitted.' }
    if ($null -ne $Device) {
        $deviceTenant = $Device.TenantId
        if (($Device.Contains('TenantId') -and $deviceTenant -isnot [string]) -or
            ($null -ne $deviceTenant -and $deviceTenant -cne '' -and $deviceTenant -notmatch $guidPattern)) { throw 'Device TenantId must be empty legacy text or a GUID string.' }
        if ($deviceTenant) {
            if ($deviceTenant -ine $tenantId) { throw 'Device TenantId does not match the authenticated tenant; no device reads or writes are permitted.' }
        }
        else {
            foreach ($field in @('AutopilotDeviceId', 'ManagedDeviceId', 'AzureAdDeviceId', 'EntraDeviceId', 'FinalPrimaryUserId', 'TechnicianUserPrincipalName', 'FinalPrimaryUserPrincipalName', 'CompletedBy', 'RecoveryReason')) {
                if ($Device[$field]) { throw 'Legacy device has no TenantId but contains cached IDs or evidence; deliberate tenant migration is required.' }
            }
            if ($Device.Steps.Count -gt 0 -or $Device.RecoveryHistory.Count -gt 0 -or $Device.RecoveryActive -or $Device.IsCompletionVerified -or
                ($Device.CompletedAt -and $Device.CompletedAt -ne [DateTime]::MinValue) -or
                ($Device.RecoveryStartedAt -and $Device.RecoveryStartedAt -ne [DateTime]::MinValue) -or $Device.Status -eq 'completed') {
                throw 'Legacy device has no TenantId but contains workflow or recovery evidence; deliberate tenant migration is required.'
            }
            if (-not $AllowUnbound) { throw 'Resolve this new device successfully to bind its TenantId before recording Live evidence.' }
        }
    }
    return $tenantId
}

function Resolve-LiveAutopilotContext {
    <#
    .SYNOPSIS
        Refresh device identifiers only after all identity reads succeed.
    .PARAMETER Device
        Existing device dictionary to refresh from current Graph evidence.
    .OUTPUTS
        Resolved Graph records. Failed reads leave the device unchanged;
        absent records clear cached mutation identifiers on successful refresh.
    #>
    param([Parameter(Mandatory)]$Device)

    $tenantId = Get-LiveTenantBinding -Device $Device -AllowUnbound
    $autopilotDevice = Resolve-LiveAutopilotDeviceBySerial -Serial $Device.Serial
    $managedDevice = Resolve-LiveManagedDeviceBySerial -Serial $Device.Serial
    $entraDevice = $null
    $resolved = @{ TenantId = $tenantId; AutopilotDeviceId = ''; ManagedDeviceId = ''; AzureAdDeviceId = ''; EntraDeviceId = ''; IntuneDeviceName = $Device.IntuneDeviceName; GroupTag = $Device.GroupTag }

    if ($null -ne $autopilotDevice) {
        $resolved.AutopilotDeviceId = [string]$autopilotDevice.id
        $resolved.GroupTag = [string]$autopilotDevice.groupTag
        if ($autopilotDevice.displayName) { $resolved.IntuneDeviceName = [string]$autopilotDevice.displayName }
        if ($autopilotDevice.azureActiveDirectoryDeviceId) { $resolved.AzureAdDeviceId = [string]$autopilotDevice.azureActiveDirectoryDeviceId }
    }

    if ($null -ne $managedDevice) {
        $resolved.ManagedDeviceId = [string]$managedDevice.id
        if ($managedDevice.deviceName) { $resolved.IntuneDeviceName = [string]$managedDevice.deviceName }
        if ($managedDevice.azureADDeviceId) { $resolved.AzureAdDeviceId = [string]$managedDevice.azureADDeviceId }
    }

    if ($resolved.AzureAdDeviceId) {
        $entraDevice = Resolve-LiveEntraDeviceObject -AzureAdDeviceId $resolved.AzureAdDeviceId
        if ($null -ne $entraDevice) { $resolved.EntraDeviceId = [string]$entraDevice.id }
    }
    foreach ($propertyName in $resolved.Keys) { $Device[$propertyName] = $resolved[$propertyName] }

    return [ordered]@{ Autopilot = $autopilotDevice; Managed = $managedDevice; Entra = $entraDevice }
}

function Get-LivePreProvisioningGroup {
    $groupName = Get-ConfiguredPreProvisioningGroupDisplayName
    $escapedGroupName = $groupName.Replace("'", "''")
    $uri = ('https://graph.microsoft.com/v1.0/groups?$filter=displayName eq ''{0}''&$select=id,displayName,securityEnabled,mailEnabled,groupTypes,isAssignableToRole' -f $escapedGroupName)
    $groups = Get-GraphDiscoveryCollection -Uri $uri
    if ($groups.Count -eq 0) { throw ('Group not found: {0}' -f $groupName) }
    if ($groups.Count -gt 1) { throw ('Multiple groups matched display name: {0}' -f $groupName) }
    if ($groups[0].displayName -ne $groupName) { throw 'Group discovery returned an unexpected display name.' }
    return $groups[0]
}

function Get-LiveAutopilotDeviceById {
    param([Parameter(Mandatory)][string]$AutopilotDeviceId)

    return Invoke-GraphApiRequest -Method 'GET' -Uri ('https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities/{0}?$select=id,groupTag,userPrincipalName,addressableUserName' -f $AutopilotDeviceId)
}

function Test-LiveGroupMembership {
    <#
    .SYNOPSIS
        Reads direct membership, failing closed on ambiguous Graph errors.
    .DESCRIPTION
        Uses complete direct member collections, without advanced-query indexes.
        Absence also requires the expected group and device identities to exist.
        HTTP errors, including 404, never establish absence.
    .PARAMETER GroupId
        Group object ID to inspect.
    .PARAMETER DirectoryObjectId
        Device directory object ID to inspect.
    .OUTPUTS
        Boolean membership state, or a terminating read/identity error.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$GroupId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$DirectoryObjectId
    )

    $members = Get-GraphDiscoveryCollection -Uri ('https://graph.microsoft.com/v1.0/groups/{0}/members' -f $GroupId) -RequiredTextProperty id
    if (@($members | Where-Object { $_.id -ieq $DirectoryObjectId }).Count -eq 1) { return $true }
    $group = Invoke-GraphApiRequest -Method 'GET' -Uri ('https://graph.microsoft.com/v1.0/groups/{0}?$select=id' -f $GroupId)
    $directoryObject = Invoke-GraphApiRequest -Method 'GET' -Uri ('https://graph.microsoft.com/v1.0/directoryObjects/{0}?$select=id' -f $DirectoryObjectId)
    if ($group.id -isnot [string] -or $group.id -ine $GroupId -or $directoryObject.id -isnot [string] -or $directoryObject.id -ine $DirectoryObjectId) {
        throw 'Membership absence could not be verified against the expected group and device identities.'
    }
    return $false
}

function Get-GraphVerificationPolicy {
    <#
    .SYNOPSIS
        Validates the existing attempt and pause settings for read-back polling.
    .DESCRIPTION
        MaxRetryAttempts bounds total reads per verification cycle, including the
        first immediate read. RetryBackoffSeconds is the fixed pause between reads.
        Defaults match the central configuration when running extracted helpers.
    .OUTPUTS
        Dictionary with MaxAttempts (1-20) and IntervalSeconds (0-60).
    #>
    $attempts = if ($null -ne $Script:Config.MaxRetryAttempts) { $Script:Config.MaxRetryAttempts } else { 5 }
    $interval = if ($null -ne $Script:Config.RetryBackoffSeconds) { $Script:Config.RetryBackoffSeconds } else { 3 }
    if ([string]$attempts -notmatch '^[1-9][0-9]?$' -or [int]$attempts -gt 20) {
        throw 'MaxRetryAttempts must be an integer from 1 to 20 for Graph state verification.'
    }
    if ([string]$interval -notmatch '^(0|[1-9][0-9]?)$' -or [int]$interval -gt 60) {
        throw 'RetryBackoffSeconds must be an integer from 0 to 60 for Graph state verification.'
    }
    return @{ MaxAttempts = [int]$attempts; IntervalSeconds = [int]$interval }
}

function Wait-PrimaryUserAssignmentVerification {
    <#
    .SYNOPSIS
        Polls one assignment surface without repeating its mutation.
    .DESCRIPTION
        Stops at the first matching read-back or the configured read count.
        Request and malformed-response errors propagate immediately; this helper
        does not retry failures or interpret throttling headers. No pause follows
        success or the last read, and all reads preserve strict identity matching.
    .PARAMETER Surface
        Autopilot UPN or exclusive ManagedDevice primary-user relationship.
    .PARAMETER DeviceId
        Identity for the selected assignment surface.
    .PARAMETER User
        Explicitly selected target identity.
    .PARAMETER MaxAttempts
        Total read-back attempts including the immediate first read.
    .PARAMETER IntervalSeconds
        Fixed pause between unsuccessful reads; zero is useful for tests.
    .OUTPUTS
        Dictionary containing Confirmed and the number of Attempts performed.
    #>
    param(
        [Parameter(Mandatory)][ValidateSet('Autopilot', 'ManagedDevice')][string]$Surface,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$DeviceId,
        [Parameter(Mandatory)]$User,
        [Parameter(Mandatory)][ValidateRange(1, 20)][int]$MaxAttempts,
        [Parameter(Mandatory)][ValidateRange(0, 60)][int]$IntervalSeconds
    )
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        if ($Surface -eq 'Autopilot') {
            $observed = Get-LiveAutopilotDeviceById -AutopilotDeviceId $DeviceId
            if ($observed.id -isnot [string] -or $observed.id -ine $DeviceId) { throw 'Primary-user verification returned a missing or unexpected Autopilot identity.' }
            $confirmed = -not [string]::IsNullOrWhiteSpace([string]$User.UserPrincipalName) -and
            [string]$observed.userPrincipalName -ieq [string]$User.UserPrincipalName
        }
        else {
            $observedUsers = @(Get-LiveManagedDevicePrimaryUsers -ManagedDeviceId $DeviceId)
            $confirmed = Test-ManagedDevicePrimaryUserMatch -Users $observedUsers -User $User
        }
        if ($confirmed) { return @{ Confirmed = $true; Attempts = $attempt } }
        if ($attempt -lt $MaxAttempts -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
    }
    return @{ Confirmed = $false; Attempts = $MaxAttempts }
}

function Invoke-LivePrimaryUserAssignment {
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)]$User
    )

    $verificationSettings = Get-GraphVerificationPolicy
    [void](Resolve-LiveAutopilotContext -Device $Device)

    $assignmentNotes = @()
    $assignmentErrors = @()
    $autopilotAssigned = $false
    $autopilotSubmitted = $false
    $managedDeviceAssigned = $false
    $managedDeviceConfirmed = $false
    $resolvedUser = if ($User.Id) { $User } else { Resolve-LiveDirectoryUserRecord -User $User }

    if ($Device.AutopilotDeviceId) {
        try {
            $body = @{ userPrincipalName = [string]$User.UserPrincipalName; addressableUserName = if ($User.DisplayName) { [string]$User.DisplayName } else { [string]$User.UserPrincipalName } }
            Invoke-GraphApiRequest -Method 'POST' -Uri ('https://graph.microsoft.com/v1.0/deviceManagement/windowsAutopilotDeviceIdentities/{0}/assignUserToDevice' -f $Device.AutopilotDeviceId) -Body $body | Out-Null
            $autopilotSubmitted = $true
            $verification = Wait-PrimaryUserAssignmentVerification -Surface Autopilot -DeviceId $Device.AutopilotDeviceId -User $User -MaxAttempts $verificationSettings.MaxAttempts -IntervalSeconds $verificationSettings.IntervalSeconds
            $autopilotAssigned = $verification.Confirmed
            $assignmentNotes += ('Autopilot verification performed {0} read-back attempts.' -f $verification.Attempts)
            if ($autopilotAssigned) {
                $assignmentNotes += ('Autopilot assigned user verified as {0}.' -f $User.UserPrincipalName)
            }
            else {
                $assignmentNotes += ('Autopilot assigned-user update was submitted but the read-back value did not match {0}.' -f $User.UserPrincipalName)
            }
        }
        catch {
            $assignmentErrors += ('Autopilot user assignment failed: {0}' -f $_.Exception.Message)
        }
    }
    else {
        $assignmentNotes += 'Autopilot device identity was not available for assignUserToDevice.'
    }

    if ($Device.ManagedDeviceId) {
        if ($null -eq $resolvedUser -or [string]::IsNullOrWhiteSpace([string]$resolvedUser.Id)) {
            $assignmentNotes += 'Managed-device primary-user association was skipped because the selected user ID could not be resolved.'
        }
        else {
            try {
                $existingUsers = @(Get-LiveManagedDevicePrimaryUsers -ManagedDeviceId $Device.ManagedDeviceId)
                $alreadyAssigned = @($existingUsers | Where-Object {
                        Test-ManagedDevicePrimaryUserMatch -Users @($_) -User $resolvedUser
                    }).Count -gt 0

                if ($alreadyAssigned) {
                    $managedDeviceAssigned = $true
                    $managedDeviceConfirmed = Test-ManagedDevicePrimaryUserMatch -Users $existingUsers -User $resolvedUser
                    $assignmentNotes += if ($managedDeviceConfirmed) {
                        ('Managed-device primary user already verified as {0}.' -f $resolvedUser.UserPrincipalName)
                    }
                    else {
                        'The selected managed-device user is present, but additional primary-user relationships prevent exclusive verification.'
                    }
                }
                else {
                    $body = @{ '@odata.id' = ('https://graph.microsoft.com/v1.0/users/{0}' -f $resolvedUser.Id) }
                    Invoke-GraphApiRequest -Method 'POST' -Uri ('https://graph.microsoft.com/v1.0/deviceManagement/managedDevices(''{0}'')/users/$ref' -f $Device.ManagedDeviceId) -Body $body | Out-Null
                    $managedDeviceAssigned = $true

                    $verification = Wait-PrimaryUserAssignmentVerification -Surface ManagedDevice -DeviceId $Device.ManagedDeviceId -User $resolvedUser -MaxAttempts $verificationSettings.MaxAttempts -IntervalSeconds $verificationSettings.IntervalSeconds
                    $managedDeviceConfirmed = $verification.Confirmed
                    $assignmentNotes += ('Managed-device verification performed {0} read-back attempts.' -f $verification.Attempts)

                    if ($managedDeviceConfirmed) {
                        $assignmentNotes += ('Managed-device primary-user relationship updated to include {0}.' -f $resolvedUser.UserPrincipalName)
                    }
                    else {
                        $assignmentNotes += ('Managed-device primary-user update for {0} was submitted and may take several minutes to appear.' -f $resolvedUser.UserPrincipalName)
                    }
                }
            }
            catch {
                $assignmentErrors += ('Managed-device primary-user update failed: {0}' -f $_.Exception.Message)
            }
        }
    }
    else {
        $assignmentNotes += 'Managed device record was not available yet, so only the Autopilot user assignment surface was attempted.'
    }

    return [ordered]@{
        User                   = $resolvedUser
        AutopilotAssigned      = $autopilotAssigned
        AutopilotSubmitted     = $autopilotSubmitted
        ManagedDeviceAssigned  = $managedDeviceAssigned
        ManagedDeviceConfirmed = $managedDeviceConfirmed
        AnyAssignmentApplied   = ($autopilotSubmitted -or $autopilotAssigned -or $managedDeviceAssigned)
        Notes                  = @($assignmentNotes)
        Errors                 = @($assignmentErrors)
    }
}

function Invoke-StepResolveAutopilotDevice {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    if ($Script:Runtime.IsDemoMode) {
        $Device.AutopilotDeviceId = [guid]::NewGuid().Guid
        $Device.ManagedDeviceId = [guid]::NewGuid().Guid
        $Device.AzureAdDeviceId = [guid]::NewGuid().Guid
        $Device.EntraDeviceId = [guid]::NewGuid().Guid
        $Device.IntuneDeviceName = ('DEMO-{0}' -f $Device.Serial)
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated Autopilot lookup completed.' -Notes 'Demo mode created synthetic Autopilot, Intune, and Entra identifiers.' -Data @{ Serial = $Device.Serial; IntuneDeviceName = $Device.IntuneDeviceName }
    }

    $evidence = @{ Serial = $Device.Serial; HandoffRecorded = $false; VerificationAttempts = 0 }
    try {
        $policy = Get-GraphVerificationPolicy
        $context = Resolve-LiveAutopilotContext -Device $Device
        $evidence.VerificationAttempts = 1
        if ($null -eq $context.Autopilot) {
            Write-Host (Get-ConfiguredMissingSerialHandoffNote)
            $handoffConfirmed = Read-ValidatedInput -Prompt 'Autopilot serial not found. Has the external upload-guide hand-off been completed? (Y/N; default: N)' -Default 'N' -Type 'Choice' -Choices @('Y', 'N')
            if ($handoffConfirmed.ToUpper() -ne 'Y') {
                return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Autopilot serial could not be resolved.' -Notes 'Complete the external upload-guide hand-off before continuing.' -Data $evidence
            }
            $evidence.HandoffRecorded = $true
            for ($attempt = 1; $attempt -le $policy.MaxAttempts; $attempt++) {
                $context = Resolve-LiveAutopilotContext -Device $Device
                $evidence.VerificationAttempts = $attempt
                if ($null -ne $context.Autopilot) { break }
                if ($attempt -lt $policy.MaxAttempts -and $policy.IntervalSeconds -gt 0) { Start-Sleep -Seconds $policy.IntervalSeconds }
            }
        }
        if ($null -eq $context.Autopilot) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Upload reported, but Autopilot presence is not yet verified.' -Notes 'The bounded fresh lookups found no identity. Leave this step pending and retry lookup after propagation; do not upload again automatically.' -Data $evidence
        }
        if ($context.Autopilot.id -isnot [string] -or [string]::IsNullOrWhiteSpace($context.Autopilot.id) -or $context.Autopilot.serialNumber -ine $Device.Serial) { throw 'Autopilot verification returned an unexpected identity or serial.' }
        $evidence.AutopilotDeviceId = [string]$context.Autopilot.id
        $evidence.ObservedSerial = [string]$context.Autopilot.serialNumber
        $evidence.ManagedDeviceId = $Device.ManagedDeviceId
        $evidence.EntraDeviceId = $Device.EntraDeviceId
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState 'Verified' -Summary 'Autopilot presence verified by a fresh serial lookup.' -Notes 'Upload confirmation alone does not complete this step.' -Data $evidence
    }
    catch {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Autopilot presence verification failed.' -Notes 'The lookup failed or returned invalid evidence. Review the error in the approved diagnostic context; no absence or completion was inferred.' -Data $evidence
    }
}

function Wait-ManagedDeviceRemovalVerification {
    <#
    .SYNOPSIS
        Polls the serial search until no managed device remains.
    .DESCRIPTION
        Repeats only validated reads, never deletion. A remaining record,
        including a replacement ID, cannot establish completion.
    .PARAMETER Serial
        Canonical serial whose Intune record must be absent.
    .PARAMETER MaxAttempts
        Total checks including the immediate first read.
    .PARAMETER IntervalSeconds
        Pause only between unsuccessful checks.
    .OUTPUTS
        Dictionary with Confirmed, Attempts and ObservedManagedDeviceId.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Serial,
        [Parameter(Mandatory)][ValidateRange(1, 20)][int]$MaxAttempts,
        [Parameter(Mandatory)][ValidateRange(0, 60)][int]$IntervalSeconds
    )
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $remaining = Resolve-LiveManagedDeviceBySerial -Serial $Serial
        if ($null -eq $remaining) { return @{ Confirmed = $true; Attempts = $attempt; ObservedManagedDeviceId = '' } }
        if ($attempt -lt $MaxAttempts -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
    }
    return @{ Confirmed = $false; Attempts = $MaxAttempts; ObservedManagedDeviceId = [string]$remaining.id }
}

function Invoke-StepRemoveAssociatedManagedDevice {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    if ($Script:Runtime.IsDemoMode) {
        $Device.ManagedDeviceId = ''
        $Device.IntuneDeviceName = ''
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated Intune device removal completed.' -Notes 'Demo mode cleared the associated Intune device context.' -Data @{ Serial = $Device.Serial }
    }

    $evidence = @{ Serial = $Device.Serial; ManagedDeviceId = $Device.ManagedDeviceId; Submitted = $false; VerificationAttempts = 0 }
    try {
        $policy = Get-GraphVerificationPolicy
        $context = Resolve-LiveAutopilotContext -Device $Device
        if (-not $Device.ManagedDeviceId -or $null -eq $context.Managed) {
            if ($null -eq $context -or $null -eq $context.Managed) {
                $remaining = Resolve-LiveManagedDeviceBySerial -Serial $Device.Serial
                if ($null -ne $remaining) { throw 'Managed-device context could not be resolved consistently; no deletion was attempted.' }
                $Device.ManagedDeviceId = ''
                $Device.IntuneDeviceName = ''
                $evidence.VerificationAttempts = 1
                $evidence.ObservedManagedDeviceId = ''
                return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState 'Verified' -Summary 'No associated Intune device was present.' -Notes 'A valid empty serial search confirmed that no deletion was required.' -Data $evidence
            }
        }
        if (-not $Device.ManagedDeviceId) { throw 'Managed-device context did not include a deletion target ID.' }
        $evidence.ManagedDeviceId = [string]$Device.ManagedDeviceId
        $managedDeviceDisplay = if ($Device.IntuneDeviceName) { $Device.IntuneDeviceName } else { $Device.ManagedDeviceId }
        $confirmDelete = Read-ValidatedInput -Prompt ('Delete associated Intune device {0}? (Y/N; default: Y)' -f $managedDeviceDisplay) -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
        if ($confirmDelete.ToUpper() -ne 'Y') {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Managed-device deletion cancelled.' -Notes 'The associated Intune device was not deleted.' -Data $evidence
        }
        if (Get-Command -Name Remove-MgDeviceManagementManagedDevice -ErrorAction SilentlyContinue) {
            Remove-MgDeviceManagementManagedDevice -ManagedDeviceId $Device.ManagedDeviceId -ErrorAction Stop
        }
        else {
            Invoke-GraphApiRequest -Method 'DELETE' -Uri ('https://graph.microsoft.com/v1.0/deviceManagement/managedDevices/{0}' -f $Device.ManagedDeviceId) | Out-Null
        }
        $evidence.Submitted = $true
        $verification = Wait-ManagedDeviceRemovalVerification -Serial $Device.Serial -MaxAttempts $policy.MaxAttempts -IntervalSeconds $policy.IntervalSeconds
        $evidence.VerificationAttempts = $verification.Attempts
        $evidence.ObservedManagedDeviceId = $verification.ObservedManagedDeviceId
        if (-not $verification.Confirmed) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Managed-device deletion is awaiting verification.' -Notes ('After {0} checks, Intune still returned record {1} for serial {2}; no additional delete was issued.' -f $verification.Attempts, $verification.ObservedManagedDeviceId, $Device.Serial) -Data $evidence
        }
        $Device.ManagedDeviceId = ''
        $Device.IntuneDeviceName = ''
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState 'Verified' -Summary 'Associated Intune device deletion verified.' -Notes ('An empty serial search confirmed removal after {0} checks.' -f $verification.Attempts) -Data $evidence
    }
    catch {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Managed-device deletion or verification failed.' -Notes $_.Exception.Message -Data $evidence
    }
}

function Wait-AutopilotGroupTagVerification {
    <#
    .SYNOPSIS
        Polls the Autopilot identity until its Group Tag matches exactly.
    .DESCRIPTION
        Performs read-only checks without repeating the tag mutation. Identity
        mismatches and request errors stop immediately. A nonmatching tag at the
        attempt bound remains unverified, including case-only differences.
    .PARAMETER AutopilotDeviceId
        Autopilot identity whose tag must be observed.
    .PARAMETER ExpectedTag
        Enforced site/device-type tag, preserving its configured case.
    .PARAMETER MaxAttempts
        Total reads including the immediate first read.
    .PARAMETER IntervalSeconds
        Pause between unsuccessful reads, never after success or the last read.
    .OUTPUTS
        Dictionary containing Confirmed, Attempts and ObservedGroupTag.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$AutopilotDeviceId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ExpectedTag,
        [Parameter(Mandatory)][ValidateRange(1, 20)][int]$MaxAttempts,
        [Parameter(Mandatory)][ValidateRange(0, 60)][int]$IntervalSeconds
    )
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $observed = Get-LiveAutopilotDeviceById -AutopilotDeviceId $AutopilotDeviceId
        if ($null -eq $observed -or [string]$observed.id -ine $AutopilotDeviceId) {
            throw 'Group Tag read-back returned a missing or unexpected Autopilot identity.'
        }
        $observedTag = [string]$observed.groupTag
        if ($observedTag -ceq $ExpectedTag) {
            return @{ Confirmed = $true; Attempts = $attempt; ObservedGroupTag = $observedTag }
        }
        if ($attempt -lt $MaxAttempts -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
    }
    return @{ Confirmed = $false; Attempts = $MaxAttempts; ObservedGroupTag = $observedTag }
}

function Invoke-StepApplyGroupTag {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    $expectedTag = ('{0}-{1}' -f $Device.SiteCode, ($Device.DeviceType -replace '\s', ''))
    if ($Script:Runtime.IsDemoMode) {
        $Device.GroupTag = $expectedTag
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated Group Tag update completed.' -Notes ('Demo mode applied the expected Group Tag {0}.' -f $expectedTag) -Data @{ GroupTag = $expectedTag }
    }

    $submitted = $false
    try {
        $verificationSettings = Get-GraphVerificationPolicy
        $context = Resolve-LiveAutopilotContext -Device $Device
        if (-not $Device.AutopilotDeviceId) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary 'Autopilot device context is required before updating Group Tag.' -Notes 'Run the resolve step first.' -Data @{}
        }
        if ($null -ne $context.Autopilot -and $context.Autopilot.id -ieq $Device.AutopilotDeviceId -and $context.Autopilot.groupTag -ceq $expectedTag) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState Verified -Summary 'Group Tag already matches the required state.' -Notes 'Fresh identity lookup verified the exact tag; no additional update was submitted.' -Data @{ AutopilotDeviceId = $Device.AutopilotDeviceId; GroupTag = $expectedTag; ObservedGroupTag = $context.Autopilot.groupTag; VerificationAttempts = 1; Submitted = $false }
        }
        Invoke-GraphApiRequest -Method 'POST' -Uri ('https://graph.microsoft.com/v1.0/deviceManagement/windowsAutopilotDeviceIdentities/{0}/updateDeviceProperties' -f $Device.AutopilotDeviceId) -Body @{ groupTag = $expectedTag } | Out-Null
        $submitted = $true
        $verification = Wait-AutopilotGroupTagVerification -AutopilotDeviceId $Device.AutopilotDeviceId -ExpectedTag $expectedTag -MaxAttempts $verificationSettings.MaxAttempts -IntervalSeconds $verificationSettings.IntervalSeconds
        $evidence = @{ AutopilotDeviceId = $Device.AutopilotDeviceId; GroupTag = $expectedTag; ObservedGroupTag = $verification.ObservedGroupTag; VerificationAttempts = $verification.Attempts; Submitted = $submitted }
        if (-not $verification.Confirmed) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Group Tag update is awaiting read-back verification.' -Notes ('After {0} reads, expected Group Tag {1}, but observed {2}.' -f $verification.Attempts, $expectedTag, $verification.ObservedGroupTag) -Data $evidence
        }
        $Device.GroupTag = $verification.ObservedGroupTag
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState 'Verified' -Summary 'Group Tag update verified.' -Notes ('Observed Group Tag {0} after {1} reads.' -f $expectedTag, $verification.Attempts) -Data $evidence
    }
    catch {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Group Tag update or verification failed.' -Notes $_.Exception.Message -Data @{ GroupTag = $expectedTag; Submitted = $submitted }
    }
}

function Invoke-StepValidateDeploymentProfile {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    $profileName = Get-ConfiguredDeploymentProfileDisplayName
    if ($Script:Runtime.IsDemoMode) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated deployment-profile validation completed.' -Notes ('Demo mode validated profile {0}.' -f $profileName) -Data @{ DeploymentProfile = $profileName }
    }

    Write-Host ('Validate in Intune that deployment profile "{0}" is assigned to this device.' -f $profileName)
    $confirmed = Read-ValidatedInput -Prompt 'Was the required deployment profile confirmed? (Y/N)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
    $isConfirmed = $confirmed.ToUpper() -eq 'Y'
    $completionState = if ($isConfirmed) { 'TechnicianConfirmed' } else { 'Failed' }
    return New-OperationResult -ActionName $StepDefinition.ActionName -Success $isConfirmed -CompletionState $completionState -Summary 'Deployment-profile validation recorded.' -Notes ('Technician confirmation for profile {0}: {1}' -f $profileName, $confirmed.ToUpper()) -Data @{ DeploymentProfile = $profileName }
}

function Wait-GroupMembershipVerification {
    <#
    .SYNOPSIS
        Polls membership presence or absence without repeating a mutation.
    .DESCRIPTION
        Uses the shared read count and delay contract. Read failures propagate;
        only an observed membership state can confirm the requested outcome.
    .PARAMETER GroupId
        Resolved pre-provisioning group object ID.
    .PARAMETER DirectoryObjectId
        Entra device object ID whose direct membership is checked.
    .PARAMETER ExpectedMember
        True for addition, false for removal.
    .PARAMETER MaxAttempts
        Total read-back checks, including the immediate first check.
    .PARAMETER IntervalSeconds
        Pause between mismatches, never after success or the last check.
    .OUTPUTS
        Dictionary containing Confirmed, Attempts and ObservedMember.
    #>
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$GroupId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$DirectoryObjectId,
        [Parameter(Mandatory)][bool]$ExpectedMember,
        [Parameter(Mandatory)][ValidateRange(1, 20)][int]$MaxAttempts,
        [Parameter(Mandatory)][ValidateRange(0, 60)][int]$IntervalSeconds
    )
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $observedMember = Test-LiveGroupMembership -GroupId $GroupId -DirectoryObjectId $DirectoryObjectId
        if ($observedMember -isnot [bool]) { throw 'Membership verification must return an explicit Boolean observation.' }
        if ($observedMember -eq $ExpectedMember) {
            return @{ Confirmed = $true; Attempts = $attempt; ObservedMember = $observedMember }
        }
        if ($attempt -lt $MaxAttempts -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
    }
    return @{ Confirmed = $false; Attempts = $MaxAttempts; ObservedMember = $observedMember }
}

function Invoke-PreProvisioningMembershipChange {
    <#
    .SYNOPSIS
        Applies and verifies one pre-provisioning membership state transition.
    .DESCRIPTION
        Shared by add/remove manifest handlers. Already-correct state is verified
        without a write; otherwise one reference mutation precedes bounded reads.
        Failures never become successful outcomes based on message wording.
    .PARAMETER Device
        Mutable dictionary-backed workflow record.
    .PARAMETER StepDefinition
        Manifest action whose result must be recorded.
    .PARAMETER ExpectedMember
        True to add the device, false to remove its membership reference.
    .OUTPUTS
        Operation result with explicit outcome and read-back evidence.
    #>
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)]$StepDefinition,
        [Parameter(Mandatory)][bool]$ExpectedMember
    )
    $groupName = Get-ConfiguredPreProvisioningGroupDisplayName
    $changeName = if ($ExpectedMember) { 'addition' } else { 'removal' }
    if ($Script:Runtime.IsDemoMode) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary ('Simulated pre-provisioning membership {0} completed.' -f $changeName) -Notes ('Demo mode simulated membership state {0} for {1}.' -f $ExpectedMember, $groupName) -Data @{ Group = $groupName; ExpectedMember = $ExpectedMember }
    }
    $evidence = @{ Group = $groupName; ExpectedMember = $ExpectedMember; Submitted = $false; VerificationAttempts = 0 }
    try {
        $policy = Get-GraphVerificationPolicy
        [void](Resolve-LiveAutopilotContext -Device $Device)
        if (-not $Device.EntraDeviceId) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary 'Entra device object ID could not be resolved.' -Notes 'Resolve the Autopilot device before changing group membership.' -Data $evidence
        }
        $group = Get-LivePreProvisioningGroup
        if (-not $group.id) { throw 'The pre-provisioning group did not resolve to an object ID.' }
        $evidence.Group = [string]$group.displayName
        $evidence.GroupId = [string]$group.id
        $evidence.DirectoryObjectId = [string]$Device.EntraDeviceId
        $observedMember = Test-LiveGroupMembership -GroupId $group.id -DirectoryObjectId $Device.EntraDeviceId
        if ($observedMember -isnot [bool]) { throw 'Membership verification must return an explicit Boolean observation.' }
        $evidence.ObservedMember = $observedMember
        if ($observedMember -eq $ExpectedMember) {
            $evidence.VerificationAttempts = 1
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState 'Verified' -Summary 'Pre-provisioning membership already matches the required state.' -Notes 'Direct membership was read back; no mutation was required.' -Data $evidence
        }
        if ($group.securityEnabled -isnot [bool] -or -not $group.securityEnabled -or
            $group.mailEnabled -isnot [bool] -or $group.mailEnabled -or
            $group.groupTypes -isnot [array] -or $group.groupTypes.Count -ne 0 -or
            ($null -ne $group.isAssignableToRole -and ($group.isAssignableToRole -isnot [bool] -or $group.isAssignableToRole))) {
            throw 'Pre-provisioning membership requires an assigned, non-mail-enabled, non-role-assignable security group with complete eligibility metadata.'
        }
        if ($ExpectedMember) {
            $body = @{ '@odata.id' = ('https://graph.microsoft.com/v1.0/directoryObjects/{0}' -f $Device.EntraDeviceId) }
            Invoke-GraphApiRequest -Method 'POST' -Uri ('https://graph.microsoft.com/v1.0/groups/{0}/members/$ref' -f $group.id) -Body $body | Out-Null
        }
        else {
            Invoke-GraphApiRequest -Method 'DELETE' -Uri ('https://graph.microsoft.com/v1.0/groups/{0}/members/{1}/$ref' -f $group.id, $Device.EntraDeviceId) | Out-Null
        }
        $evidence.Submitted = $true
        $verification = Wait-GroupMembershipVerification -GroupId $group.id -DirectoryObjectId $Device.EntraDeviceId -ExpectedMember $ExpectedMember -MaxAttempts $policy.MaxAttempts -IntervalSeconds $policy.IntervalSeconds
        $evidence.ObservedMember = $verification.ObservedMember
        $evidence.VerificationAttempts = $verification.Attempts
        $completionState = if ($verification.Confirmed) { 'Verified' } else { 'Submitted' }
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $verification.Confirmed -CompletionState $completionState -Summary ('Pre-provisioning membership {0}: {1}.' -f $changeName, $completionState) -Notes ('After {0} checks, expected membership {1}; observed {2}.' -f $verification.Attempts, $ExpectedMember, $verification.ObservedMember) -Data $evidence
    }
    catch {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary ('Pre-provisioning membership {0} or verification failed.' -f $changeName) -Notes $_.Exception.Message -Data $evidence
    }
}

function Invoke-StepAddPreProvisioningGroup {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    return Invoke-PreProvisioningMembershipChange -Device $Device -StepDefinition $StepDefinition -ExpectedMember $true
}

function Invoke-StepClearUserlessEnrollmentStatus {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    if ($Script:Runtime.IsDemoMode) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated userless-enrolment unblock completed.' -Notes 'Demo mode cleared the userless-enrolment status gate.' -Data @{}
    }

    try {
        [void](Resolve-LiveAutopilotContext -Device $Device)
        if (-not $Device.AutopilotDeviceId) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Autopilot device context is required before clearing Userless Enrolment Status.' -Notes 'Run the resolve step first so the Autopilot device identity is available.' -Data @{}
        }

        Invoke-GraphApiRequest -Method 'POST' -Uri ('https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities/{0}/allowNextEnrollment' -f $Device.AutopilotDeviceId) | Out-Null
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Userless-enrolment unblock was submitted but cannot be Graph-verified.' -Notes ('Invoked allowNextEnrollment for Autopilot device {0}. Verify Allowed in Intune before retrying Autopilot.' -f $Device.AutopilotDeviceId) -Data @{ AutopilotDeviceId = $Device.AutopilotDeviceId }
    }
    catch {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Failed to clear Userless Enrolment Status block.' -Notes $_.Exception.Message -Data @{ AutopilotDeviceId = $Device.AutopilotDeviceId }
    }
}

function Invoke-StepConfirmRecoveryReadiness {
    <#
    .SYNOPSIS
        Confirms checklist recovery readiness without claiming Graph status proof.
    .DESCRIPTION
        Requires a current-cycle unblock submission, the checklist two-minute
        wait and a valid empty managed-device search. The technician then checks
        Allowed in Intune and confirms physical reset/reimage. No reset is sent
        remotely. Only successful close-out permits the writer to restart steps.
    .PARAMETER Device
        Active recovery record with persisted unblock evidence.
    .PARAMETER StepDefinition
        Conditional recovery close-out manifest action.
    .OUTPUTS
        Blocked, Submitted, Failed, TechnicianConfirmed or Simulated result.
    #>
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    $evidence = @{ Serial = $Device.Serial; ChecklistVersion = '1.4'; ChecklistSteps = @(12); ConfirmationDefault = 'Y' }
    try {
        $unblockStepId = Get-ManifestActionStepId -ActionName 'ClearUserlessEnrollmentStatus'
        $cleanupStepId = Get-ManifestActionStepId -ActionName 'RemoveAssociatedManagedDevice'
        $unblock = $Device.Steps[$unblockStepId]
        if ($null -eq $unblock -or $unblock.CompletionState -notin @('Submitted', 'Simulated')) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary ('Submit the recovery unblock action {0} first.' -f $unblockStepId) -Notes 'A previous completed recovery is not evidence for this recovery cycle.' -Data $evidence
        }
        if (-not $Script:Runtime.IsDemoMode) {
            $submittedAt = ConvertTo-RecordDate -Value $unblock.Timestamp
            $startedAt = ConvertTo-RecordDate -Value $Device.RecoveryStartedAt
            $now = Get-Date
            if ($submittedAt -eq [DateTime]::MinValue -or $startedAt -eq [DateTime]::MinValue -or $submittedAt -lt $startedAt) {
                throw ('Current-cycle unblock timestamp is missing or invalid. Submit {0} again before confirming recovery.' -f $unblockStepId)
            }
            $elapsedSeconds = ($now - $submittedAt).TotalSeconds
            if ($elapsedSeconds -lt 120) {
                return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary 'The checklist two-minute wait is not yet complete.' -Notes ('Wait at least two minutes after {0}, then refresh the Autopilot device in Intune and return here.' -f $unblockStepId) -Data $evidence
            }
            $remaining = Resolve-LiveManagedDeviceBySerial -Serial $Device.Serial
            if ($null -ne $remaining) {
                return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary 'An associated Intune device still exists.' -Notes ('Use {0} to delete and verify removal before closing recovery. No additional delete was issued.' -f $cleanupStepId) -Data $evidence
            }
        }
        Write-Host 'Checklist step 12: press Reset after the Autopilot failure and reimage using the approved Windows USB guide.'
        Write-Host 'Confirm the associated Intune device is deleted. After the two-minute wait, refresh Windows Autopilot Devices and verify Userless Enrollment Status displays Allowed.'
        Write-Host 'Do not proceed if it displays Not Allowed. Record the error and return to recovery; no remote reset or reimage is performed by this script.'
        $confirmed = Read-ValidatedInput -Prompt 'Have reset/reimage completed and Allowed been confirmed in Intune? (Y/N)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
        if ($confirmed.ToUpper() -ne 'Y') {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Recovery readiness remains unconfirmed.' -Notes 'Recovery mode and prior step evidence are retained.' -Data $evidence
        }
        $evidence.ManagedDeviceAbsent = $true
        $evidence.AllowedEvidence = if ($Script:Runtime.IsDemoMode) { 'Simulated' } else { 'TechnicianConfirmedInIntune' }
        $evidence.ConfirmedBy = $env:USERNAME
        $state = if ($Script:Runtime.IsDemoMode) { 'Simulated' } else { 'TechnicianConfirmed' }
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState $state -Summary ('Recovery readiness confirmed; restart preparation from {0}.' -f $cleanupStepId) -Notes 'Prior results are archived. Recheck deletion, Group Tag, group membership and physical build milestones.' -Data $evidence
    }
    catch {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Recovery readiness check failed.' -Notes $_.Exception.Message -Data $evidence
    }
}

function Invoke-StepAssignTechnicianPrimaryUser {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    $technicianUpn = $Script:GraphSession.Account
    $technicianUser = [ordered]@{
        Id                = [string]$Script:GraphSession.UserId
        DisplayName       = [string]$Script:GraphSession.DisplayName
        UserPrincipalName = [string]$technicianUpn
        AccountEnabled    = $true
    }
    $eligibilityMessage = Get-DirectoryUserEligibilityMessage -User $technicianUser

    if (-not [string]::IsNullOrWhiteSpace($eligibilityMessage)) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'The authenticated technician account is not permitted for technician-primary-user assignment.' -Notes ('Current account {0} does not match the configured prefixes: {1}' -f $technicianUpn, ((Get-ConfiguredTechnicianPrefixes) -join ', ')) -Data @{}
    }

    $Device.TechnicianUserPrincipalName = $technicianUpn
    if ($Script:Runtime.IsDemoMode) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated technician primary-user assignment completed.' -Notes ('Demo mode assigned technician {0} on both Autopilot and managed-device surfaces.' -f $technicianUpn) -Data @{ Technician = $technicianUpn; AutopilotAssigned = $true; ManagedDeviceAssigned = $true }
    }

    $assignment = Invoke-LivePrimaryUserAssignment -Device $Device -User $technicianUser
    if (-not $assignment.AnyAssignmentApplied) {
        $completionState = if ($assignment.Errors.Count -gt 0) { 'Failed' } else { 'Blocked' }
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState $completionState -Summary 'No technician primary-user assignment was verified or submitted.' -Notes ((@($assignment.Notes) + @($assignment.Errors)) -join ' ') -Data @{ Technician = $technicianUpn }
    }

    if ($assignment.Errors.Count -gt 0) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Technician primary-user assignment failed.' -Notes ((@($assignment.Notes) + @($assignment.Errors)) -join ' ') -Data @{ Technician = $technicianUpn; AutopilotAssigned = $assignment.AutopilotAssigned; ManagedDeviceAssigned = $assignment.ManagedDeviceAssigned }
    }

    if ($assignment.AutopilotAssigned -and $assignment.ManagedDeviceAssigned -and -not $assignment.ManagedDeviceConfirmed) {
        $confirmed = Read-ValidatedInput -Prompt 'Managed-device primary-user update was submitted. Has Intune reflected the technician yet? (Y/N)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
        $success = $confirmed.ToUpper() -eq 'Y'
        $completionState = if ($success) { 'TechnicianConfirmed' } else { 'Submitted' }
        $summary = if ($success) { 'Technician primary-user assignment confirmed manually, not Graph-verified.' } else { 'Technician primary-user assignment submitted but not yet confirmed.' }
        $notes = @($assignment.Notes)
        $notes += ('Technician confirmation: {0}' -f $confirmed.ToUpper())
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $success -CompletionState $completionState -Summary $summary -Notes ($notes -join ' ') -Data @{ Technician = $technicianUpn; AutopilotAssigned = $assignment.AutopilotAssigned; ManagedDeviceAssigned = $assignment.ManagedDeviceAssigned; ManagedDeviceConfirmed = $assignment.ManagedDeviceConfirmed }
    }

    $success = $assignment.AutopilotAssigned -and $assignment.ManagedDeviceConfirmed
    $completionState = if ($success) { 'Verified' } else { 'Submitted' }
    $summary = if ($success) { 'Technician primary-user assignment verified on both surfaces.' } else { 'Technician primary-user assignment is awaiting complete read-back verification.' }
    return New-OperationResult -ActionName $StepDefinition.ActionName -Success $success -CompletionState $completionState -Summary $summary -Notes (@($assignment.Notes) -join ' ') -Data @{ Technician = $technicianUpn; AutopilotAssigned = $assignment.AutopilotAssigned; ManagedDeviceAssigned = $assignment.ManagedDeviceAssigned; ManagedDeviceConfirmed = $assignment.ManagedDeviceConfirmed }
}

function Get-SyncSubmissionReceiptPath {
    <#
    .SYNOPSIS
        Locate one record's receipt in the actively reserved data root.
    .PARAMETER RecordId
        Non-empty alphanumeric/hyphen identifier; never a relative path.
    .OUTPUTS
        Receipt path, independent of the workflow records file.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$RecordId)
    if ($RecordId -cnotmatch '\A[A-Za-z0-9-]+\z') { throw 'Sync receipt RecordId must contain only letters, digits and hyphens.' }
    Assert-ActiveStorageReservation
    return (Join-Path $Script:Storage.DataPath ('sync-submission-{0}.json' -f $RecordId))
}

function Get-SyncSubmissionReceipt {
    <#
    .SYNOPSIS
        Read a recovery-checked receipt without retargeting accepted evidence.
    .PARAMETER Path
        Per-record receipt path under the current reservation.
    .PARAMETER Target
        Refreshed RecordId, Serial, ManagedDeviceId and optional TenantId.
    .OUTPUTS
        Validated receipt dictionary, or null when no receipt exists.
    #>
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][hashtable]$Target)
    Assert-FileWriteRecoveryState -Path $Path
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $jsonParameters = @{ ErrorAction = 'Stop' }
    $parserParameters = (Get-Command ConvertFrom-Json).Parameters
    if ($parserParameters.ContainsKey('DateKind')) { $jsonParameters.DateKind = 'String' }
    if ($parserParameters.ContainsKey('NoEnumerate')) { $jsonParameters.NoEnumerate = $true }
    $receipt = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json @jsonParameters
    if ($null -eq $receipt -or $receipt -isnot [pscustomobject]) { throw 'Sync receipt must be a JSON object.' }
    $evidence = @{}
    foreach ($field in @('RecordId', 'Serial', 'ManagedDeviceId', 'SubmittedAt')) {
        $value = $receipt.PSObject.Properties[$field].Value
        if ($value -isnot [string] -or [string]::IsNullOrWhiteSpace($value)) { throw ('Sync receipt {0} must be a non-empty string.' -f $field) }
        $evidence[$field] = $value
    }
    if ($evidence.RecordId -cnotmatch '\A[A-Za-z0-9-]+\z') { throw 'Sync receipt RecordId is unsafe.' }
    $submittedAt = [DateTimeOffset]::MinValue
    if ($evidence.SubmittedAt -notmatch '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{7}(Z|[+-]\d{2}:\d{2})\z' -or
        -not [DateTimeOffset]::TryParse($evidence.SubmittedAt, [ref]$submittedAt)) { throw 'Sync receipt SubmittedAt must be an ISO round-trip timestamp.' }
    $tenantProperty = $receipt.PSObject.Properties['TenantId']
    if ($null -ne $tenantProperty) {
        if ($tenantProperty.Value -isnot [string] -or [string]::IsNullOrWhiteSpace($tenantProperty.Value)) { throw 'Sync receipt TenantId must be a non-empty string when present.' }
        $evidence.TenantId = $tenantProperty.Value
    }
    foreach ($field in @('RecordId', 'Serial', 'ManagedDeviceId')) {
        if ($evidence[$field] -cne $Target[$field]) { throw ('Sync receipt target changed ({0}); no sync or confirmation is permitted. Review the original submission.' -f $field) }
    }
    if ($Target.ContainsKey('TenantId') -and $evidence.TenantId -cne $Target.TenantId) {
        throw 'Sync receipt target changed (TenantId); no sync or confirmation is permitted. Review the original submission.'
    }
    return $evidence
}

function Invoke-StepRetryFailedApps {
    <#
    .SYNOPSIS
        Submit sync once per record, then collect technician outcome separately.
    .DESCRIPTION
        A receipt is saved immediately after acceptance and before input. Existing
        receipts permit confirmation only. A persistence failure stops further sync
        in this process; it cannot guarantee durability after process loss. Death
        between POST acceptance and the first save remains an unavoidable gap.
    .PARAMETER Device
        Workflow record whose managed-device identity is refreshed before use.
    .PARAMETER StepDefinition
        RetryFailedApplications manifest action.
    .OUTPUTS
        Submitted accepted evidence, TechnicianConfirmed, Failed or Simulated.
    #>
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    if ($Script:Runtime.IsDemoMode) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated app retry completed.' -Notes 'Demo mode simulated Intune app remediation and retry.' -Data @{}
    }

    $evidence = @{}
    $accepted = $false
    $stopVariable = Get-Variable -Name SyncSubmissionPersistenceFailure -Scope Script -ErrorAction SilentlyContinue
    if ($null -ne $stopVariable -and $stopVariable.Value) {
        throw 'Further sync is stopped: an accepted submission has an unresolved durable receipt gap. Review tenant state and storage before restarting; do not automatically retry.'
    }
    try {
        [void](Resolve-LiveAutopilotContext -Device $Device)
        if (-not $Device.ManagedDeviceId) {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Managed device context is required before retrying app installations.' -Notes 'Resolve the device first, or confirm the managed device exists in Intune.' -Data @{}
        }

        foreach ($field in @('RecordId', 'Serial', 'ManagedDeviceId')) {
            if ($Device[$field] -isnot [string] -or [string]::IsNullOrWhiteSpace($Device[$field])) { throw ('Sync target {0} must be a non-empty string.' -f $field) }
            $evidence[$field] = $Device[$field]
        }
        $sessionVariable = Get-Variable -Name GraphSession -Scope Script -ErrorAction SilentlyContinue
        if ($null -ne $sessionVariable -and $sessionVariable.Value.Contains('TenantId')) {
            $tenantId = $sessionVariable.Value['TenantId']
            if ($null -ne $tenantId -and $tenantId -cne '') {
                if ($tenantId -isnot [string] -or [string]::IsNullOrWhiteSpace($tenantId)) { throw 'Sync target TenantId must be a non-empty string when present.' }
                $evidence.TenantId = $tenantId
            }
        }
        $receiptPath = Get-SyncSubmissionReceiptPath -RecordId $Device.RecordId
        $receipt = Get-SyncSubmissionReceipt -Path $receiptPath -Target $evidence
        if ($null -ne $receipt) {
            $evidence = $receipt
            $accepted = $true
            $evidence.ReceiptPersisted = $true
        }
        else {
            Invoke-GraphApiRequest -Method 'POST' -Uri ('https://graph.microsoft.com/v1.0/deviceManagement/managedDevices/{0}/syncDevice' -f $Device.ManagedDeviceId) | Out-Null
            $accepted = $true
            $evidence.SyncAccepted = $true
            $evidence.SubmittedAt = Get-Date -Format o
            try {
                Write-Utf8File -Path $receiptPath -Content ($evidence | ConvertTo-Json -Compress)
                $evidence.ReceiptPersisted = $true
            }
            catch {
                $Script:SyncSubmissionPersistenceFailure = $true
                $evidence.ReceiptPersisted = $false
                $evidence.DurableGap = $true
                return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Sync was accepted, but durable receipt persistence failed. Further sync is stopped.' -Notes ('Do not automatically retry. Review tenant state and retained storage artefacts; durability across restart is unknown. Detail: {0}' -f $_.Exception.Message) -Data $evidence
            }
        }
        $evidence.SyncAccepted = $true
        $confirmed = Read-ValidatedInput -Prompt 'Was the failed application retry/remediation successful? (Y/N)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
        $isConfirmed = $confirmed.ToUpper() -eq 'Y'
        $completionState = if ($isConfirmed) { 'TechnicianConfirmed' } else { 'Submitted' }
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $isConfirmed -CompletionState $completionState -Summary 'Accepted sync; app outcome recorded separately, not Graph-verified.' -Notes ('Accepted syncDevice for managed device {0} at {1}; technician confirmation {2}. No additional sync was issued for an existing receipt.' -f $evidence.ManagedDeviceId, $evidence.SubmittedAt, $confirmed.ToUpper()) -Data $evidence
    }
    catch {
        $state = if ($accepted) { 'Submitted' } else { 'Failed' }
        $evidence.SyncAccepted = $accepted
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState $state -Summary 'Managed-device sync or outcome confirmation did not complete.' -Notes $_.Exception.Message -Data $evidence
    }
}

function Invoke-StepRemovePreProvisioningGroup {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    return Invoke-PreProvisioningMembershipChange -Device $Device -StepDefinition $StepDefinition -ExpectedMember $false
}

function Invoke-StepAssignFinalPrimaryUser {
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    $selectedUser = Select-DirectoryUser
    if (-not $selectedUser) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Final primary-user selection was cancelled.' -Notes 'No user was selected.' -Data @{}
    }

    $Device.FinalPrimaryUserId = [string]$selectedUser.Id
    $Device.FinalPrimaryUserPrincipalName = [string]$selectedUser.UserPrincipalName
    $Device.FinalPrimaryUserDisplayName = [string]$selectedUser.DisplayName
    Add-RecentUser -User $selectedUser

    if ($Script:Runtime.IsDemoMode) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -Summary 'Simulated final primary-user assignment completed.' -Notes ('Demo mode assigned final primary user {0} on both Autopilot and managed-device surfaces.' -f $selectedUser.UserPrincipalName) -Data @{ FinalPrimaryUser = $selectedUser.UserPrincipalName; AutopilotAssigned = $true; ManagedDeviceAssigned = $true }
    }

    $assignment = Invoke-LivePrimaryUserAssignment -Device $Device -User $selectedUser
    if (-not $assignment.AnyAssignmentApplied) {
        $completionState = if ($assignment.Errors.Count -gt 0) { 'Failed' } else { 'Blocked' }
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState $completionState -Summary 'No final primary-user assignment was verified or submitted.' -Notes ((@($assignment.Notes) + @($assignment.Errors)) -join ' ') -Data @{ FinalPrimaryUser = $selectedUser.UserPrincipalName }
    }

    if ($assignment.Errors.Count -gt 0) {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Final primary-user assignment failed.' -Notes ((@($assignment.Notes) + @($assignment.Errors)) -join ' ') -Data @{ FinalPrimaryUser = $selectedUser.UserPrincipalName; AutopilotAssigned = $assignment.AutopilotAssigned; ManagedDeviceAssigned = $assignment.ManagedDeviceAssigned }
    }

    if ($assignment.AutopilotAssigned -and $assignment.ManagedDeviceAssigned -and -not $assignment.ManagedDeviceConfirmed) {
        $confirmed = Read-ValidatedInput -Prompt 'Managed-device primary-user update was submitted. Has Intune reflected the final user yet? (Y/N)' -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
        $success = $confirmed.ToUpper() -eq 'Y'
        $completionState = if ($success) { 'TechnicianConfirmed' } else { 'Submitted' }
        $summary = if ($success) { 'Final primary-user assignment confirmed by technician, not Graph-verified.' } else { 'Final primary-user assignment submitted but not yet confirmed.' }
        $notes = @($assignment.Notes)
        $notes += ('Technician confirmation: {0}' -f $confirmed.ToUpper())
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $success -CompletionState $completionState -Summary $summary -Notes ($notes -join ' ') -Data @{ FinalPrimaryUser = $selectedUser.UserPrincipalName; AutopilotAssigned = $assignment.AutopilotAssigned; ManagedDeviceAssigned = $assignment.ManagedDeviceAssigned; ManagedDeviceConfirmed = $assignment.ManagedDeviceConfirmed }
    }

    $success = $assignment.AutopilotAssigned -and $assignment.ManagedDeviceConfirmed
    $completionState = if ($success) { 'Verified' } else { 'Submitted' }
    $summary = if ($success) { 'Final primary-user assignment verified on both surfaces.' } else { 'Final primary-user assignment is awaiting complete read-back verification.' }
    return New-OperationResult -ActionName $StepDefinition.ActionName -Success $success -CompletionState $completionState -Summary $summary -Notes (@($assignment.Notes) -join ' ') -Data @{ FinalPrimaryUser = $selectedUser.UserPrincipalName; AutopilotAssigned = $assignment.AutopilotAssigned; ManagedDeviceAssigned = $assignment.ManagedDeviceAssigned; ManagedDeviceConfirmed = $assignment.ManagedDeviceConfirmed }
}

function Invoke-StepConfirmPhysicalMilestone {
    <#
    .SYNOPSIS
        Guides and records a technician-observed physical milestone.
    .DESCRIPTION
        Instructions follow checklist v1.4 steps 6-10, 13-14 and 17-22. Confirmation
        defaults to Y by operator decision, but never claims Graph verification.
        The standard step writer persists evidence and preserves resume behaviour.
    .PARAMETER Device
        Workflow record for the device being physically prepared.
    .PARAMETER StepDefinition
        Manifest definition for pre-provisioning or post-login device work.
    .OUTPUTS
        TechnicianConfirmed, Submitted or Simulated operation result.
    #>
    param([Parameter(Mandatory)]$Device, [Parameter(Mandatory)]$StepDefinition)

    switch ($StepDefinition.ActionName) {
        'ConfirmImagingAndOobe' {
            $checklistSteps = @(6, 7, 8, 9, 10)
            $instructions = @(
                'Connect the device to the network. For a laptop, use the Dell docking station required by the checklist.',
                'Install Windows 11 using the approved bootable USB guide and allow imaging to restart the device.',
                'Set the correct country/region and keyboard if prompted; skip a second keyboard layout.',
                'At the work or school setup screen, press the Windows key five times.',
                'Choose Pre-provision with Windows Autopilot, then Next. Wait for the deployment-profile screen; validate it in step D before proceeding.'
            )
            $confirmation = 'Has the device reached the Autopilot deployment-profile screen? (Y/N)'
        }
        'ConfirmReseal' {
            $checklistSteps = @(13)
            $instructions = @(
                'Wait for preparation and setup to complete successfully.',
                'If setup fails, do not confirm reseal: return to the workflow and record the failure using recovery option X.',
                'At Your device setup is complete, select Reseal and wait for the device to shut down.'
            )
            $confirmation = 'Did successful pre-provisioning finish with reseal and shutdown? (Y/N)'
        }
        'ConfirmBootToSignIn' {
            $checklistSteps = @(14)
            $instructions = @(
                'Power up the resealed device and allow Setting up for work or school to finish.',
                'If an error appears at this stage, the checklist directs Continue Anyway. Record any error details for troubleshooting.',
                'Leave the device at the Windows sign-in screen. Do not perform the first sign-in until technician assignment and group removal are complete.'
            )
            $confirmation = 'Is the device now at the Windows sign-in screen? (Y/N)'
        }
        'ConfirmFirstSignIn' {
            $checklistSteps = @(17)
            $instructions = @(
                'Confirm technician primary-user assignment and pre-provisioning group removal are complete.',
                'On the new device, sign in for the first time and wait for the Windows desktop to be ready.'
            )
            $confirmation = 'Has the first sign-in completed and reached the Windows desktop? (Y/N)'
        }
        'ConfirmApplicationBaseline' {
            $checklistSteps = @(18, 19)
            $instructions = @(
                'Open Company Portal on the new device and check every required application, including applications already installed by the USB image.',
                'Install only one application at a time, in this checklist order:',
                '1. Cortex XDR Windows x64.',
                '2. Office. For a shared device, install Office 2016 Pro Plus to replace the standard version.',
                '3. Microsoft .NET Desktop Runtime 8 8.0.21.35325 (dependency for Dell Command | Update).',
                '4. Dell Command | Update.',
                '5. Microsoft Edge WebView2 Runtime 142.0.3595.53 (dependency for Zenworks Agent).',
                '6. Zenworks Agent.',
                '7. Laptops only: Global Protect.',
                'If an installation fails, leave this milestone incomplete. The checklist directs Intune > Devices > device > Run Remediations > Retry failed app installation.',
                'Workflow step H requests a device sync; it does not invoke that named remediation. After troubleshooting, return here and verify every required application.'
            )
            $confirmation = 'Have all required applications been checked and installed successfully? (Y/N)'
        }
        'ConfirmUpdatesAndShutdown' {
            $checklistSteps = @(20, 21, 22)
            $instructions = @(
                'Run Dell Command | Update on the applicable device and install all required BIOS and driver updates.',
                'Complete any required reboots and recheck for remaining updates.',
                'Follow all other applicable procedures and documentation for this device, including Imprivata or host-name whitelisting where required.',
                'When updates, reboots and required procedures are complete, power off the device before final primary-user assignment.',
                'For a non-Dell device, follow the approved manufacturer procedure rather than attempting to install Dell firmware.'
            )
            $confirmation = 'Are required updates and procedures complete, and is the device powered off? (Y/N)'
        }
        default { throw ('Unsupported physical milestone action: {0}' -f $StepDefinition.ActionName) }
    }
    Write-Host ('Device {0}: {1}' -f $Device.Serial, $StepDefinition.DisplayName)
    foreach ($instruction in $instructions) { Write-Host ('- {0}' -f $instruction) }
    $confirmed = Read-ValidatedInput -Prompt $confirmation -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
    $evidence = @{ Serial = $Device.Serial; ChecklistVersion = '1.4'; ChecklistSteps = $checklistSteps; ConfirmedBy = $env:USERNAME; ConfirmationDefault = 'Y' }
    if ($confirmed.ToUpper() -ne 'Y') {
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Submitted' -Summary 'Physical milestone remains incomplete.' -Notes 'No completion was confirmed; return to this step when the device is ready.' -Data $evidence
    }
    $completionState = if ($Script:Runtime.IsDemoMode) { 'Simulated' } else { 'TechnicianConfirmed' }
    return New-OperationResult -ActionName $StepDefinition.ActionName -Success $true -CompletionState $completionState -Summary 'Physical milestone confirmed by the technician.' -Notes 'This records physical observation, not remote Graph verification. Demo confirmations remain simulated.' -Data $evidence
}

function Invoke-AutopilotManifestStep {
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)]$StepDefinition
    )

    if (-not $Script:Runtime.IsDemoMode) {
        try { $null = Get-LiveTenantBinding -Device $Device -AllowUnbound:($StepDefinition.ActionName -eq 'ResolveAutopilotDevice') }
        catch { return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary 'Tenant binding refused.' -Notes $_.Exception.Message -Data @{ Blocked = $true } }
    }
    $eligibility = Test-ManifestStepEligibility -Device $Device -StepDefinition $StepDefinition
    if (-not $eligibility.Eligible) {
        $notes = if ($eligibility.MissingStepIds.Count -gt 0) {
            'Complete prerequisite step(s) before this action: {0}.' -f ($eligibility.MissingStepIds -join ', ')
        }
        else {
            'Activate {0} before this action.' -f $eligibility.ActivationRequirement
        }
        return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -CompletionState 'Blocked' -Summary 'Workflow prerequisite not met.' -Notes $notes -Data @{ Blocked = $true; MissingStepIds = $eligibility.MissingStepIds; ActivationRequirement = $eligibility.ActivationRequirement }
    }

    switch ($StepDefinition.ActionName) {
        'ResolveAutopilotDevice' { return Invoke-StepResolveAutopilotDevice -Device $Device -StepDefinition $StepDefinition }
        'RemoveAssociatedManagedDevice' { return Invoke-StepRemoveAssociatedManagedDevice -Device $Device -StepDefinition $StepDefinition }
        'ApplyGroupTag' { return Invoke-StepApplyGroupTag -Device $Device -StepDefinition $StepDefinition }
        'ValidateDeploymentProfile' { return Invoke-StepValidateDeploymentProfile -Device $Device -StepDefinition $StepDefinition }
        'AddToPreProvisioningGroup' { return Invoke-StepAddPreProvisioningGroup -Device $Device -StepDefinition $StepDefinition }
        'ClearUserlessEnrollmentStatus' { return Invoke-StepClearUserlessEnrollmentStatus -Device $Device -StepDefinition $StepDefinition }
        'AssignTechnicianPrimaryUser' { return Invoke-StepAssignTechnicianPrimaryUser -Device $Device -StepDefinition $StepDefinition }
        'RetryFailedApplications' { return Invoke-StepRetryFailedApps -Device $Device -StepDefinition $StepDefinition }
        'RemoveFromPreProvisioningGroup' { return Invoke-StepRemovePreProvisioningGroup -Device $Device -StepDefinition $StepDefinition }
        'AssignFinalPrimaryUser' { return Invoke-StepAssignFinalPrimaryUser -Device $Device -StepDefinition $StepDefinition }
        'ConfirmImagingAndOobe' { return Invoke-StepConfirmPhysicalMilestone -Device $Device -StepDefinition $StepDefinition }
        'ConfirmReseal' { return Invoke-StepConfirmPhysicalMilestone -Device $Device -StepDefinition $StepDefinition }
        'ConfirmBootToSignIn' { return Invoke-StepConfirmPhysicalMilestone -Device $Device -StepDefinition $StepDefinition }
        'ConfirmFirstSignIn' { return Invoke-StepConfirmPhysicalMilestone -Device $Device -StepDefinition $StepDefinition }
        'ConfirmApplicationBaseline' { return Invoke-StepConfirmPhysicalMilestone -Device $Device -StepDefinition $StepDefinition }
        'ConfirmUpdatesAndShutdown' { return Invoke-StepConfirmPhysicalMilestone -Device $Device -StepDefinition $StepDefinition }
        'ConfirmRecoveryReadiness' { return Invoke-StepConfirmRecoveryReadiness -Device $Device -StepDefinition $StepDefinition }
        default {
            return New-OperationResult -ActionName $StepDefinition.ActionName -Success $false -Summary 'Manifest action is not yet implemented.' -Notes ('No step handler exists for action {0}.' -f $StepDefinition.ActionName) -Data @{}
        }
    }
}

function Show-ChecklistHandoffGuide {
    <#
    .SYNOPSIS
        Display checklist v1.4 steps 24-26 after final Intune ownership completes.
    .DESCRIPTION
        Provides read-only external handoff guidance. It does not update ZENworks,
        CMDB or device state, collect confirmation, or change completion/dispatch gates.
        The technician performs these actions using the approved external procedures.
    .PARAMETER Device
        Workflow record used only to display device identity and captured Intune name.
    #>
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()]$Device)
    Write-Host ''
    Write-Host 'Remaining checklist handoffs (v1.4, steps 24-26)'
    Write-Host ('Device serial: {0}; Configuration Item: {1}; site: {2}' -f $Device.Serial, $Device.ConfigItem, $Device.SiteCode)
    if ($Device.IntuneDeviceName) { Write-Host ('Captured Intune device name: {0}' -f $Device.IntuneDeviceName) }
    $instructions = @(
        '24. ZENworks: find the replaced device under Devices > Device List and use Actions > Copy Relationships to copy its relationships to the new device.',
        'If there is no replaced device, use an existing device at the installation location that performs the same or similar activities as the relationship source.',
        '25. CMDB: find the record by device name or service tag; create a record if neither search finds it.',
        'For a new CMDB record, use the full device name shown in Intune. Use only the numbers from the Configuration Item sticker in the CMDB CI field; this guide does not change the stored CI.',
        'Check Assigned to against the approved recipient: the checklist specifies the assigned caregiver E number or, for a shared device, the Unit/Area Manager. The CLI does not infer roles or select this CMDB recipient.',
        'Check site, the full department or ward name (not an acronym), and Floor-Room with building, floor, room number where displayed, and room name or descriptor.',
        'If the replaced device is being decommissioned or disposed of, link that old device to the new device in the Downstream CI tab.',
        '26. Coordinate installation with the caregiver or manager. When replacing a device for decommissioning or disposal, collect the old device at the same time as installing the new one.',
        'Do not install the replacement until the old device can be collected, and do not leave a device awaiting decommissioning or disposal with the caregiver.',
        'Complete every applicable disposal/decommissioning procedure for the collected device before close of business on the current business day.',
        'Guidance only: no external updates or handoff confirmations are recorded here. Intune workflow completion and bench dispatch do not certify these handoffs or physical deployment.'
    )
    foreach ($instruction in $instructions) { Write-Host ('- {0}' -f $instruction) }
}

function Write-ManifestStepResult {
    <#
    .SYNOPSIS
        Append detached outcome evidence before replacing current workflow state.
    .DESCRIPTION
        History survives retries, dependency invalidation and recovery step resets.
        Legacy evidence retains its recorded timestamp, or null when unknown.
        This records handler outcomes only, not interrupted executions or save durability.
    .PARAMETER Device
        Mutable workflow record whose history owns independent normalised snapshots.
    .PARAMETER StepDefinition
        Manifest identity for the completed handler invocation.
    .PARAMETER Result
        Complete handler outcome, including blocked and unsuccessful results.
    #>
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)]$StepDefinition,
        [Parameter(Mandatory)]$Result
    )

    function Add-ManifestAttemptSnapshot {
        <#
        .SYNOPSIS
            Append a deep copy of supplied evidence with record identity and sequence.
        .PARAMETER StepId
            Step owning the evidence; unrelated historical entries are never changed.
        .PARAMETER Evidence
            Complete handler result or untouched legacy step evidence.
        .PARAMETER Legacy
            Preserve prior evidence once without inventing its execution timestamp.
        .OUTPUTS
            None. Appends one independent snapshot to the enclosing device record.
        #>
        param([Parameter(Mandatory)][string]$StepId, [Parameter(Mandatory)]$Evidence, [switch]$Legacy)
        if ($Legacy -and @($Device.AttemptHistory | Where-Object { $_.StepId -eq $StepId }).Count -gt 0) { return }
        $snapshot = ConvertTo-NormalisedValue -Value $Evidence
        $timestamp = Get-Date -Format o
        $actor = [string]$env:USERNAME
        $mode = [string]$Script:Runtime.ModeDisplayName
        if ($Legacy) {
            $timestamp = $null
            if ($null -ne $snapshot.Timestamp) {
                $recordedTimestamp = $snapshot.Timestamp
                if ($recordedTimestamp -is [System.Collections.IDictionary]) { $recordedTimestamp = $recordedTimestamp.value }
                $recordedDate = Get-Date -Date $recordedTimestamp -ErrorAction Stop
                if ($recordedDate -ne [DateTime]::MinValue) { $timestamp = Get-Date -Date $recordedDate -Format o }
            }
            $actor = ''
            $mode = [string]$snapshot.Mode
        }
        $actionName = [string]$snapshot.ActionName
        if (-not $Legacy) { $actionName = [string]$StepDefinition.ActionName }
        $Device.AttemptHistory = @($Device.AttemptHistory) + , @{
            Sequence = $Device.AttemptHistory.Count + 1; AttemptId = [guid]::NewGuid().Guid
            StepId = $StepId; ActionName = $actionName; Actor = $actor; Timestamp = $timestamp
            Mode = $mode; TenantId = [string]$Device.TenantId; Serial = [string]$Device.Serial; RecordId = [string]$Device.RecordId
            EvidenceKind = if ($Legacy) { 'LegacyEvidence' } else { 'HandlerOutcome' }
            Result = $snapshot
        }
    }

    if (-not $Script:Runtime.IsDemoMode -and $Result.CompletionState -eq 'Verified') {
        $Result = New-OperationResult -ActionName $StepDefinition.ActionName -Success ([bool]$Result.Success) -CompletionState Verified -Summary $Result.Summary -Notes $Result.Notes -Data $Result.Data
    }
    if (-not $Device.Contains('AttemptHistory')) { $Device['AttemptHistory'] = @() }
    if ($Device.AttemptHistory -isnot [array]) { throw 'Attempt history must be an array; evidence cannot be discarded.' }
    if ($null -ne $Device.Steps[$StepDefinition.Id]) {
        Add-ManifestAttemptSnapshot -StepId $StepDefinition.Id -Evidence $Device.Steps[$StepDefinition.Id] -Legacy
    }
    Add-ManifestAttemptSnapshot -StepId $StepDefinition.Id -Evidence $Result
    if ($Result.Data -is [System.Collections.IDictionary] -and $Result.Data['Blocked']) { return }
    if ($Result.Success -and $StepDefinition.ActionName -eq 'ConfirmRecoveryReadiness') {
        $identityStepId = Get-ManifestActionStepId -ActionName 'ResolveAutopilotDevice'
        $unblockStepId = Get-ManifestActionStepId -ActionName 'ClearUserlessEnrollmentStatus'
        $retainedSteps = @{}
        foreach ($retainedStepId in @($identityStepId, $unblockStepId)) {
            if ($Device.Steps.Contains($retainedStepId)) { $retainedSteps[$retainedStepId] = $Device.Steps[$retainedStepId] }
        }
        $Device.RecoveryHistory = @($Device.RecoveryHistory) + , @{
            Stage = 'RecoveryClosed'; Timestamp = Get-Date -Format o; Actor = $env:USERNAME
            Reason = $Device.RecoveryReason; Steps = ConvertTo-NormalisedValue -Value $Device.Steps
        }
        $Device.Steps = $retainedSteps
        $Device.ManagedDeviceId = ''
        $Device.IntuneDeviceName = ''
        $Device.TechnicianUserPrincipalName = ''
        $Device.FinalPrimaryUserId = ''
        $Device.FinalPrimaryUserPrincipalName = ''
        $Device.FinalPrimaryUserDisplayName = ''
        $Device.Status = 'in-progress'
        $Device.CompletedAt = [DateTime]::MinValue
        $Device.CompletedBy = ''
        $Device.IsCompletionVerified = $false
    }
    $stepWasPreviouslyCompleted = Test-ManifestStepCompleted -Device $Device -StepId $StepDefinition.Id

    if ($stepWasPreviouslyCompleted -and $StepDefinition.ActionName -ne 'ConfirmRecoveryReadiness') {
        $affectedStepIds = @($StepDefinition.Id)
        $definitions = @(Get-EnabledManifestSteps)
        do {
            $addedDependency = $false
            foreach ($definition in $definitions) {
                if ($definition.Id -in $affectedStepIds) { continue }
                if (@($definition.PrerequisiteStepIds | Where-Object { $_ -in $affectedStepIds }).Count -gt 0) {
                    $affectedStepIds += $definition.Id
                    $addedDependency = $true
                }
            }
        } while ($addedDependency)
        foreach ($stepId in $affectedStepIds) {
            if ($stepId -eq $StepDefinition.Id -or $null -eq $Device.Steps[$stepId]) { continue }
            $dependentEvidence = $Device.Steps[$stepId]
            Add-ManifestAttemptSnapshot -StepId $stepId -Evidence $dependentEvidence -Legacy
            if ($dependentEvidence.CompletionState -ne 'Blocked') { $dependentEvidence['PreviousCompletionState'] = $dependentEvidence.CompletionState }
            $dependentEvidence['CompletionState'] = 'Blocked'
            $dependentEvidence['Completed'] = $false
            $dependentEvidence['Success'] = $false
            $dependentEvidence['InvalidatedBy'] = $StepDefinition.Id
            $dependentEvidence['InvalidatedAt'] = Get-Date -Format o
        }
    }

    $Device.Steps[$StepDefinition.Id] = @{
        Completed       = (Test-CompletionStateComplete -CompletionState $Result.CompletionState)
        Success         = $Result.Success
        CompletionState = $Result.CompletionState
        Timestamp       = Get-Date
        Summary         = $Result.Summary
        Notes           = $Result.Notes
        Mode            = $Script:Runtime.ModeDisplayName
        ActionName      = $Result.ActionName
        IsSimulated     = $Result.IsSimulated
        Data            = ConvertTo-NormalisedValue -Value $Result.Data
    }

    if ($Result.Success -and $Device.Status -eq 'new') { $Device.Status = 'in-progress' }
    if ($Result.Success -and $StepDefinition.ActionName -eq 'ConfirmRecoveryReadiness') {
        $Device.RecoveryActive = $false
        $Device.RecoveryReason = ''
    }
    $Device.LastUpdatedAt = Get-Date
    $Device.LastUpdatedBy = $env:USERNAME

    if ((Test-DeviceReadyForDispatch -Device $Device).Ready) {
        $Device.Status = 'completed'
        if (-not $Device.CompletedAt -or $Device.CompletedAt -eq [DateTime]::MinValue) { $Device.CompletedAt = Get-Date }
        if (-not $Device.CompletedBy) { $Device.CompletedBy = $env:USERNAME }
    }
    elseif ($Device.Status -eq 'completed') {
        $Device.Status = 'in-progress'
        $Device.CompletedAt = [DateTime]::MinValue
        $Device.CompletedBy = ''
        $Device.IsCompletionVerified = $false
    }
    if ($StepDefinition.ActionName -eq 'AssignFinalPrimaryUser' -and $Result.Success -and (Test-CompletionStateComplete -CompletionState $Result.CompletionState)) {
        Show-ChecklistHandoffGuide -Device $Device
    }
}

function New-BuildBench {
    param([int]$Positions)
    if ($Positions -lt 1 -or $Positions -gt 50) { Write-Host 'Positions must be between 1 and 50.'; return }
    $Script:BuildBench.Positions = @(); for ($i = 1; $i -le $Positions; $i++) { $Script:BuildBench.Positions += [ordered]@{ Index = $i; Serial = $null; ConfigItem = $null } }
    $Script:BuildBench.Active = $true
    Write-AutopilotExpressLog -Message ('Build bench initialised with {0} positions.' -f $Positions) -Level 'INFO'
}

function Test-ManifestStepAttempted {
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)][string]$StepId
    )
    return $null -ne $Device.Steps[$StepId]
}

function Test-ManifestStepCompleted {
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)][string]$StepId
    )

    if (-not (Test-ManifestStepAttempted -Device $Device -StepId $StepId)) { return $false }
    $stepDefinition = Get-EnabledManifestSteps | Where-Object { $_.Id -eq $StepId } | Select-Object -First 1
    if ($stepDefinition.ActionName -eq 'ResolveAutopilotDevice' -and [string]::IsNullOrWhiteSpace($Device.AutopilotDeviceId)) { return $false }
    $stepRecord = $Device.Steps[$StepId]
    if ($null -eq $stepRecord) { return $false }

    if ($stepRecord -is [System.Collections.IDictionary]) {
        if ($null -ne $stepRecord['CompletionState']) { return Test-CompletionStateComplete -CompletionState ([string]$stepRecord['CompletionState']) }
        if ($null -ne $stepRecord['Completed']) { return [bool]$stepRecord['Completed'] }
        if ($null -ne $stepRecord['Success']) { return [bool]$stepRecord['Success'] }
    }

    if ($stepRecord.PSObject.Properties.Name -contains 'CompletionState' -and $null -ne $stepRecord.CompletionState) { return Test-CompletionStateComplete -CompletionState ([string]$stepRecord.CompletionState) }
    if ($stepRecord.PSObject.Properties.Name -contains 'Completed' -and $null -ne $stepRecord.Completed) { return [bool]$stepRecord.Completed }
    if ($stepRecord.PSObject.Properties.Name -contains 'Success' -and $null -ne $stepRecord.Success) { return [bool]$stepRecord.Success }
    return $false
}

function Test-CompletionStateComplete {
    param([Parameter(Mandatory)][string]$CompletionState)

    return $CompletionState -in @('Verified', 'TechnicianConfirmed', 'AuditedException', 'Simulated', 'LegacyCompleted')
}

function Get-NextStepId {
    param($Device)
    $nextEligibleStep = Get-EligibleManifestSteps -Device $Device | Select-Object -First 1
    if ($nextEligibleStep) { return $nextEligibleStep.Id }
    return $null
}

function Get-ManifestStepPrerequisiteIds {
    param([Parameter(Mandatory)]$StepDefinition)

    return @($StepDefinition.PrerequisiteStepIds)
}

function Test-ManifestStepEligibility {
    param(
        [Parameter(Mandatory)]$Device,
        [Parameter(Mandatory)]$StepDefinition
    )

    $missingStepIds = @(Get-ManifestStepPrerequisiteIds -StepDefinition $StepDefinition | Where-Object { -not (Test-ManifestStepCompleted -Device $Device -StepId $_) })
    $activationRequirement = [string]$StepDefinition.ActivationRequirement
    $activationSatisfied = $activationRequirement -eq 'None' -or ($activationRequirement -eq 'RecoveryMode' -and $Device.RecoveryActive)
    if ($Device.RecoveryActive -and $activationRequirement -eq 'None' -and $StepDefinition.ActionName -notin @('ResolveAutopilotDevice', 'RemoveAssociatedManagedDevice')) {
        $activationRequirement = 'RecoveryCloseOut'
        $activationSatisfied = $false
    }
    return [ordered]@{ Eligible = ($missingStepIds.Count -eq 0 -and $activationSatisfied); MissingStepIds = $missingStepIds; ActivationRequirement = $activationRequirement; ActivationSatisfied = $activationSatisfied }
}

function Enter-DeviceRecoveryMode {
    param([Parameter(Mandatory)]$Device)

    $identityStepId = Get-ManifestActionStepId -ActionName 'ResolveAutopilotDevice'
    $unblockStepId = Get-ManifestActionStepId -ActionName 'ClearUserlessEnrollmentStatus'
    $closeOutStepId = Get-ManifestActionStepId -ActionName 'ConfirmRecoveryReadiness'
    if (-not (Test-ManifestStepCompleted -Device $Device -StepId $identityStepId)) {
        Write-Host 'Resolve the Autopilot device before recording an Autopilot failure and entering recovery mode.'
        return
    }
    if ($Device.RecoveryActive) {
        Write-Host 'Recovery mode is already active for this device.'
        return
    }
    $confirmed = Read-ValidatedInput -Prompt 'Record an Autopilot failure and enter recovery mode? (Y/N)' -Default 'N' -Type 'Choice' -Choices @('Y', 'N')
    if ($confirmed.ToUpper() -ne 'Y') { return }
    $reason = Read-ValidatedInput -Prompt 'Recovery reason' -Default 'Autopilot failure reported by technician'
    $Device.RecoveryHistory = @($Device.RecoveryHistory) + , @{
        Stage = 'RecoveryEntered'; Timestamp = Get-Date -Format o; Actor = $env:USERNAME
        Reason = $reason; Steps = ConvertTo-NormalisedValue -Value $Device.Steps
    }
    $retainedSteps = @{}
    foreach ($stepId in $Device.Steps.Keys) {
        if ($stepId -notin @($unblockStepId, $closeOutStepId)) { $retainedSteps[$stepId] = $Device.Steps[$stepId] }
    }
    $Device.Steps = $retainedSteps
    $Device.RecoveryActive = $true
    $Device.RecoveryStartedAt = Get-Date
    $Device.RecoveryReason = $reason
    $Device.Status = 'in-progress'
    $Device.IsCompletionVerified = $false
    $Device.LastUpdatedAt = $Device.RecoveryStartedAt
    $Device.LastUpdatedBy = $env:USERNAME
    Write-AutopilotExpressLog -Message ('Recovery mode entered for Serial={0}: {1}' -f $Device.Serial, $reason) -Level 'WARN'
    Write-Host 'Recovery mode is active. Conditional recovery actions are now available.'
}

function Get-EligibleManifestSteps {
    param([Parameter(Mandatory)]$Device)

    return @(Get-EnabledManifestSteps | Where-Object {
            $awaitingRecoveryConfirmation = $Device.RecoveryActive -and $_.ActionName -eq 'ClearUserlessEnrollmentStatus' -and
            $Device.Steps[$_.Id].CompletionState -eq 'Submitted'
            -not $awaitingRecoveryConfirmation -and
            -not (Test-ManifestStepCompleted -Device $Device -StepId $_.Id) -and
            (Test-ManifestStepEligibility -Device $Device -StepDefinition $_).Eligible
        })
}

function Get-DispatchBlockingManifestSteps {
    param([Parameter(Mandatory)]$Device)

    return @(Get-EnabledManifestSteps | Where-Object {
            $isInactiveConditionalAction = $_.ActivationRequirement -eq 'RecoveryMode' -and -not $Device.RecoveryActive
            -not $isInactiveConditionalAction -and -not (Test-ManifestStepCompleted -Device $Device -StepId $_.Id)
        })
}

function Test-DeviceReadyForDispatch {
    param([Parameter(Mandatory)]$Device)

    $blockingSteps = @(Get-DispatchBlockingManifestSteps -Device $Device)
    return [ordered]@{ Ready = ($blockingSteps.Count -eq 0); BlockingStepIds = @($blockingSteps | ForEach-Object { $_.Id }) }
}

function Add-DeviceToBenchPosition {
    param([int]$Position, [string]$Serial, [string]$ConfigItem, [hashtable]$Records, [string]$SiteCode, [string]$DeviceType)
    $slot = $Script:BuildBench.Positions | Where-Object { $_.Index -eq $Position }; if (-not $slot) { Write-Host 'Invalid position.'; return }
    if ($slot.Serial) { Write-Host 'The selected bench position is occupied. Choose an empty position.'; return }
    if (@($Script:BuildBench.Positions | Where-Object { $_.Serial -eq $Serial }).Count -gt 0) {
        Write-Host 'This serial is already on the bench. Use Move to change its position.'
        return
    }
    $existing = @($Records.Value | Where-Object { $_.Serial -eq $Serial })
    if ($existing.Count -gt 1) { Write-Host 'Multiple workflow records match this serial. Resolve the duplicate records before induction.'; return }
    if ($existing.Count -eq 1) {
        if ($existing[0].Status -eq 'removed') { Write-Host 'This workflow record is removed. Restore its status before returning it to the bench.'; return }
        if ($existing[0].ConfigItem -ne $ConfigItem -or $existing[0].SiteCode -ne $SiteCode -or $existing[0].DeviceType -ne $DeviceType) {
            Write-Host 'Serial metadata differs from the existing workflow. Induct using its recorded Configuration Item, site and device type.'
            return
        }
    }
    if (@($Records.Value | Where-Object { $_.Serial -ne $Serial -and $_.ConfigItem -eq $ConfigItem -and $_.Status -ne 'removed' }).Count -gt 0) {
        Write-Host 'This Configuration Item belongs to another active workflow. Resolve the conflict before induction.'
        return
    }
    if ($existing.Count -eq 0) {
        $expectedTag = ('{0}-{1}' -f $SiteCode, ($DeviceType -replace '\s', ''))
        $rec = New-DeviceRecordObject -Serial $Serial -ConfigItem $ConfigItem -SiteCode $SiteCode -DeviceType $DeviceType -GroupTag $expectedTag
        Add-DeviceRecord -Records $Records -Record $rec
    }
    $slot.Serial = $Serial; $slot.ConfigItem = $ConfigItem
    Write-UserDeviceRecords -Records $Records.Value
}

function Remove-DeviceFromBenchPosition { param([int]$Position) $slot = $Script:BuildBench.Positions | Where-Object { $_.Index -eq $Position }; if (-not $slot) { Write-Host 'Invalid position.'; return }; $slot.Serial = $null; $slot.ConfigItem = $null }

# Ensure that any devices shown in the bench positions exist in the per-user records
function Assert-BenchPositionIdentity {
    <#
    .SYNOPSIS
        Reject ambiguous saved positions before serial or CI selection.
    .PARAMETER Positions
        Bench positions to validate; empty positions and an empty bench are valid.
    .DESCRIPTION
        Requires unique positive position numbers and unambiguous occupied serial/CI
        identities. It never repairs, discards or combines the operator's saved data.
    #>
    param([AllowEmptyCollection()][System.Collections.IEnumerable]$Positions = @())
    $indices = @{}
    $occupiedRecords = @()
    foreach ($position in $Positions) {
        $index = [int]$position.Index
        if ($index -lt 1 -or $indices.ContainsKey($index)) { throw 'Saved bench positions have invalid or duplicate numbers. Correct the bench data before continuing.' }
        $indices[$index] = $true
        if ($position.Serial) {
            $occupiedRecords += @{ Serial = $position.Serial; ConfigItem = $position.ConfigItem; Status = 'in-progress' }
        }
        elseif ($position.ConfigItem) { throw 'A saved bench position has a Configuration Item but no serial. Correct the bench data before continuing.' }
    }
    Assert-DeviceRecordIdentity -Records $occupiedRecords
}

function Sync-BenchRecords {
    <#
    .SYNOPSIS
        Validate all bench links before creating missing workflow records or saving.
    .DESCRIPTION
        Uses trimmed, case-insensitive identities without relabelling saved records.
        Rejects conflicting or terminal links and retains records outside the bench.
    .PARAMETER Records
        Caller-owned workflow collection; invalid links leave it unchanged.
    #>
    param([hashtable]$Records)
    if (-not $Script:BuildBench -or -not $Script:BuildBench.Positions) { return }
    Assert-BenchPositionIdentity -Positions $Script:BuildBench.Positions
    Assert-DeviceRecordIdentity -Records $Records.Value
    $recordsBySerial = @{}
    $recordsByConfigItem = @{}
    foreach ($record in $Records.Value) {
        $recordsBySerial[([string]$record.Serial).Trim()] = $record
        $configItem = ([string]$record.ConfigItem).Trim()
        if ($record.Status -ne 'removed' -and $configItem) { $recordsByConfigItem[$configItem] = $record }
    }
    $missingSlots = @()
    foreach ($slot in $Script:BuildBench.Positions) {
        if (-not $slot.Serial) { continue }
        $serial = ([string]$slot.Serial).Trim()
        $configItem = ([string]$slot.ConfigItem).Trim()
        if (-not $configItem) {
            throw ('Bench position {0} has no Configuration Item. Correct the bench data before continuing.' -f $slot.Index)
        }
        $existing = $recordsBySerial[$serial]
        if ($existing) {
            if ($existing.Status -in @('removed', 'completed')) {
                throw ('Bench position {0} links to a {1} workflow for serial {2}. Resolve its status and bench placement before continuing.' -f $slot.Index, $existing.Status, $serial)
            }
            if (([string]$existing.ConfigItem).Trim() -ne $configItem) {
                throw ('Bench position {0} Configuration Item {1} does not match workflow serial {2}. Correct the conflicting link before continuing.' -f $slot.Index, $configItem, $serial)
            }
        }
        $configItemOwner = $recordsByConfigItem[$configItem]
        if ($configItemOwner -and ([string]$configItemOwner.Serial).Trim() -ne $serial) {
            throw ('Bench position {0} Configuration Item {1} belongs to another workflow, serial {2}. Resolve the conflict before induction.' -f $slot.Index, $configItem, ([string]$configItemOwner.Serial).Trim())
        }
        if (-not $existing) { $missingSlots += $slot }
    }
    $site = $Script:BuildBench.SiteCode
    $dtype = $Script:BuildBench.DeviceType
    foreach ($slot in $missingSlots) {
        $expectedTag = if ($site -and $dtype) { ('{0}-{1}' -f $site, ($dtype -replace '\s', '')) } else { $null }
        $rec = New-DeviceRecordObject -Serial $slot.Serial -ConfigItem $slot.ConfigItem -SiteCode $site -DeviceType $dtype -GroupTag $expectedTag
        Add-DeviceRecord -Records $Records -Record $rec
    }
    Write-UserDeviceRecords -Records $Records.Value
}

function Show-BuildBenchTable {
    param([hashtable]$Records)
    # Column widths to preserve alignment; ellipsise long content
    $labelWidth = 10
    $colWidth = 14
    function FormatCell([string]$text, [int]$width) {
        if ($null -eq $text) { $text = '' }
        $t = [string]$text
        if ($t.Length -gt $width) { $t = $t.Substring(0, $width - 1) + '…' }
        return $t.PadRight($width)
    }
    function CenterCell([string]$text, [int]$width) {
        if ($null -eq $text) { $text = '' }
        $t = [string]$text
        if ($t.Length -gt $width) { $t = $t.Substring(0, $width - 1) + '…' }
        $padTotal = $width - $t.Length
        if ($padTotal -le 0) { return $t }
        $left = ($padTotal - ($padTotal % 2)) / 2
        $right = $padTotal - $left
        return ('{0}{1}{2}' -f (' ' * $left), $t, (' ' * $right))
    }
    function BuildRow([string]$label, [string[]]$values, [bool]$centerValues) {
        $row = '|' + ' ' + ($label.PadRight($labelWidth)) + ' '
        foreach ($v in $values) {
            $cellText = if ($centerValues) { CenterCell -text $v -width $colWidth } else { FormatCell -text $v -width $colWidth }
            $row += ('| {0} ' -f $cellText)
        }
        $row += '|'
        return $row
    }
    # Determine how many columns fit the current window
    $winWidth = 120
    try {
        if ($Host -and $Host.UI -and $Host.UI.RawUI) {
            $winWidth = $Host.UI.RawUI.WindowSize.Width
            if ($winWidth -lt 50) { $winWidth = 50 }
        }
    }
    catch { $winWidth = 120 }
    $baseLen = $labelWidth + 3 + 1  # label plus separators and final '|'
    $perCol = $colWidth + 3         # "| {col} " per column
    $maxCols = [int](($winWidth - $baseLen) / $perCol)
    if ($maxCols -lt 1) { $maxCols = 1 }
    $colsPerRow = if ($maxCols -gt 8) { 8 } else { $maxCols }
    $positions = $Script:BuildBench.Positions
    $chunks = @()
    for ($i = 0; $i -lt $positions.Count; $i += $colsPerRow) {
        $endIndex = $i + $colsPerRow - 1
        if ($endIndex -ge $positions.Count) { $endIndex = $positions.Count - 1 }
        $chunks += , (@($positions[$i..$endIndex]))
    }
    foreach ($chunk in $chunks) {
        $posLabels = $chunk | ForEach-Object { $_.Index.ToString() }
        $lineSample = BuildRow -label 'Position' -values $posLabels -centerValues $true
        $rule = '-' * $lineSample.Length
        Write-Host $rule
        Write-Host $lineSample
        Write-Host $rule
        $serialVals = $chunk | ForEach-Object { if ($_.Serial) { $_.Serial } else { '' } }
        Write-Host (BuildRow -label 'Serial' -values $serialVals -centerValues $false)
        $ciVals = $chunk | ForEach-Object { if ($_.ConfigItem) { $_.ConfigItem } else { '' } }
        Write-Host (BuildRow -label 'CI' -values $ciVals -centerValues $false)
        Write-Host $rule
        $currentVals = @()
        foreach ($slot in $chunk) {
            $val = ''
            if ($slot.Serial) {
                $rec = $Records.Value | Where-Object { $_.Serial -eq $slot.Serial }
                if ($rec -and $rec.Steps.Keys.Count -gt 0) { $val = ($rec.Steps.Keys | Select-Object -Last 1) } else { $val = '' }
            }
            $currentVals += $val
        }
        Write-Host (BuildRow -label 'Current' -values $currentVals -centerValues $false)
        $nextVals = @()
        foreach ($slot in $chunk) {
            $val = ''
            if ($slot.Serial) {
                $rec = $Records.Value | Where-Object { $_.Serial -eq $slot.Serial }
                if ($rec) { $val = Get-NextStepId -Device $rec }
            }
            $nextVals += $val
        }
        Write-Host (BuildRow -label 'Next' -values $nextVals -centerValues $false)
        Write-Host $rule
        Write-Host ''
    }
}

function Get-TerminalViewport {
    <# .SYNOPSIS Read usable terminal dimensions; unavailable RawUI uses a conservative fallback. #>
    $width = 120
    $height = 40
    try {
        $size = $Host.UI.RawUI.WindowSize
        if ($size.Width -gt 1) { $width = $size.Width - 1 }
        if ($size.Height -gt 0) { $height = $size.Height }
    }
    catch { $width = 120; $height = 40 }
    return @{ Width = $width; Height = $height }
}

function Get-ScreenTextPage {
    <#
    .SYNOPSIS
        Wrap accessible text and reserve header, navigation and prompt rows before paging.
    .OUTPUTS
        Array of page dictionaries, each containing a Lines array. No host output or workflow mutations.
    #>
    param([AllowEmptyCollection()][string[]]$Lines = @(), [Parameter(Mandatory)][hashtable]$Viewport, [string]$Title)
    $width = [Math]::Max(1, [int]$Viewport.Width)
    $headerRows = [int][Math]::Ceiling(('Autopilot Express - {0} | Live | Page 999 of 999' -f $Title).Length / [double]$width)
    $reservedRows = 2
    foreach ($footer in @('NEXT PAGE. Next page', 'PREVIOUS PAGE. Previous page', 'Step letter: detail; STEP LIST: guide', '0. Return to bench', 'Guide command (default: 0): ')) {
        $reservedRows += [int][Math]::Ceiling($footer.Length / [double]$width)
    }
    $capacity = [Math]::Max(1, [int]$Viewport.Height - $headerRows - $reservedRows)
    $wrapped = @()
    foreach ($line in $Lines) {
        $remaining = [string]$line
        while ($remaining.Length -gt $width) {
            $cut = $remaining.LastIndexOf(' ', $width - 1, $width)
            if ($cut -le 0) { $cut = $width }
            $wrapped += $remaining.Substring(0, $cut)
            $remaining = $remaining.Substring($cut).TrimStart()
        }
        $wrapped += $remaining
    }
    $pages = @()
    for ($offset = 0; $offset -lt $wrapped.Count; $offset += $capacity) {
        $last = [Math]::Min($wrapped.Count - 1, $offset + $capacity - 1)
        $pages += @{ Lines = @($wrapped[$offset..$last]) }
    }
    if (-not $pages.Count) { $pages = @(@{ Lines = @('No enabled workflow steps.') }) }
    return , $pages
}

function Show-BenchWorkflowGuide {
    <#
    .SYNOPSIS
        Explain manifest step codes without executing actions or changing records.
    .DESCRIPTION
        Preserve manifest order within ordinary and conditional recovery actions.
        Pages wrap to the current viewport and recalculate after input/resize.
        > advances and < goes back; repeated symbols avoid custom step-ID collisions.
        A step letter shows paged
        detail; STEP LIST restores the overview; 0 or Enter returns to the bench. R remains
        a return alias only when it is not a manifest step ID. Input is
        case-insensitive and invalid codes are rejected by the shared validator.
    .OUTPUTS
        Accessible host text only; no workflow evidence or files are changed.
    #>
    $steps = @(Get-EnabledManifestSteps)
    $overview = @('Steps follow workflow order. Prerequisites must be complete before an action.', 'Conditional recovery runs only after a recorded failure.')
    foreach ($conditional in @($false, $true)) {
        $section = if ($conditional) { 'Conditional recovery - only after a recorded failure' } else { 'Normal computer build - workflow order' }
        $overview += @('', $section)
        foreach ($step in @($steps | Where-Object { [bool]$_.IsConditional -eq $conditional })) {
            $kind = if ($step.ExecutionType -eq 'graph') { 'Graph action' } else { 'Technician observation' }
            $overview += ('{0}. {1} [{2}]' -f $step.Id, $step.DisplayName, $kind)
            $overview += ('   {0}' -f $step.Summary)
            $prerequisites = if (@($step.PrerequisiteStepIds).Count) { $step.PrerequisiteStepIds -join ', ' } else { 'None' }
            $overview += ('   Requires: {0}' -f $prerequisites)
        }
    }
    $overview += 'Graph submission is not completion: read-back or technician confirmation is recorded separately.'
    $content = $overview
    $pageIndex = 0
    $nextCode = '>'
    $previousCode = '<'
    while (@($steps.Id) -contains $nextCode) { $nextCode += '>' }
    while (@($steps.Id) -contains $previousCode) { $previousCode += '<' }
    while ($true) {
        $pages = Get-ScreenTextPage -Lines $content -Viewport (Get-TerminalViewport) -Title 'Workflow Step Guide'
        $pageIndex = [Math]::Min($pageIndex, $pages.Count - 1)
        Show-ScriptScreen -Title ('Workflow Step Guide | Page {0} of {1}' -f ($pageIndex + 1), $pages.Count)
        foreach ($line in $pages[$pageIndex].Lines) { Write-Host $line }
        Write-Host ''
        $choices = @('0', 'R', 'STEP LIST') + @($steps | ForEach-Object { $_.Id })
        if ($pageIndex -lt $pages.Count - 1) { Write-Host ('{0}. Next page' -f $nextCode); $choices += $nextCode } else { Write-Host 'Last page' }
        if ($pageIndex -gt 0) { Write-Host ('{0}. Previous page' -f $previousCode); $choices += $previousCode } else { Write-Host 'First page' }
        Write-Host 'Step letter: detail; STEP LIST: guide'
        Write-Host '0. Return to bench'
        $code = Read-ValidatedInput -Prompt 'Guide command' -Default '0' -Type 'Choice' -Choices $choices
        if ($code -eq '0' -or ($code -eq 'R' -and @($steps.Id) -notcontains 'R')) { return }
        if ($code -eq $nextCode) { $pageIndex++; continue }
        if ($code -eq $previousCode) { $pageIndex--; continue }
        if ($code -eq 'STEP LIST') { $content = $overview; $pageIndex = 0; continue }
        $step = $steps | Where-Object { $_.Id -eq $code } | Select-Object -First 1
        $content = @('{0}. {1}' -f $step.Id, $step.DisplayName) + @([string]$step.Summary)
        if ($step.Notes) { $content += [string]$step.Notes }
        $prerequisites = if (@($step.PrerequisiteStepIds).Count) { $step.PrerequisiteStepIds -join ', ' } else { 'None' }
        $content += ('Requires completed steps: {0}' -f $prerequisites)
        $pageIndex = 0
    }
}

function Read-BenchCommand {
    <#
    .SYNOPSIS
        Keep the editable command above the separated five-line result area.
    .DESCRIPTION
        Reserve prompt rows and restore the cursor below results before executing an
        action. Hosts without cursor support use linear input followed by results;
        no cursor failure consumes the command or changes workflow state.
    .PARAMETER Lines
        Already retained, transient bench feedback, not persisted workflow evidence.
    #>
    param([AllowEmptyCollection()][string[]]$Lines = @(), [switch]$LinearOutput)
    $footer = @('------------------------------------------------------------', 'Recent results and messages (last five lines):')
    if (-not $Lines.Count) { $footer += '  No actions in this bench view yet.' }
    foreach ($line in $Lines) { $footer += ('  {0}' -f $line) }
    $footer += ''
    $cursorReady = $false
    $endPosition = $null
    if (-not $LinearOutput) {
        try {
            $rawUI = $Host.UI.RawUI
            $inputPosition = $rawUI.CursorPosition
            $rawUI.CursorPosition = $inputPosition
            $width = [Math]::Max(1, $rawUI.BufferSize.Width)
            $promptRows = [int][Math]::Ceiling(100 / [double]$width)
            for ($row = 0; $row -lt $promptRows; $row++) { Write-Host '' }
            $footerRows = 0
            foreach ($line in $footer) {
                Write-Host $line
                $footerRows += [Math]::Max(1, [int][Math]::Ceiling($line.Length / [double]$width))
            }
            $endPosition = $rawUI.CursorPosition
            $inputPosition.X = 0
            $inputPosition.Y = [Math]::Max(0, $endPosition.Y - $footerRows - $promptRows)
            $rawUI.CursorPosition = $inputPosition
            $cursorReady = $true
        }
        catch { $cursorReady = $false }
    }
    try { $command = Read-ValidatedInput -Prompt 'Command (Enter refreshes)' -AllowEmpty -Default 'REFRESH' }
    finally {
        if ($cursorReady) {
            try { $rawUI.CursorPosition = $endPosition }
            catch { Write-Host '' }
        }
    }
    if (-not $cursorReady) { foreach ($line in $footer) { Write-Host $line } }
    return $command
}

function Show-BuildBenchView {
    param([hashtable]$Records)
    if (-not $Script:BuildBench.Active) { Write-Host 'Build bench not initialised.'; return }
    $benchFeedback = @{ Lines = @() }
    function Write-BenchFeedback {
        <# .SYNOPSIS Retain a readable bench result or refusal across redraws. #>
        param([Parameter(Mandatory)][AllowEmptyString()][string]$Text)
        Add-ScreenFeedback -State $benchFeedback -Text @($Text)
        Write-Host $Text
    }
    function Invoke-BenchActionOutput {
        <# .SYNOPSIS Retain host/information output without consuming returned results or exceptions. #>
        param([Parameter(Mandatory)][scriptblock]$Action)
        & $Action 6>&1 | ForEach-Object {
            if ($_ -is [System.Management.Automation.InformationRecord]) {
                $text = if ($_.MessageData -is [string]) { $_.MessageData } else { [string]$_.MessageData.Message }
                if ($text) { Write-BenchFeedback -Text $text }
            }
            else { $_ }
        }
    }
    function Show-BenchScreen {
        Show-ScriptScreen -Title 'Build Bench Manager'
        Show-BuildBenchTable -Records $Records
        if ($Script:BuildBench.Faults -and $Script:BuildBench.Faults.Count -gt 0) {
            Write-Host 'Current faults:'
            foreach ($f in $Script:BuildBench.Faults) { Write-Host $f }
            Write-Host ''
        }
        Write-Host 'Actions:'
        Write-Host '[I]nduct new device   [S]tart Next Step for a device   [C]hoose eligible action   [V]iew all actions for a device'
        Write-Host '[D]ispatch and finish a device   [R]emove from position   [M]ove device   [0/E] Return to main menu'
        Write-Host '[W]orkflow step guide - explain the step letters in build order'
        Write-Host ''
        # Hints for open positions
        $open = @($Script:BuildBench.Positions | Where-Object { -not $_.Serial })
        $nextOpen = if ($open.Count -gt 0) { $open[0].Index } else { 'None' }
        $openList = if ($open.Count -gt 0) { @($open | ForEach-Object { $_.Index }) } else { @() }
        $openPreview = if ($openList.Count -gt 0) { ($openList | Select-Object -First 10) -join ', ' } else { 'None' }
        $moreCount = if ($openList.Count -gt 10) { $openList.Count - 10 } else { 0 }
        Write-Host ('Hint: Next open position: {0}' -f $nextOpen)
        if ($moreCount -gt 0) {
            Write-Host ('Open positions: {0} (and {1} more)' -f $openPreview, $moreCount)
        }
        else {
            Write-Host ('Open positions: {0}' -f $openPreview)
        }
        Write-Host 'Enter a position or scan Serial/CI. Use P:1, CI:123 or S:ABC to disambiguate matches.'
        Write-Host ''
    }
    Show-BenchScreen
    while ($true) {
        $cmd = Read-BenchCommand -Lines $benchFeedback.Lines
        $u = if ([string]::IsNullOrWhiteSpace($cmd)) { 'REFRESH' } else { $cmd.Trim().ToUpper() }
        switch ($u) {
            '0' { Save-BuildBenchState; return }
            'E' { Save-BuildBenchState; return }
            'REFRESH' { Show-BenchScreen }
            'W' { Show-BenchWorkflowGuide; Show-BenchScreen }
            'I' {
                Show-ScriptScreen -Title 'Induct New Device'
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $openSlots = @($Script:BuildBench.Positions | Where-Object { -not $_.Serial })
                if ($openSlots.Count -eq 0) {
                    Write-BenchFeedback 'All bench positions are occupied. Remove or dispatch a device, then try again.'
                    Show-BenchScreen
                    continue
                }
                $defaultPos = $openSlots[0].Index
                while ($true) {
                    $prompt = ('Position number (1-{0}, 0 to cancel)' -f $max)
                    $ans = Read-ValidatedInput -Prompt $prompt -AllowEmpty -Default $defaultPos -Type 'Int'
                    $posNum = [int]$ans
                    if ($posNum -eq 0) { Write-BenchFeedback 'Induction cancelled; no device added.'; Show-BenchScreen; break }
                    if ($posNum -lt 1 -or $posNum -gt $max) { Write-Host ('Invalid position. Choose between 1 and {0}.' -f $max); continue }
                    $slot = $Script:BuildBench.Positions | Where-Object { $_.Index -eq $posNum }
                    if ($slot -and $slot.Serial) { Write-Host ('Position {0} is occupied. Choose an empty position.' -f $posNum); continue }

                    $useCurrent = Read-ValidatedInput -Prompt ('Use current site {0}? (Y/N)' -f $Script:BuildBench.SiteCode) -Default 'Y' -Type 'Choice' -Choices @('Y', 'N')
                    $site = if ($useCurrent.ToUpper() -eq 'Y') { $Script:BuildBench.SiteCode } else { Select-Site -CurrentSiteCode $Script:BuildBench.SiteCode }
                    $dtype = Select-DeviceType -Default $Script:BuildBench.DeviceType
                    $serial = Read-NormalisedSerialInput -Prompt ('Scan or enter {0}' -f $Script:Config.Nomenclature.Serial)
                    $ci = Read-ValidatedInput -Prompt ('Enter {0}' -f $Script:Config.Nomenclature.ConfigItem)
                    Invoke-BenchActionOutput -Action { Add-DeviceToBenchPosition -Position $posNum -Serial $serial -ConfigItem $ci -Records $Records -SiteCode $site -DeviceType $dtype }
                    Show-BenchScreen
                    break
                }
            }
            'R' {
                # Remove a device by position or identifier
                $hasAny = (($Script:BuildBench.Positions | Where-Object { $_.Serial }) | Measure-Object).Count -gt 0
                if (-not $hasAny) { Write-BenchFeedback 'No devices are currently on the bench.'; Show-BenchScreen; continue }
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $occupied = @($Script:BuildBench.Positions | Where-Object { $_.Serial })
                $defaultPos = if ($occupied.Count -gt 0) { $occupied[0].Index } else { 1 }
                $ans = Read-ValidatedInput -Prompt ('Position number (1-{0}) or Serial/CI (0 to cancel)' -f $max) -AllowEmpty -Default $defaultPos
                if ($ans -eq '0') { Show-BenchScreen; continue }
                $slot = Resolve-DeviceSelection -Items $Script:BuildBench.Positions -Selection $ans -Bench
                if (-not $slot -or -not $slot.Serial) { Write-BenchFeedback 'No unique device at that position or identifier. Use P:, S: or CI:.'; Show-BenchScreen; continue }
                Remove-DeviceFromBenchPosition -Position ([int]$slot.Index)
                Save-BuildBenchState
                Write-BenchFeedback ('Position {0}: removed from bench; workflow record retained.' -f $slot.Index)
                Show-BenchScreen
            }
            'S' {
                # Action next step for a device by position or identifier
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $ans = Read-ValidatedInput -Prompt ('Position number (1-{0}) or Serial/CI (0 to cancel)' -f $max)
                if ($ans -eq '0') { Show-BenchScreen; continue }
                $slot = Resolve-DeviceSelection -Items $Script:BuildBench.Positions -Selection $ans -Bench
                if (-not $slot -or -not $slot.Serial) { Write-BenchFeedback 'No unique device at that position or identifier. Use P:, S: or CI:.'; Show-BenchScreen; continue }
                $rec = $Records.Value | Where-Object { $_.Serial -eq $slot.Serial }
                if (-not $rec) {
                    $expectedTag = if ($Script:BuildBench.SiteCode -and $Script:BuildBench.DeviceType) { ('{0}-{1}' -f $Script:BuildBench.SiteCode, ($Script:BuildBench.DeviceType -replace '\s', '')) } else { $null }
                    $rec = New-DeviceRecordObject -Serial $slot.Serial -ConfigItem $slot.ConfigItem -SiteCode $Script:BuildBench.SiteCode -DeviceType $Script:BuildBench.DeviceType -GroupTag $expectedTag
                    Add-DeviceRecord -Records $Records -Record $rec
                    Write-UserDeviceRecords -Records $Records.Value
                }
                $next = Get-NextStepId -Device $rec
                if ($next) {
                    $stepDefinition = Get-ManifestStepDefinition -StepId $next
                    if ($stepDefinition) {
                        $result = Invoke-BenchActionOutput -Action { Invoke-AutopilotManifestStep -Device $rec -StepDefinition $stepDefinition }
                        Write-ManifestStepResult -Device $rec -StepDefinition $stepDefinition -Result $result
                        Write-UserDeviceRecords -Records $Records.Value
                        Write-BenchFeedback ('Serial {0}: {1} [{2}]' -f $rec.Serial, $stepDefinition.DisplayName, $result.CompletionState)
                        Write-BenchFeedback $result.Summary
                        if ($result.Notes) { Write-BenchFeedback $result.Notes }
                        Show-BenchScreen
                    }
                }
                else {
                    $readiness = Test-DeviceReadyForDispatch -Device $rec
                    if ($readiness.Ready) { Write-BenchFeedback 'All steps completed.' }
                    else { Write-BenchFeedback ('No next action is eligible. Required steps remain: {0}.' -f ($readiness.BlockingStepIds -join ', ')) }
                    Show-BenchScreen
                }
            }
            'C' {
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $ans = Read-ValidatedInput -Prompt ('Position number (1-{0}) or Serial/CI (0 to cancel)' -f $max)
                if ($ans -eq '0') { Show-BenchScreen; continue }
                $slot = Resolve-DeviceSelection -Items $Script:BuildBench.Positions -Selection $ans -Bench
                if (-not $slot -or -not $slot.Serial) { Write-BenchFeedback 'No unique device at that position or identifier. Use P:, S: or CI:.'; Show-BenchScreen; continue }

                $rec = $Records.Value | Where-Object { $_.Serial -eq $slot.Serial }
                if (-not $rec) { Write-BenchFeedback 'The selected bench device has no active workflow record.'; Show-BenchScreen; continue }
                $eligibleSteps = @(Get-EligibleManifestSteps -Device $rec)
                if ($eligibleSteps.Count -eq 0) {
                    Write-BenchFeedback 'No eligible actions are available for this device.'
                    Show-BenchScreen
                    continue
                }

                Write-Host 'Eligible actions:'
                foreach ($step in $eligibleSteps) { Write-Host ('{0}. {1}' -f $step.Id, $step.DisplayName) }
                $stepId = Read-ValidatedInput -Prompt 'Choose eligible action' -Default $eligibleSteps[0].Id -Type 'Choice' -Choices @($eligibleSteps | ForEach-Object { $_.Id })
                $stepDefinition = $eligibleSteps | Where-Object { $_.Id -eq $stepId } | Select-Object -First 1
                $result = Invoke-BenchActionOutput -Action { Invoke-AutopilotManifestStep -Device $rec -StepDefinition $stepDefinition }
                Write-ManifestStepResult -Device $rec -StepDefinition $stepDefinition -Result $result
                Write-UserDeviceRecords -Records $Records.Value
                Write-BenchFeedback ('Serial {0}: {1} [{2}]' -f $rec.Serial, $stepDefinition.DisplayName, $result.CompletionState)
                Write-BenchFeedback $result.Summary
                if ($result.Notes) { Write-BenchFeedback $result.Notes }
                Show-BenchScreen
            }
            'D' {
                # Dispatch and finish a device by position or identifier
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $ans = Read-ValidatedInput -Prompt ('Position number (1-{0}) or Serial/CI (0 to cancel)' -f $max)
                if ($ans -eq '0') { Show-BenchScreen; continue }
                $slot = Resolve-DeviceSelection -Items $Script:BuildBench.Positions -Selection $ans -Bench
                if (-not $slot -or -not $slot.Serial) { Write-BenchFeedback 'No unique device at that position or identifier. Use P:, S: or CI:.'; Show-BenchScreen; continue }
                $rec = $Records.Value | Where-Object { $_.Serial -eq $slot.Serial }
                if (-not $rec) {
                    $expectedTag = if ($Script:BuildBench.SiteCode -and $Script:BuildBench.DeviceType) { ('{0}-{1}' -f $Script:BuildBench.SiteCode, ($Script:BuildBench.DeviceType -replace '\s', '')) } else { $null }
                    $rec = New-DeviceRecordObject -Serial $slot.Serial -ConfigItem $slot.ConfigItem -SiteCode $Script:BuildBench.SiteCode -DeviceType $Script:BuildBench.DeviceType -GroupTag $expectedTag
                    Add-DeviceRecord -Records $Records -Record $rec
                }
                if ($rec) {
                    $dispatchReadiness = Test-DeviceReadyForDispatch -Device $rec
                    if (-not $dispatchReadiness.Ready) {
                        Write-BenchFeedback ('Cannot dispatch device. Complete required step(s): {0}.' -f ($dispatchReadiness.BlockingStepIds -join ', '))
                        Show-BenchScreen
                        continue
                    }
                    $rec.Status = 'completed'
                    $rec.IsCompletionVerified = $true
                    $rec.CompletedAt = Get-Date
                    $rec.CompletedBy = $env:USERNAME
                    $rec.LastUpdatedAt = Get-Date
                    $rec.LastUpdatedBy = $env:USERNAME
                }
                Remove-DeviceFromBenchPosition -Position ([int]$slot.Index)
                Write-UserDeviceRecords -Records $Records.Value
                Write-BenchFeedback ('Serial {0}: dispatched; required workflow evidence complete.' -f $rec.Serial)
                Show-BenchScreen
            }
            'V' {
                # View a device details by position or identifier
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $ans = Read-ValidatedInput -Prompt ('Position number (1-{0}) or Serial/CI (0 to cancel)' -f $max)
                if ($ans -eq '0') { Show-BenchScreen; continue }
                $slot = Resolve-DeviceSelection -Items $Script:BuildBench.Positions -Selection $ans -Bench
                if (-not $slot -or -not $slot.Serial) { Write-BenchFeedback 'No unique device at that position or identifier. Use P:, S: or CI:.'; Show-BenchScreen; continue }
                $rec = $Records.Value | Where-Object { $_.Serial -eq $slot.Serial }
                if (-not $rec) {
                    $expectedTag = if ($Script:BuildBench.SiteCode -and $Script:BuildBench.DeviceType) { ('{0}-{1}' -f $Script:BuildBench.SiteCode, ($Script:BuildBench.DeviceType -replace '\s', '')) } else { $null }
                    $rec = New-DeviceRecordObject -Serial $slot.Serial -ConfigItem $slot.ConfigItem -SiteCode $Script:BuildBench.SiteCode -DeviceType $Script:BuildBench.DeviceType -GroupTag $expectedTag
                    Add-DeviceRecord -Records $Records -Record $rec
                    Write-UserDeviceRecords -Records $Records.Value
                }
                if ($rec) {
                    Show-ScriptScreen -Title 'Bench Device Details'
                    Show-DeviceWorkflowStatus -Device $rec
                    Write-Host ''
                    [void](Read-ValidatedInput -Prompt '0 to return to the bench' -Default '0' -Type 'Choice' -Choices @('0'))
                    Show-BenchScreen
                }
            }
            'M' {
                # Move device between positions; source can be pos/serial/ci, destination must be empty; default destination = next open
                $hasAny = (($Script:BuildBench.Positions | Where-Object { $_.Serial }) | Measure-Object).Count -gt 0
                if (-not $hasAny) { Write-BenchFeedback 'No devices are currently on the bench.'; Show-BenchScreen; continue }
                $max = ($Script:BuildBench.Positions | Measure-Object).Count
                $srcAns = Read-ValidatedInput -Prompt ('Source position (1-{0}) or Serial/CI (0 to cancel)' -f $max)
                if ($srcAns -eq '0') { Show-BenchScreen; continue }
                $srcSlot = Resolve-DeviceSelection -Items $Script:BuildBench.Positions -Selection $srcAns -Bench
                if (-not $srcSlot -or -not $srcSlot.Serial) { Write-BenchFeedback 'No unique device found at that source position or identifier.'; Show-BenchScreen; continue }

                $openSlots = @($Script:BuildBench.Positions | Where-Object { -not $_.Serial })
                if ($openSlots.Count -eq 0) { Write-BenchFeedback 'There are no empty positions to move the device to.'; Show-BenchScreen; continue }
                $defaultDest = $openSlots[0].Index
                while ($true) {
                    $destAns = Read-ValidatedInput -Prompt ('Destination position (1-{0}, 0 to cancel)' -f $max) -AllowEmpty -Default $defaultDest
                    if ($destAns -eq '0') { Show-BenchScreen; break }
                    $destNum = ConvertTo-OptionalInteger -Value $destAns
                    if ($null -eq $destNum -or $destNum -lt 1 -or $destNum -gt $max) { Write-Host ('Invalid position. Choose between 1 and {0}.' -f $max); continue }
                    $destSlot = $Script:BuildBench.Positions | Where-Object { $_.Index -eq $destNum }
                    if ($destSlot.Serial) { Write-Host ('Position {0} is occupied. Choose an empty position.' -f $destNum); continue }
                    # Move
                    $destSlot.Serial = $srcSlot.Serial; $destSlot.ConfigItem = $srcSlot.ConfigItem
                    $srcSlot.Serial = $null; $srcSlot.ConfigItem = $null
                    Save-BuildBenchState
                    Write-BenchFeedback ('Moved device to position {0}; workflow evidence retained.' -f $destNum)
                    Show-BenchScreen
                    break
                }
            }
            default {
                # Treat as Serial or CI scanned
                $str = if ($cmd) { $cmd.Trim() } else { '' }
                $rec = $Records.Value | Where-Object { $_.Serial -eq $str -or $_.ConfigItem -eq $str }
                if ($rec) { Write-Host ('Scanned device Serial={0} CI={1} Status={2}' -f $rec.Serial, $rec.ConfigItem, $rec.Status) }
                else { Write-BenchFeedback 'Unknown command or device. Use I/S/C/V/D/R/M/W/0 or scan a known Serial/CI.'; Show-BenchScreen }
            }
        }
    }
}

# ===== Selection helpers =====
function Resolve-DeviceSelection {
    <#
    .SYNOPSIS
        Resolve position, serial or CI input only when it identifies one device.
    .PARAMETER Items
        Display-ordered workflow records or bench positions; empty input is allowed.
    .PARAMETER Selection
        Bare position/identifier, or explicit P:, S: or CI: selection; zero cancels.
    .PARAMETER Bench
        Use stored bench indices instead of displayed workflow list numbers.
    .OUTPUTS
        One original record, or null for cancelled, missing or ambiguous input.
    #>
    param(
        [AllowEmptyCollection()][System.Collections.IEnumerable]$Items = @(),
        [Parameter(Mandatory)][AllowEmptyString()][string]$Selection,
        [switch]$Bench
    )
    $text = $Selection.Trim()
    if (-not $text -or $text -eq '0') { return $null }
    $kind = 'Any'
    if ($text -match '^(P|S|CI):(.+)$') {
        $kind = $Matches[1].ToUpperInvariant()
        $text = $Matches[2].Trim()
    }
    $number = ConvertTo-OptionalInteger -Value $text
    $candidates = @()
    $displayIndex = 0
    foreach ($item in $Items) {
        $displayIndex++
        if (-not $item.Serial) { continue }
        $position = if ($Bench) { $item.Index } else { $displayIndex }
        $positionMatch = $kind -in @('Any', 'P') -and $null -ne $number -and $number -eq $position
        $serialMatch = $kind -in @('Any', 'S') -and ([string]$item.Serial).Trim() -eq $text
        $ciMatch = $kind -in @('Any', 'CI') -and ([string]$item.ConfigItem).Trim() -eq $text
        if ($positionMatch -or $serialMatch -or $ciMatch) { $candidates += , $item }
    }
    if ($candidates.Count -eq 1) { return $candidates[0] }
    if ($candidates.Count -gt 1) { Write-Host 'Ambiguous selection. Use P:<position>, CI:<CI> or S:<serial>; no device was selected.' }
    return $null
}

function Select-DeviceFromRecords {
    param([hashtable]$Records, [string]$Purpose)
    $list = @($Records.Value | Where-Object { $_.Status -ne 'removed' })
    if (-not $list -or $list.Count -eq 0) { Write-Host ''; Write-Host 'No devices currently being worked on.'; Show-ReturnToMainMenu; return $null }
    Write-Host ''
    Write-Host ('Select a device to {0} (number, Serial, CI, or 0 to exit; explicit P:, S:, CI: supported):' -f $Purpose)
    $idx = 1
    foreach ($d in $list) { Write-Host ('  {0}. Serial={1} CI={2} Status={3}' -f $idx, $d.Serial, $d.ConfigItem, $d.Status); $idx++ }
    $sel = Read-ValidatedInput -Prompt 'Your selection (0 exits)' -Default '0'
    if ($sel -eq '0') { return $null }
    $selected = Resolve-DeviceSelection -Items $list -Selection $sel
    if ($selected) { return $selected }
    Write-Host ''; Write-Host 'No matching device'; Show-ReturnToMainMenu; return $null
}

function Select-DeviceType {
    param([string]$Default)
    # Compute unique hotkey letter for each type and present a concise chooser
    $types = $Script:DeviceTypes
    $hotkeys = @{}
    foreach ($t in $types) {
        $clean = ($t -replace '[^A-Za-z0-9]', '')
        if ([string]::IsNullOrWhiteSpace($clean)) { continue }
        $assigned = $false
        for ($i = 0; $i -lt $clean.Length; $i++) {
            $upper = $clean[$i].ToString().ToUpper()
            if (-not ($hotkeys.Values | Where-Object { $_.Key -eq $upper })) {
                $hotkeys[$t] = @{ Index = $i; Key = $upper }
                $assigned = $true
                break
            }
        }
        if (-not $assigned) { $hotkeys[$t] = @{ Index = 0; Key = ($clean[0].ToString().ToUpper()) } }
    }
    Write-Host 'Select Device Type:'
    $i = 1
    foreach ($name in $types) {
        $marker = if ($name -eq $Default) { '*' } else { ' ' }
        $hk = $hotkeys[$name].Key
        Write-Host ('  {0}. {1} (hotkey: {2}) {3}' -f $i, $name, $hk, $marker)
        $i++
    }
    $ans = Read-ValidatedInput -Prompt 'Enter number, hotkey letter, or full name' -Default $Default
    # Try number
    $num = ConvertTo-OptionalInteger -Value $ans
    if ($null -ne $num) {
        if ($num -ge 1 -and $num -le $types.Count) { return $types[$num - 1] }
    }
    # Try hotkey
    $match = $hotkeys.Keys | Where-Object { $hotkeys[$_].Key -eq $ans.ToUpper() }
    if ($match) { return $match }
    # Try exact name
    $exact = $types | Where-Object { $_ -eq $ans }
    if ($exact) { return $exact }
    Write-Host 'Invalid selection; defaulting.'
    return $Default
}

function Show-ReturnToMainMenu {
    <#
    .SYNOPSIS
        Keep report/error output readable until one explicit return acknowledgement.
    .DESCRIPTION
        Zero returns; Enter uses the same default. Invalid input is re-prompted.
        Call only for reports or errors, never after an explicit navigation return.
    .OUTPUTS
        Host text only; no workflow records or persisted evidence are changed.
    #>
    Write-Host ''
    [void](Read-ValidatedInput -Prompt '0. Return to the main menu' -Default '0' -Type Choice -Choices @('0'))
    try { Clear-Host } catch { Write-Host '' }
}

# INITIALISATION & MAIN LOOP
Initialize-AutopilotExpressDefinitions
Show-ScriptScreen -Title 'Initial setup and testing'
$localSessionLock = Start-LocalSessionLock
try {
    Assert-LocalStorageWriteState
    if (-not (Initialize-GraphSession)) {
        Write-AutopilotExpressLog -Message 'Autopilot Express cannot continue without a valid Graph session or demo simulation.' -Level 'ERROR'
        Write-Host 'Startup stopped before the main menu.'
        Write-Host 'Review the error messages above for configuration, module, sign-in, or permission details.'
        Write-Host 'Use Demo mode to rehearse the workflow. For Live mode, sign in with an approved CA/A account and select the tenant profile and group when prompted.'
        Write-Host 'See README.md: Troubleshooting / Live Startup Failures.'
        return
    }
    $records = @{ Value = (Initialize-SessionState) }
    $currentSiteCode = Select-Site -CurrentSiteCode (Get-SessionDefaultSiteCode -Records $records.Value)
    Write-AutopilotExpressLog -Message ('Autopilot Express initialised in {0} mode' -f $Script:Runtime.ModeDisplayName) -Level 'INFO'

    while ($true) {
        $option = Show-MainMenu -CurrentSiteCode $currentSiteCode
        switch ($option) {
            'NewDevice' { $currentSiteCode = Start-NewDeviceWorkflow -CurrentSiteCode $currentSiteCode -Records $records }
            'TrackedDevice' { Invoke-AutopilotSequence -Records $records }
            'Outstanding' { Get-DeviceOutstanding -Records $records }
            'Maintain' { Update-DeviceStatus -Records $records }
            'Statistics' { Get-UserStats -Records $records; Show-ReturnToMainMenu }
            'Enhancements' { Show-EnhancementsQuestions; Show-ReturnToMainMenu }
            'Site' { Show-ScriptScreen -Title 'Change Current Site'; $currentSiteCode = Select-Site -CurrentSiteCode $currentSiteCode }
            'About' { Show-AboutScript }
            'ArchiveSession' {
                if (Show-SessionArchive -Records $records) {
                    $currentSiteCode = Select-Site -CurrentSiteCode $Script:Sites[0].Code
                }
            }
            'Bench' {
                Show-ScriptScreen -Title 'Build Bench Setup'
                if (-not $Script:BuildBench.Active) {
                    $benchCount = Read-ValidatedInput -Prompt 'Number of bench positions' -Type 'Int'
                    New-BuildBench -Positions ([int]$benchCount)
                    $Script:BuildBench.SiteCode = $currentSiteCode
                    $Script:BuildBench.DeviceType = Select-DeviceType -Default $Script:DeviceTypes[0]
                    Sync-BenchRecords -Records $records
                }
                Sync-BenchRecords -Records $records
                Show-BuildBenchView -Records $records
            }
            'Exit' { Write-AutopilotExpressLog -Message 'Exiting Autopilot Express.' -Level 'INFO'; Close-GraphSession; break }
            default { Write-Information -MessageData 'Invalid selection.' -InformationAction Continue }
        }
        if ($option -eq 'Exit') { break }
    }
}
finally {
    Close-GraphSession
    Stop-LocalSessionLock -Lock $localSessionLock
}
