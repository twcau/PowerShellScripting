<!-- omit from toc -->
# Autopilot Express Operations Reference

Detailed workflow behaviour, configuration safeguards, evidence rules, session recovery and diagnostic guidance
are maintained here. Start with [README.md](README.md) for installation and everyday use.
Acceptance and pilot procedures are in [TESTING.md](TESTING.md); the backlog is in [DEVELOPMENT.md](DEVELOPMENT.md).

## Contents

- [Scope and Design Decisions](#scope-and-design-decisions)
- [Implementation Reference](#implementation-reference)
- [Workflow and Physical Work](#workflow-and-physical-work)
- [Configuration Reference](#configuration-reference)
- [Navigation and Device Selection](#navigation-and-device-selection)
- [Data, Session Recovery, and Audit](#data-session-recovery-and-audit)
- [Microsoft Graph](#microsoft-graph)
- [Security and Privacy](#security-and-privacy)
- [Troubleshooting](#troubleshooting)
- [Known Issues and Limitations](#known-issues-and-limitations)
- [Support and Escalation](#support-and-escalation)

## Scope and Design Decisions

The governing procedure is [Autopilot Checklist - New Device v1.4](Autopilot%20Checklist%20-%20v1.4.pdf).
The CLI automates selected Intune/Entra actions and guides technician work; it does not replace the checklist,
physical-device work, approvals or technician judgement.

Confirmed Version 1 decisions:

- Autopilot presence is a blocking preflight gate. A missing serial triggers the approved hash-upload handoff and a retry, not synthetic identifiers or a bypass. Intune preparation cannot continue until the serial is present.
- Local session JSON is the source for in-progress work. A future audit enhancement must provide an all-machine record of what happened, by whom, where and when, with suitable timestamp precision and outcomes. The current local master audit does not meet that cross-machine requirement.
- The build bench supports both the next eligible step and deliberately selecting an eligible specific step.
- Plain serials and supported manufacturer URLs are normalised through ordered runtime rules before lookup, storage, duplicate checks or Group Tag construction.
- Device type is selected by the technician. Manufacturer-service discovery is outside Version 1.

In scope: resolve Autopilot, managed-device and Entra context from serial; normalise supported scanner values;
explicitly confirm associated managed-device deletion; set and verify the enforced `SITECODE-DeviceType` Group Tag;
add/remove pre-provisioning membership; guide imaging, OOBE, profile validation, reseal and sign-in; support conditional
recovery; assign/verify technician and final primary users; persist/resume active work and audit evidence; manage
multiple bench positions and workflow progress.

Outside Version 1 automation:

- Manufacturer lookup of device type and saving the official checklist to SharePoint.
- Company Portal installation/inspection, Dell Command updates, PCL and other machine-side checklist steps 17-22. The CLI guides and records observations; it does not execute this work remotely.
- ZENworks relationships, CMDB changes, physical deployment, replaced-device collection and disposal in steps 24-26.
- Remote device connections or automated machine-side commands.
- Audit-history searches by serial, user, site or date/time window; history-based device status lookup.
- Writing a build certificate onto the built device.

Future proposals must not be presented as implemented. Guided mode is also unimplemented; its intended behaviour
is manual portal/device work without Graph sign-in or mutations, using TechnicianConfirmed evidence rather than
Graph verification. See [development decisions](DEVELOPMENT.md#future-decisions).

## Implementation Reference

The script is an active implementation foundation, not a production-approved release. It implements Live/Demo
menus, JSON definitions, session lifecycle, per-user device/bench/recent-user records, archival, a Live master audit,
site/type selection, scanner normalisation, Graph-backed handlers and isolated Demo simulations. Browser authentication
uses configured Graph scopes/modules. Live startup discovers the authenticated organisation and available Autopilot
profiles and validates the selected group. Session selections are not written back to runtime configuration.

The script resolves the repository root through a README, LICENSE or .git ancestor. The script owns CLI/persistence/
Graph handlers; the manifest owns ordered actions, IDs, labels, enabled state, execution/activation, prerequisites,
permissions, endpoints and notes. Runtime JSON owns tenant/storage/Demo settings. Both definitions load at startup.
Keep them beside the script or use the approved definition-folder override. When the official checklist changes,
review the manifest and workflow guidance together. The historical text scaffold is not executable authority.

### Identity and Workflow Guards

Bootstrap errors preserve the original error and terminate with actionable output. Failed root resolution or cancelled
mode selection cannot continue into definitions, storage or Graph authentication. Demo remains the input default.

Raw manifest validation precedes operational storage and Graph authentication. Schema `1.6.x`, non-empty step/phase
arrays, required text, JSON Boolean flags, typed metadata arrays, supported actions/execution/activation values,
unique step/action/phase identifiers, phase references and enabled dependencies are checked. Duplicate IDs, undefined
or self-dependencies, duplicate prerequisites and cycles are refused. Invalid definitions are not partially published
or silently skipped; optional defaults are retained.

Displayed actions place prerequisites before dependants, including group-add before imaging/profile validation and
sync after first sign-in. Every enabled action appears in one phase. Ordering metadata retains IDs, prerequisites,
activation rules and saved evidence; the loader does not reorder definitions or alter eligibility. Manifest-driven
menus and bench actions explain missing prerequisites rather than propose blocked work or record it as a failed attempt.

Completion and recovery gates resolve enabled semantic action names rather than fixed A/B/F/Q letters. Missing or
ambiguous roles fail closed. The current identity, cleanup, unblock and close-out labels control recovery, the wait,
pending submission and history retention. Existing IDs are unchanged; renaming IDs in saved workflows is not supported
by a migration tool. Recovery-only actions use `activationRequirement` and require an explicitly recorded failure/reason.

Live identity reads require complete, valid responses and a unique matching identity or valid absence. Duplicate
results, malformed/partial collections, missing IDs and mismatched lookup keys stop resolution; the first result is
never selected blindly. Context refresh stages all identifiers until reads succeed, leaving the record unchanged on
failure and clearing absent mutation targets on success. During re-enrolment, a current serial-matched managed-device
record takes precedence over the Autopilot association; that association alone cannot replace current managed-device evidence.

Deletion, Group Tag, membership, unblock and sync refresh context before acting even when IDs are cached. Primary-user
assignment also refreshes context. Failed/ambiguous reads stop the action. Fresh reads do not prevent external changes
after the read or establish an overall deadline.

### Evidence and Completion

| State | Meaning |
| --- | --- |
| `Verified` | Target Graph state was observed. |
| `TechnicianConfirmed` | Technician explicitly observed/confirmed a guided or eligible manual outcome. |
| `Submitted` | An action or handoff remains unverified. |
| `Blocked` | Workflow action is unavailable. |
| `Failed` | Action was unsuccessful. |
| `AuditedException` | Reserved for approved exception evidence. |
| `Simulated` | Successful Demo action, not Live verification. |
| `LegacyCompleted` | Compatible historical completion without invented Graph verification. |

Verified, TechnicianConfirmed, AuditedException and Simulated satisfy current prerequisites; LegacyCompleted remains
compatible for old records missing completion state. Pending and failed outcomes do not satisfy prerequisites.
Normal dispatch/manual completion require all normal steps, plus recovery-only steps while recovery is active.
No eligible next action is not proof of completion.

Unsuccessful/cancelled Demo actions default to Failed, not Simulated. Explicit pending states remain pending.
Retrying a completed action invalidates transitive downstream completion even if the retry succeeds. Prior details
remain with `InvalidatedBy`, `InvalidatedAt` and `PreviousCompletionState`. Reconfirming the upstream action does
not revive descendants; they must be completed again. Unrelated branches and explicit recovery archival remain unchanged.

Primary-user Verified requires the intended Autopilot UPN and a complete managed-device users response containing
exactly one matching user. Object IDs take precedence over UPNs when available. Autopilot-only/managed-only evidence
remains Submitted; absent targets are Blocked and request/read errors Failed. Ambiguous or partial users cannot establish
exclusive verification. Existing relationships are not deleted automatically to resolve ambiguity.

When Autopilot matches but a submitted managed assignment is still unverified, the existing manual prompt is preserved.
Yes is TechnicianConfirmed, never Verified; No stays Submitted. Device final-user fields are selected intent, not proof
of assignment. Consult step evidence. Polling runs before offering manual confirmation; actual tenant validation remains open.

### Polling and Transport

Central script configuration contains separate verification and HTTP transport policies:

| Setting | Default | Accepted values | Purpose |
| --- | --- | --- | --- |
| `MaxRetryAttempts` | `5` | `1` to `20` | Total post-write verification reads. |
| `RetryBackoffSeconds` | `3` | `0` to `60` | Delay between nonmatching verification reads. |
| `TransportMaxAttempts` | `3` | `1` to `5` | Total wrapper GET attempts, including the first. |
| `TransportBackoffSeconds` | `3` | `0` to `60` | Initial backoff without Retry-After. |
| `TransportMaxDelaySeconds` | `60` | `1` to `300` | Maximum backoff/accepted server wait. |
| `TransportTimeoutSeconds` | `60` | `1` to `300` | SDK HTTP client timeout in seconds. |

First verification reads are immediate; there is no pause after success or the last read. Pre-write identity and
relationship checks are separate. Invalid policy is rejected before lookup/mutation. A read-count bound is not a
wall-clock timeout: verification invokes bounded transport attempts and waits. Attempt counts are retained in evidence.

The wrapper retries GET only on structured HTTP 429, 503 or 504. Numeric/HTTP-date Retry-After is honoured; otherwise
backoff is exponential. Invalid headers stop retries. A server delay above the maximum is refused, not shortened;
the operator must return later. Authentication/permission errors, other statuses and unclassified failures are not
automatically retried. Backoff cannot exceed the maximum delay.

Startup and wrapper calls set SDK MaxRetry to zero and apply ClientTimeout. An SDK without those controls fails closed.
This avoids stacked retries and replay of mutations. POST and DELETE are attempted once, including transient failures.
The initial sign-in identity probe uses the configured timeout but not wrapper retries. Default wrapper GET can make
three attempts and two waits, and verification may invoke it repeatedly. No overall workflow deadline is claimed.
Real SDK errors/timeouts, tenant throttling and generated-command behaviour require approved tenant acceptance.

Transport logs include status, attempt, delay and validated request ID, not URI/query or request body. The transport
redaction check alone does not certify every other workflow message. Never blindly repeat an uncertain mutation;
inspect tenant state and retained submission evidence first.

### Mutation Verification

Group Tag updates issue one write, then read back the identity and exact case-sensitive expected tag. A match is
Verified; exhausted mismatch is Submitted, missing context Blocked, and request/unexpected-identity failures Failed.
Data retains expected/last observed tag, attempts and submission evidence; the stored tag changes only after matching
Live read-back. Current operation uses a guarded v1.0 REST update; earlier implementation notes also documented the
[SDK device-property command](https://learn.microsoft.com/powershell/module/microsoft.graph.devicemanagement.enrollment/update-mgdevicemanagementwindowsautopilotdeviceidentitydeviceproperty).

Membership add/remove share a validated policy. An already-correct direct membership is verified without a write.
Otherwise one POST or reference DELETE precedes bounded reads. Matching presence/absence is Verified, exhausted mismatch
Submitted, absent device context Blocked and lookup/write/read failures Failed. Data retains group/device IDs, expected
and observed membership, submission and completed attempt count. Removal retains `/$ref`, removing the relationship,
not the directory object. Never infer completion from "not found" or "already exists" error text.

Earlier membership implementation notes described structured 404 plus group/device identity reads; the implementation
must be interpreted against the current source and [membership tests](tests/GroupMembership.Tests.ps1), not by treating
an arbitrary failed read as absence. Complete membership and identity evidence is required; membership polling attempts
do not count every Graph request or elapsed time.

Managed-device deletion issues one delete, then polls the serial search. Only valid empty results are Verified;
continued visibility, including a replacement ID, is Submitted. Local Intune IDs clear only after verified absence.
Malformed, duplicate, partial and failed reads are refused. Evidence preserves the deleted target and check count.
The existing deletion confirmation default is Y. Older notes described SDK/REST paths; consult current source for the
active implementation rather than interpreting historical paths as an additional user option.

## Workflow and Physical Work

The intended sequence is Intune preparation, guided imaging/pre-provisioning, conditional recovery when needed,
technician ownership/group removal, physical sign-in/applications/updates, then explicitly selected final ownership.
There is no manager-chain or account-role inference. Account contexts remain distinct: CA/A authenticates to Graph;
C/E is used for physical sign-in; an appropriate active C/E account is explicitly selected as final primary user.

### Physical Sequence

```plaintext
Pre-provisioning
|-- E. Add to pre-provisioning group        # Intune preparation
|-- K. Confirm network, imaging and OOBE    # Reach profile screen; default Y
|-- D. Validate deployment profile         # Confirm before setup
|-- L. Confirm successful setup and reseal # Wait for shutdown; default Y
|-- M. Confirm boot to Windows sign-in     # Leave at sign-in; default Y
`-- G. Assign technician primary user      # Remove group before physical sign-in

Post-login
|-- I. Remove pre-provisioning membership  # Requires technician assignment
|-- N. Confirm first Windows sign-in       # Requires G, I and M; default Y
|-- O. Confirm required applications       # One at a time; default Y
|-- H. Retry failed applications           # Sync action, available after N
|-- P. Confirm updates and shutdown        # Requires O; default Y
`-- J. Assign final primary user           # Requires I and P; explicit selection
```

K/D/L/M cover checklist steps 6-10 and 13-14. G requires D and M. Existing A-J records are retained; new K/L/M completion
is never inferred. N-P cover steps 17-22: first sign-in, ordered Company Portal baseline including shared-device Office
and laptop-only Global Protect, manufacturer updates, reboot, applicable procedures and shutdown. They do not remotely
install software, update firmware or power off devices. Live observations are TechnicianConfirmed; Demo observations
Simulated. Defaults are Y as approved; No leaves incomplete/resumable work and later confirmation can resume it.

Application versions reproduce checklist v1.4, not current vendor-release claims. Install one at a time in checklist
order and verify required applications, including those installed by USB image. Failed installations use the named
Intune portal remediation. H requests sync, not that remediation; its required-step behaviour is retained and N is
required before eligibility. Conditional application-remediation modelling remains development work. Non-Dell hardware
must use approved manufacturer procedures, not Dell firmware instructions.

### Recovery Close-out

Manifest 1.6.0 Q follows checklist step 12:

1. Use X to record failure and reason (default N). Results are archived in RecoveryHistory and earlier F/Q results removed from the active recovery cycle.
2. Reset/reimage physically. Use B to remove an associated managed-device record when required, then F to submit Userless Enrolment Status clearing. Live F remains Submitted; it does not prove Allowed or close recovery.
3. Return to Q at least two minutes after the current cycle's F submission. Q is Blocked while waiting, rather than sleeping the CLI. Missing/invalid/prior-cycle timestamps fail closed; serial lookup must show no managed device.
4. Confirm reset/reimage and Intune Allowed (default Y). No retains active recovery. Live confirmation is TechnicianConfirmed, not Graph verification; Demo is Simulated without real lookup/wait.
5. Q archives prior results, retains resolved identity A and recovery evidence F/Q, clears active ownership/completion context and restarts preparation from B. History persists in records and audit. Preparation/physical milestones must be completed again.

While recovery is active, ordinary work is blocked except identity A and cleanup B. After submitted F, the next eligible
bench action offers Q rather than repeat F and restart the wait. This does not remotely reset/reimage a device.
Real-device recovery acceptance remains outstanding. Stop/escalate instead of inventing verification or reusing old completion.

### External Handoff Guidance

Checklist steps 24-26 are guidance only. After successful completed final ownership (Verified, TechnicianConfirmed,
or Demo Simulated), the shared writer displays the handoffs in both normal and bench workflows. Pending/failed/blocked
ownership does not trigger them. There is no integration, confirmation record or added manifest prerequisite;
completion/dispatch gates, old records and account eligibility are unchanged.

- Copy ZENworks relationships from the replaced device or one at the same location performing similar work.
- Find/create the CMDB record. Verify new-record Intune name, numeric sticker CI, approved recipient, site, full department/ward, building/floor/room. The CLI does not infer manager roles or convert Intune ownership to CMDB identity.
- Link the replaced device for decommissioning/disposal using the Downstream CI tab.
- Coordinate installation and collect the old device at the same time. Do not install before collection is possible or leave disposal devices with the caregiver. Complete disposal/decommissioning before close of business that day.

Technicians evidence this work externally. The guide stores no handoff proof; completed Intune work or an empty bench
does not certify physical deployment or external handoffs. Use the official checklist and approved external procedures.

## Configuration Reference

Runtime JSON contains Graph auth/context, required modules/scopes, approved tenant pin, deployment profile/group names,
physical-account eligibility prefixes, search/recent-user limits, storage-contract settings and scanner rules.
Recovery/polling/transport controls are central script settings. Shared-contract fields are not approval to enable Shared.
Do not add broad scopes simply because they work; document each requested scope. The CA/A Graph login prefix is not
enforced by an account-selection policy. Physical C/E eligibility and the selected Graph account are separate concerns.

For changing the pre-provisioning target, see [README configuration](README.md#configuration). One runtime name controls
both add and remove. It is loaded once, requires restart for persistent changes, and a startup placeholder prompt is
session-only. Do not change targets midway through work without a reviewed membership transition.

### Pasted-Code Execution

When using pasted code in an approved IDE/ISE context, retain both JSON definition files. Missing execution-host mode
causes a Live/Demo prompt, default Demo. The script searches the working directory, ancestors and conventional project
location for definitions and prompts for the folder if necessary. The explicit override is:

```powershell
$env:AutopilotExpressDefinitionDirectory = 'C:\Approved\AutopilotExpress'
```

After resolving definitions, the script determines project/storage root; stale inherited PowerShellScriptingNewRoot
does not redirect storage. This selects configuration only: it does not bypass execution policy or signed-code controls.
Windows PowerShell 5.1/ISE writes UTF8 with its byte-order mark; PowerShell 7 writes utf8NoBOM. Offline compatibility
does not certify the actual enforced corporate policy or every ISE/SDK combination.

### Tenant Approval Gate

Local structural validation is not tenant approval. Complete these checks with the tenant security owner before
authorising Live authentication or a pilot; keep secrets and operational records out of Git.

- Confirm tenant and Graph operator. Set graph.expectedTenantId to the approved GUID; blank preserves unpinned compatibility, not approval. Do not clear a pin to bypass rejection. OrganisationName is a label, not an identity safeguard. Live captures SDK tenant GUID, matches organisation discovery and binds records; wrong context/record tenants are refused. These safeguards do not replace security-owner approval.
- Confirm SJOG Hybrid Join and Intune-Autopilot-PreProvisioning, or the approved configured replacements, and record immutable IDs in controlled evidence. Runtime uses display names; group lookup must be unique. Profile assignment is a technician observation, not immutable-ID Graph verification.
- Review all seven configured scopes, including DeviceManagementManagedDevices.PrivilegedOperations.All for sync, plus Intune/Entra roles and Conditional Access. Startup preflight uses write-capable scopes despite read-only probes; it is not reduced-permission discovery. Consent/read success does not establish write authorisation.
- Approve browser sign-in, Process context, installed Graph modules and dedicated-session timeout/zero SDK retries.
- Confirm active C/E eligibility, site/type tags, checklist version and application requirements. Ownership is an explicit technician choice, not manager or role inference.
- Keep storage Local; do not enable Shared before qualified atomicity, locking, concurrency and recovery. Set access and retention for local records/audit.
- Approve a dedicated serial, physical reimage procedure, permitted mutations, evidence handling, recovery owner and escalation. Authentication/read approval and mutation approval are separate. Preparing this checklist runs neither.

Tenant acceptance is deferred; confirming target display names is not approval of actual IDs or pilot operations.
Follow the separately approved [single-device pilot](TESTING.md#single-device-live-pilot).

### Directory Search

autopilot.directorySearchLimit controls requested page size and maximum matches. Optional directorySearchPageLimit
defaults to 10, accepts 1-100 and need not be added to legacy files. At the page bound the CLI warns of incompleteness
and recommends refining/full UPN. UPN duplicates are removed; invalid/repeated continuations or page failures stop
instead of claiming partial success. See [Graph paging](https://learn.microsoft.com/graph/paging).

Literal ranking is exact identity/name, leading phrase, word prefixes in any order, contained phrase, name fragments,
then UPN-only fragments; ties sort by display name/UPN. Numbered menus retain rank; recent users sort alphabetically.
Literal ranking alone does not provide typo tolerance or infer roles. After exhaustive empty literal results, the
separate bounded one-edit suggestion fallback may offer candidates; prefix retrieval can miss typos. Every result
requires explicit selection and Live revalidation, not automatic ownership selection.

### Scanner Serial Normalisation

Ordered runtime rules include name, match condition, named URL/query component and expected serial format. Preserve
valid plain serials; use only the first unambiguous rule producing a valid serial; show transformed serial and ask
confirmation. Reject ambiguous/invalid data rather than guess. Use canonical serial for lookup, duplicates, storage,
audit and tags. Avoid storing complete scanned URLs in normal records; restricted diagnostic retention requires need.
Tenant rules require regression tests.

The MyDell rule recognises `https://www.dell.com/support/pid?s=q3&t=6H70TH4` and extracts `6H70TH4` from one t value.
Missing/repeated t, wrong format or mismatched host/path are rejected.

## Navigation and Device Selection

Menus derive numbers/routes from one ordered definition; old numbers are not aliases. Headers label Demo/Live with
screen title and a blank spacer, and the main screen combines site/account. Input is case-insensitive and defaults
are labelled. Zero returns/exits where shown. Explicit return does not add acknowledgements; empty/error reports
retain one readable prompt. Invalid choices/numbers re-prompt rather than return as valid.

Tracked device stays on that workflow after actions, even off-bench. Eight runs the next eligible action, a step ID
runs eligible specific work, nine selects another device, zero returns. Custom IDs colliding with eight/nine receive
displayed alternative commands; R is a return alias only when not a step ID. Outstanding displays one action per line
and separates recovery; one opens the same device, two selects another, zero returns. Maintain supports repeated
edits after refusals and does not save unchanged status. About text is editable in Show-AboutScript for maintainers.

Declining new-device confirmation preserves serial/CI/site/type as editable defaults; Enter keeps them. Identity
conflicts are explained at entry with correction/zero cancellation; scanner and final identity guards remain. CI is
text, not numeric-only. Success/failure banners include serial/CI/action/state and are not colour-only; Submitted is
pending, Demo Simulated is not Live verification. Results follow successful persistence.

Selection checks position, serial and CI together; bare ambiguous input is rejected. Use P:1 for a position, S:ABC123
for serial or CI:001 for literal CI. Prefixes are case-insensitive; leading zeros matter. Bare zero cancels but CI:0
selects that literal identifier. Main, bench actions and move-source use the same guard; destinations are empty positions.

### Build Bench and Guide

The bench persists physical positions/serials/CIs. I inducts, S runs next, C chooses eligible work, V views, D dispatches,
R removes only the bench position, M moves, W opens the guide, zero returns (E legacy alias). Dispatch completes/removes
only after all required normal and active recovery steps are complete. Removing a position does not delete workflow evidence.

Enter refreshes rather than exits. Five recent readable lines survive redraws, including outcomes/refusals/notes, below
command entry and a dashed separator. Cursor hosts reserve prompt rows; fallback uses linear input then output. This is
transient feedback, not durable audit proof. Real cursor layout still awaits technician acceptance. Zero/E returns immediately.

W shows enabled steps in build order, separates recovery and displays descriptions/types/prerequisites. Pages wrap to
width and budget rows to height with repeated header/page count. Use > then Enter next, < then Enter previous, including
last page. N/P remain step IDs. Direction-symbol ID collisions repeat the displayed paging symbol. Resizing recalculates
on the next command; absent RawUI defaults 120x40. Step IDs open paged notes; STEP LIST returns overview, zero/Enter exits.
R is an alias only without collision. Tiny windows may require enlargement. Guide navigation never executes/saves work.

## Data, Session Recovery, and Audit

Local mode is required for initial imaging. Live/Demo device, recent-user and bench files are per Windows user/mode;
Live master audit is common within the selected root. Files contain operational IDs/personal data, not Graph tokens
or passwords. Restrict access and retain recovery artefacts in backups.

Normal storage is project data; fallback is `%LOCALAPPDATA%\PowerShellScriptingNew\AutopilotExpress\data`. Once fallback
is authoritative it stays so even if repository storage becomes writable. Conflicts or unfinished source checkpoints
stop migration; newest timestamp is not authority and roots must not be merged without review.

### Resume and Audit Evidence

Resume saved work or deliberately archive/start fresh. Loading validates IDs, outcomes, history, bench links and tenant
context; malformed/empty files or conflicting identities stop rather than create empty work. Missing first-run files
and compatible legacy records do not invent verification. Archival is not interrupted-write recovery.

Option 10 selects only the current Windows user's current-mode saved/resumable device/bench pair. The schema holds
one pair, so at most one selection is available; other users/modes and already archived history are not listed.
Selection defaults zero; one warns that the active list/bench will end, then Y/N defaults No and CLEAR defaults CANCEL.
Cancellation changes nothing; responses are case-insensitive.

Confirmation saves active records/bench, archives current and previous files under unique names, resets active work/bench
and opens fresh site selection. Build bench then offers normal position/type setup. It does not reconnect Graph or perform
tenant/device operations. Audit, recent users, receipts, other users/modes and old archives remain. Failure stops without
claiming success; this is not permanent deletion or automatic recovery. The archive-in-progress marker remains until both
moves finish; partial archive blocks reuse/migration pending owner review, not automatic rollback.

Returned outcomes append detached attempt snapshots. Retries invalidate descendants and recovery preserves earlier
results. Normal saves refuse history/audit truncation or rewriting. Evidence becomes durable only after successful save.
Five-line bench text is transient; console output is not a durable transcript and there is no all-machine audit/search.
Never edit evidence to bypass completion/dispatch gates.

### Local Session Reservation

Before operational loading/authentication, exclusive `autopilot-express-live.session.lock` or
`autopilot-express-demo.session.lock` reserves the root/mode across Windows users sharing that root. Live/Demo locks
are separate. A second cooperating invocation stops; normal exit/exceptions release only the owner's token.
Crash leftovers have no expiry/automatic takeover. Separate computers/copied roots do not coordinate the same physical
device. OneDrive/network/external editors/older versions are not a multi-writer safety guarantee.

For a reserved store:

1. Read reported owner/user/computer/PID/token; close a live owner normally.
2. Never remove an active lock or infer death from age. After confirmed crash, stop all CLIs for that root/mode; PID reuse is possible.
3. Preserve device, bench, audit and recovery data. Archive only a reviewed leftover lock outside its active path.
4. Resume and inspect tenant state before repeating anything that might already have executed.

### Interrupted Save Recovery

Single-file saves retain `.write-in-progress`, verified `.pending` and `.previous` evidence. Content is checked
case-sensitively before/after promotion; first saves lack previous copies. UTF-8 follows host/BOM behaviour. Reset archives
current and previous together. Markers, pending orphans or missing targets with previous copies block startup;
Demo ignores Live audit.

Multi-file saves stage a detached proposed record/audit/bench checkpoint. Failure retains it and blocks saves/startup,
including fallback source checkpoints. Targets can be at different committed states. There is no automatic replay,
rollback, reconciliation, atomic replacement, fsync or physical power-loss guarantee.

Recovery procedure:

1. Stop all root/mode CLIs and resolve lock ownership.
2. Preserve checkpoint, targets, marker/pending/previous copies in restricted storage with names/timestamps.
3. Use Get-LocalCheckpointInspection in an approved recovery/development context. It is read-only, not recovery approval; compare proposed/actual content and retained file presence.
4. Inspect target/actor/time/HadOriginal. Incomplete candidates and first saves may lack trustworthy previous state; valid JSON/newest timestamp/highest revision is not commit proof.
5. Compare IDs, serials, CIs, tenant, step/history, bench and audit. Under separate approval inspect tenant mutations, which may have succeeded before failure.
6. Obtain recovery-owner decision. Restore only reviewed consistent state if necessary; archive unresolved evidence outside active paths after review and retain trustworthy backups.
7. Restart, verify records/bench/audit, and only then continue. Without trustworthy state, stop and escalate.

Never delete markers merely to bypass guards. The `.archive-in-progress` marker also requires review of active files
and completed moves. A save error does not permit replay. Sync receipts reduce repeat submissions but leave the
server-acceptance-to-save crash gap. See [fault coverage](TESTING.md#test-catalogue).

### Shared Storage: Deferred

Local-only initial imaging was selected on 11 October 2026. Shared is disabled/refused, not silently replaced with Local.
Do not enable it or migrate records for the initial pilot. Disconnected helpers cover reservations/revisions, append-only
evidence, inspection and migration preview; RecoveryApproved/MigrationApproved never become true. They do not capture
consistent local checkpoints, integrate Shared or qualify network durability. Activation requires approved backend,
permissions/recovery owner, atomic replacement/distributed ownership, reviewed migration and real concurrency/disconnect/
recovery tests. See [Shared Development Contract](TESTING.md#shared-development-contract).

## Microsoft Graph

Live uses delegated browser authentication with configured scopes/modules and Process context. Read preflight covers
Autopilot, managed devices, Entra devices, users and group; failure closes Graph/stops startup without destructive probes.
Read/consent success is neither write permission nor mutation approval. Profile remains technician-confirmed.

| Operation | Required evidence |
| --- | --- |
| Resolve serial/Entra device | Unique matching IDs and complete reads. |
| Delete managed device | Explicit confirmation and bounded absence reads. |
| Group Tag | One guarded v1.0 REST write and exact tag read-back. |
| Membership | Current eligible targets and observed presence/absence. |
| Primary user | Matching Autopilot UPN and exclusive managed relationship. |
| Sync | One submission/receipt then application observation; not app remediation. |
| Recovery unblock | Submitted, then timed technician-observed Allowed plus managed-device absence. |

Fresh reads and tenant pinning refuse inappropriate cached targets but cannot eliminate races after a read. Logs/consent
are not independent mutation proof. Use the tenant approval gate and inspect uncertain outcomes before replaying work.

## Security and Privacy

- Use approved CA/A authentication; keep credentials/tokens out of source, JSON and screenshots.
- Confirm tenant, serial, group/profile and account. Never bypass denial with a broader/shared unapproved account.
- Protect data/recovery with approved Windows access/retention controls; keep personal/operational data out of Git.
- Retain permitted status/code/request IDs without secrets or excessive payloads; review privacy and persistence.
- Keep Demo separate. Manual observations remain TechnicianConfirmed, never relabelled Verified.

## Troubleshooting

### Live Startup Failures

Browser success precedes SDK context validation, /me, matching organisation and read capabilities. Failure afterwards
does not automatically mean licensing or authentication denial. No menu workflow runs after failed startup.
Diagnostics include stage, exception type, recognised status/request ID, host/edition/language and loaded SDK versions.
HTTP=unavailable only means no recognised supplied status, not absence of traffic/denial. Routine logs omit raw SDK
bodies/messages, tokens and query strings.

| Stage or diagnostic | Interpretation and next step |
| --- | --- |
| URI construction | Investigate SDK/environment first; retry approved current code in fresh non-elevated PS7. Do not broaden permissions or reinstall solely on this message. |
| Context validation | Verify approved expectedTenantId and authenticated tenant; never clear an intentional pin to bypass rejection. |
| /me identity | Browser returned but identity read failed. Preserve stage/type/status; 401 needs session review, 403 delegated-access administrator review. |
| Organisation binding | Verify intended organisation and directory-read access; consent alone is insufficient. |
| Capability preflight | Review the named failure with administrator against scopes/roles/policy; Intune availability is not API authorisation proof. |

The 11 October two-tenant Invalid URI report exposed inconsistent absolute /me versus relative guarded SDK paths.
/me now follows the relative convention to avoid environment reset. The user subsequently confirmed successful sign-in
and correct rejection when the required group was missing; broader tenant acceptance remains deferred. Exact historical
probe limits and evidence are in [Validation Results](TESTING.md#validation-results).

For an approved retry use fresh non-elevated PS7, current code and intended pin. Avoid processes preloaded with mixed
Graph versions or speculative account/tenant switches. Supply stage/version/status/revision in controlled storage.
Verbose enables exception-type chains, not indiscriminate SDK debug/body/token logging. Read/auth retries still need approval.

Other failure handling:

- Missing serial: check canonical scanner value, complete approved hash-upload handoff and retry; never fabricate IDs.
- Denied action: preserve permitted code/request ID and target/action/account, then escalate for minimum approved access.
- Submitted or uncertain save: inspect tenant and durable evidence; never treat submission as complete or replay blindly.
- No eligible action: inspect prerequisites/recovery; never manually complete because the picker is empty.
- Resume failure: verify mode/user/root/archive decision; never overwrite authoritative fallback with older repository state.
- Storage failure: use the reservation/recovery procedures above, not marker deletion or empty-session substitution.
- Layout fault: rehearse Demo in the same host/width and provide controlled screenshots/input trace. Mock tests are not visual proof.
- Physical Autopilot failure: X reason, B cleanup, F submission, timed Q; preserve history and restart preparation from B.

## Known Issues and Limitations

Real SDK/permissions, propagation/throttling, policy and a complete approved physical pilot still need acceptance.
Observations/profile/manual outcomes are technician evidence. H is sync; app remediation remains a portal handoff.
Steps 24-26 are guidance only. No CMDB/ZENworks/disposal/machine-side integration is claimed. Local storage is not
distributed or atomic multi-file/power-loss-certified; Shared and all-machine audit/search are deferred. One-edit
discovery is bounded, not exhaustive; permission-aware disabling is unimplemented. Synthetic FullLanguage/
ConstrainedLanguage tests do not certify real corporate policy, ISE or all SDKs. The old text scaffold is not executable authority.

## Support and Escalation

Use MWP + ITSOs Teams chat with serial, action/checklist, permitted code/request ID, approved evidence location and
troubleshooting completed. For defects include mode, host/edition/language, source/config revision, SDK versions, exact
inputs, preflight and record/checkpoint IDs. Never include secrets. Preserve uncertain-state evidence and stop.
The approved pilot approver and recovery owner decide when work may resume.
